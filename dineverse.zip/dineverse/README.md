# DineVerse: Dining, Reimagined

Multi-restaurant discovery and reservation platform (MERN + Three.js). Customers explore a restaurant in interactive 3D, pick a **specific table**, and reserve it; owners manage venues, menus, floor plans and staff; staff check guests in with QR codes; admins oversee the platform.

> **Demo build.** Every restaurant, menu, rating, testimonial and statistic is **fictional sample content** and is labelled as such in the UI. No payments, ordering, delivery, email or SMS exist in this version.

## Status: read this first

This codebase was written in an environment **without access to the npm registry or MongoDB**, so it has **not been installed, built, or run end-to-end**. What *was* verified there:

| Verified | How |
|---|---|
| 20 unit tests of the core business rules pass (time zones, opening hours, slot generation, table availability, status transitions, cancellation cutoff, QR signing, analytics) | run with a temporary vitest shim |
| Every server and client file parses; every relative import resolves to a real file and a real export; every route handler/validator exists; every JSX component is declared | static scripts |

What is **not** verified and needs you to run it: `npm install`, `vite build`, the API integration tests (need MongoDB), the frontend tests, the 3D scene on real hardware, camera scanning, Socket.IO. Expect some small fixes on first run (typos, dependency version drift). Run the checklist in [First run](#first-run-checklist) and fix anything red before relying on it.

## Features

- **Discovery**: search + filters (city, cuisine, price, rating, experience, live availability), sort, pagination, URL-persisted state, skeletons/empty/error states.
- **Interactive 3D seating** (React Three Fiber): procedural room built from the saved floor plan, orbit/zoom/pan with limits, touch controls, reset camera, legend with symbols + text, WebGL detection and automatic **2D fallback** with equivalent functionality (also keyboard/screen-reader accessible).
- **Reservations**: server-side validation of hours, capacity, window, table ownership; **database-level double-booking prevention**; cancellation by policy; QR confirmation.
- **QR check-in**: signed token (no personal data), hash stored, staff-only verification, arrival window, duplicate prevention, manual reference entry, clear invalid/expired/already-used states.
- **Staff**: live dashboard, reservation list + lifecycle actions, scanner, walk-ins, table status.
- **Owner**: restaurant profile/hours/rules, menu CRUD, tables CRUD, **drag-and-drop 2D floor-plan editor** with 3D preview, staff assignments, analytics (Recharts).
- **Admin**: platform metrics, approve/reject/suspend/reactivate restaurants, user (de)activation, audit log.
- **Realtime**: Socket.IO rooms per restaurant (authenticated, authorised joins); automatic 30-second polling fallback.

## Stack

React 18 + Vite + React Router + Tailwind · Framer Motion · Lucide · React Hook Form + Zod · Three.js / R3F / Drei · Axios · Socket.IO · Recharts · html5-qrcode  
Node + Express · MongoDB + Mongoose · JWT (HTTP-only cookie) · bcryptjs · helmet · express-rate-limit · zod · qrcode · Socket.IO  
Tests: Vitest, React Testing Library, supertest + mongodb-memory-server.

## Project structure

```
client/src/{app,assets,components/{common,layout,restaurant,reservation,dashboard},context,hooks,pages/{public,customer,owner,staff,admin},services,styles,test,three,utils}
server/src/{config,models,controllers,routes,middleware,services,validators,sockets,utils,seed,app.js,server.js}
server/tests/{unit,api}
```

## Prerequisites

Node 18.18+ (20/22 recommended), npm, and MongoDB: a local `mongod`, `docker compose up -d` (see `docker-compose.yml`), or a free MongoDB Atlas cluster.

## Installation & first run checklist

```bash
# 1. Backend
cd server
cp .env.example .env            # set MONGODB_URI, JWT_SECRET, QR_SECRET
npm install
npm run test:unit               # no database needed
npm test                        # unit + API tests (downloads an in-memory MongoDB on first run)
npm run seed                    # development-only demo data
npm run dev                     # http://localhost:5000/api/v1/health

# 2. Frontend (new terminal)
cd client
cp .env.example .env            # leave blank for local dev (Vite proxies /api and /socket.io)
npm install
npm test
npm run dev                     # http://localhost:5173
npm run build                   # verify the production bundle
```

### Development demo accounts (created by `npm run seed`, password `Demo@12345`)

| Role | Email |
|---|---|
| Admin | admin@dineverse.demo |
| Owner (4 venues) | owner@dineverse.demo |
| Owner (1 venue) | owner2@dineverse.demo |
| Staff (2 venues) | staff@dineverse.demo |
| Customer | customer@dineverse.demo (also customer2/3) |

The seed script **refuses to run when `NODE_ENV=production`** and there is no endpoint that can create admins. Override the password with `SEED_DEMO_PASSWORD`.

### Environment variables

Server (`server/.env.example`): `PORT`, `NODE_ENV`, `MONGODB_URI`, `CLIENT_URL` (comma-separated origins), `COOKIE_SAMESITE`, `JWT_SECRET`, `JWT_EXPIRES_IN`, `COOKIE_MAX_AGE_DAYS`, `QR_SECRET`, `EMAIL_PROVIDER` (unused), `SEED_DEMO_PASSWORD`.  
Client (`client/.env.example`): `VITE_API_URL`, `VITE_SOCKET_URL`, `VITE_CONTACT_EMAIL`, `VITE_DEV_API_TARGET`.  
In production the server **refuses to start** with default/short secrets.

## How the important things work

**Double-booking prevention (no transactions required).** Every reservation stores `slotKeys`: one `"<tableId>:<15-min-slot>"` string per 15-minute slot it holds (including buffer). A **partial unique index** on `slotKeys` (only where `blocking: true`) makes it impossible for two active reservations to overlap on a table, even under concurrent requests. A losing request gets `409 SLOT_CONFLICT` with alternative tables/times. Cancelled/completed/no-show reservations set `blocking: false`, freeing the slots. The same guard covers walk-ins. (If you later move to multi-document workflows, MongoDB transactions need a replica set; Atlas has one by default.)

**Time zones.** Instants are stored in UTC; opening hours are interpreted in each restaurant's IANA timezone (seed data uses `Asia/Kolkata`). Closing times earlier than opening mean "after midnight". Known edge: a booking *after midnight* is evaluated against that calendar day's hours, not the previous night's.

**Authentication.** JWT in an HTTP-only, `SameSite` cookie (`Secure` in production). Logout and password change bump a per-user `tokenVersion`, revoking all earlier tokens. For cross-site hosting (Vercel → Render) set `COOKIE_SAMESITE=none` (HTTPS required) and list the Vercel origin in `CLIENT_URL`. A `Bearer` header is also accepted. Registration can only create `customer` or `owner` (applicant) accounts; owners' restaurants start `pending` until an admin approves.

**Authorization.** Route guards in React are UX only. Every endpoint re-checks role, restaurant ownership or staff assignment (`services/access.js`), never trusting client-supplied ids. Updates use strict whitelisted zod schemas (no mass assignment). Admin/owner actions are audited with secrets scrubbed.

**QR.** Token = `<reservationId>.<HMAC-SHA256 signature>`; only its SHA-256 hash is stored. QR contains `dineverse:checkin:<token>`; no names or contact data.

## API (all under `/api/v1`)

Responses: `{ success: true, data, message?, meta? }` or `{ success: false, message, code, details? }`.

| Area | Endpoints |
|---|---|
| Auth | `POST /auth/register`, `POST /auth/login`, `POST /auth/logout`, `GET/PATCH /auth/me`, `POST /auth/change-password`, `POST /auth/forgot-password` (explains email is disabled) |
| Public | `GET /restaurants` (filters: q, city, cuisine, price, experience, minRating, date+time+guests, sort, page), `GET /restaurants/facets`, `GET /restaurants/:slug`, `GET /restaurants/:id/availability?date&time&guests`, `GET /restaurants/:id/tables`, `GET /restaurants/:id/menu` |
| Customer | `POST /reservations`, `GET /reservations/my?group=`, `GET /reservations/:id`, `PATCH /reservations/:id/cancel`, `GET/PUT/DELETE /favorites…` |
| Check-in (staff/owner) | `POST /checkin/verify`, `POST /checkin/confirm` (`{token}` or `{reference}`) |
| Owner | `GET /owner/dashboard`, `GET /owner/analytics`, `GET/POST /owner/restaurants`, `GET/PATCH /owner/restaurants/:id`, `GET /owner/reservations`, `GET/POST /owner/restaurants/:id/tables`, `PATCH/DELETE /owner/tables/:tableId`, `GET/PUT /owner/restaurants/:id/floor-plan`, `GET/POST /owner/restaurants/:id/menu`, `PATCH/DELETE /owner/menu/:itemId`, `GET/POST /owner/staff`, `PATCH /owner/staff/:id` |
| Staff | `GET /staff/me`, `GET /staff/dashboard`, `GET /staff/reservations`, `POST /staff/walk-ins`, `PATCH /staff/tables/:tableId/status`, `PATCH /staff/reservations/:id/status` |
| Admin | `GET /admin/dashboard`, `GET /admin/restaurants`, `PATCH /admin/restaurants/:id/status`, `GET /admin/customers`, `PATCH /admin/users/:id/active`, `GET /admin/reservations`, `GET /admin/audit` |

Socket.IO events (restaurant-room, ids/status only, no PII): `reservation:created|updated|cancelled`, `guest:checked_in`, `table:status`. Clients emit `restaurant:join` (authorised server-side).

## Deployment

- **Database**: MongoDB Atlas; allow the Render egress IPs; set `MONGODB_URI`.
- **Backend (Render)**: root `server`, build `npm install`, start `npm start`. Set all env vars, `NODE_ENV=production`, `COOKIE_SAMESITE=none`, `CLIENT_URL=https://<your-vercel-app>`. Do **not** run the seed in production.
- **Frontend (Vercel)**: root `client`, build `npm run build`, output `dist`. Set `VITE_API_URL=https://<render-app>/api/v1`, `VITE_SOCKET_URL=https://<render-app>`. Add a rewrite of all paths to `/index.html` (SPA routing).
- Render free instances sleep; the first request may be slow and WebSockets reconnect automatically.

## Security notes

bcrypt (12 rounds) · strict input validation · NoSQL operator-key rejection · helmet · explicit CORS · rate limits on auth, booking, check-in and the API overall · HTTP-only cookies · token revocation · audit log · production refuses weak secrets · stack traces never returned in production.

## Accessibility

Semantic landmarks, skip link, labelled forms with `aria-describedby` errors, accessible modal (focus trap, Escape, focus return), `aria-live` regions for availability/selection/check-in results, text + symbol for every table state, keyboard-operable 2D seating plan and floor-plan editor (arrow keys), `prefers-reduced-motion` honoured. `text-muted` (#77736D) is slightly below 4.5:1 on the darkest background; it is used sparingly for non-essential metadata, so audit before a formal WCAG claim.

## Known limitations (honest list)

- **Unverified build** (see Status). Dependencies are version-ranged, not locked; no `package-lock.json` was generated.
- No images are bundled. Venues show generated placeholders until owners add image URLs (use only images you have rights to). No real photography is shipped.
- Email/SMS are not implemented; the UI says so wherever a confirmation would normally be emailed. Password recovery is therefore unavailable.
- "Pending" reservations exist in the state machine but online bookings are auto-confirmed (no approval workflow UI).
- Staff reservation lifecycle changes can be made by owners too (owners act with full permission on their venues).
- Analytics "occupancy" is reserved table-time ÷ opening time, an estimate, and the seeded statistics are simulated.
- The availability filter on `/restaurants` evaluates venues individually (fine for demo scale, not for thousands of venues).
- The Playwright/end-to-end test required by the PRD is **not included**; API integration tests cover the booking and check-in flows at the HTTP level.
- Table renumbering swaps in a single floor-plan save can trip the unique index (409); rename via an interim number.

## Future enhancements

Email/SMS provider, approval workflow, payments/deposits, reviews, GLB assets for richer 3D, multi-floor plans, waitlists, Playwright E2E, lockfiles + CI.
