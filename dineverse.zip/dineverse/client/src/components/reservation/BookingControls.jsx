import { Field } from '../common/ui.jsx';
import { dateInTz, to12h } from '../../utils/format.js';

const GUESTS = Array.from({ length: 12 }, (_, i) => i + 1);

/** Date / time / party-size controls shared by the detail page and the 3D experience. */
export default function BookingControls({ value, onChange, slots, maxGuests = 12, tz = 'Asia/Kolkata', compact }) {
  const set = (patch) => onChange({ ...value, ...patch });
  const min = dateInTz(0, tz);
  return (
    <div className={compact ? 'grid gap-3 sm:grid-cols-3' : 'space-y-4'}>
      <Field label="Date" type="date" min={min} value={value.date} onChange={(e) => e.target.value && set({ date: e.target.value })} />
      <Field label="Time" as="select" value={value.time} onChange={(e) => set({ time: e.target.value })}>
        {(slots?.length ? slots : [{ time: value.time, availableCount: 0 }]).map((s) => (
          <option key={s.time} value={s.time}>
            {to12h(s.time)}
            {slots?.length ? (s.availableCount > 0 ? '' : ' · full') : ''}
          </option>
        ))}
      </Field>
      <Field label="Guests" as="select" value={value.guests} onChange={(e) => set({ guests: Number(e.target.value) })}>
        {GUESTS.filter((g) => g <= maxGuests).map((g) => (
          <option key={g} value={g}>
            {g} {g === 1 ? 'guest' : 'guests'}
          </option>
        ))}
      </Field>
    </div>
  );
}

/** Time chips: each bookable start time with how many suitable tables remain. */
export function SlotChips({ slots, value, onPick }) {
  if (!slots?.length) return <p className="text-sm text-paper-2">No bookable times on this date. The restaurant may be closed.</p>;
  return (
    <div role="group" aria-label="Available times" className="flex flex-wrap gap-2">
      {slots.map((s) => {
        const full = s.availableCount === 0;
        return (
          <button
            key={s.time}
            type="button"
            disabled={full}
            aria-pressed={value === s.time}
            onClick={() => onPick(s.time)}
            className={`rounded-lg border px-3 py-1.5 text-xs transition ${value === s.time ? 'border-gold bg-gold text-ink' : full ? 'border-line text-muted line-through' : 'border-line text-paper hover:border-gold'}`}
            title={full ? 'No suitable tables free' : `${s.availableCount} table(s) free`}
          >
            {to12h(s.time)}
          </button>
        );
      })}
    </div>
  );
}
