import { Suspense, lazy, useState } from 'react';
import { Box, Check, LayoutGrid, Minus, RotateCcw, Star, X } from 'lucide-react';
import ErrorBoundary from '../common/ErrorBoundary.jsx';
import SceneLoading from '../../three/SceneLoading.jsx';
import SceneFallback from '../../three/SceneFallback.jsx';
import { STATE_META, hasWebGL } from '../../three/tableState.js';
import { cn } from '../../utils/format.js';

// The 3D scene (three.js + R3F) is loaded on demand so it never bloats the initial bundle.
const RestaurantScene = lazy(() => import('../../three/RestaurantScene.jsx'));

const ICON = { available: Check, selected: Star, unavailable: X, disabled: Minus };

export function SeatingLegend({ className }) {
  return (
    <ul className={cn('flex flex-wrap gap-x-5 gap-y-2 text-xs text-paper-2', className)} aria-label="Legend">
      {Object.entries({ available: 'Available', selected: 'Selected', unavailable: 'Booked', disabled: 'Unavailable / out of service' }).map(([k, label]) => {
        const Icon = ICON[k];
        return (
          <li key={k} className="flex items-center gap-1.5">
            <span className="grid h-5 w-5 place-items-center rounded-full border" style={{ borderColor: STATE_META[k].color, color: STATE_META[k].color }}>
              <Icon size={11} aria-hidden />
            </span>
            {label}
          </li>
        );
      })}
    </ul>
  );
}

/**
 * Wraps the 3D scene with its toolbar, legend, WebGL detection and automatic 2D fallback.
 * The 2D view offers equivalent functionality, so booking never depends on 3D or a mouse.
 */
export default function SeatingExperience({ layout, tables, selectedId, onPick, readOnly = false, height = 540, showLegend = true }) {
  const [view, setView] = useState(() => (hasWebGL() ? '3d' : '2d'));
  const [reset, setReset] = useState(0);
  const [notice, setNotice] = useState(!hasWebGL() ? 'Your browser or device could not start 3D graphics, so the 2D seating plan is shown.' : '');

  const fallback = (why) => {
    setNotice(why);
    setView('2d');
  };

  return (
    <div className="overflow-hidden rounded-xl border border-line bg-ink-2">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line px-3 py-2">
        <div role="group" aria-label="View mode" className="flex rounded-lg border border-line p-0.5">
          {[['3d', 'Interactive 3D', Box], ['2d', '2D plan', LayoutGrid]].map(([id, label, Icon]) => (
            <button
              key={id}
              type="button"
              aria-pressed={view === id}
              onClick={() => (id === '3d' && !hasWebGL() ? fallback('3D graphics are not supported on this device.') : (setNotice(''), setView(id)))}
              className={cn('flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs transition', view === id ? 'bg-gold text-ink' : 'text-paper-2 hover:text-paper')}
            >
              <Icon size={14} aria-hidden /> {label}
            </button>
          ))}
        </div>
        {view === '3d' && (
          <button type="button" onClick={() => setReset((n) => n + 1)} className="btn-ghost btn-sm">
            <RotateCcw size={14} aria-hidden /> Reset camera
          </button>
        )}
      </div>

      {notice && (
        <p role="status" className="border-b border-line bg-gold/10 px-4 py-2 text-xs text-champagne">
          {notice}
        </p>
      )}

      {view === '3d' ? (
        <div style={{ height }} className="relative touch-none bg-ink">
          <ErrorBoundary onError={() => fallback('The 3D scene could not be displayed, so the 2D seating plan is shown instead.')} fallback={null}>
            <Suspense fallback={<SceneLoading />}>
              <RestaurantScene layout={layout} tables={tables} selectedId={selectedId} onPick={onPick} readOnly={readOnly} resetSignal={reset} onContextLost={() => fallback('3D graphics stopped responding, so the 2D seating plan is shown.')} />
            </Suspense>
          </ErrorBoundary>
          <p className="pointer-events-none absolute bottom-2 left-3 hidden text-[11px] text-paper-2 sm:block">Drag to rotate · scroll or pinch to zoom · right-drag or two fingers to pan</p>
        </div>
      ) : (
        <SceneFallback layout={layout} tables={tables} selectedId={selectedId} onPick={onPick} readOnly={readOnly} />
      )}

      {showLegend && <SeatingLegend className="border-t border-line px-4 py-3" />}
    </div>
  );
}
