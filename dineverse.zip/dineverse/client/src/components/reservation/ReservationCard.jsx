import { Link } from 'react-router-dom';
import { CalendarDays, Clock, QrCode, Users, Armchair } from 'lucide-react';
import RestaurantImage from '../common/RestaurantImage.jsx';
import { StatusBadge } from '../common/ui.jsx';
import { fmtDate, fmtTime } from '../../utils/format.js';

export default function ReservationCard({ reservation: r, onCancel }) {
  const tz = r.restaurant?.timezone;
  return (
    <article className="card flex flex-col overflow-hidden sm:flex-row">
      <div className="h-36 shrink-0 sm:h-auto sm:w-44">
        <RestaurantImage image={r.restaurant?.image} name={r.restaurant?.name} seed={r.restaurant?.slug} rounded="" />
      </div>
      <div className="flex-1 p-5">
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div>
            <h3 className="text-2xl">{r.restaurant?.name}</h3>
            <p className="text-xs text-paper-2">Ref {r.bookingReference}</p>
          </div>
          <StatusBadge status={r.status} />
        </div>
        <dl className="mt-3 grid grid-cols-2 gap-2 text-sm text-paper-2 sm:grid-cols-4">
          <div className="flex items-center gap-1.5"><CalendarDays size={14} aria-hidden /><dt className="sr-only">Date</dt><dd>{fmtDate(r.startAt, tz)}</dd></div>
          <div className="flex items-center gap-1.5"><Clock size={14} aria-hidden /><dt className="sr-only">Time</dt><dd>{fmtTime(r.startAt, tz)}</dd></div>
          <div className="flex items-center gap-1.5"><Users size={14} aria-hidden /><dt className="sr-only">Guests</dt><dd>{r.guestCount} guests</dd></div>
          <div className="flex items-center gap-1.5"><Armchair size={14} aria-hidden /><dt className="sr-only">Table</dt><dd>{r.table?.displayName}</dd></div>
        </dl>
        <div className="mt-4 flex flex-wrap gap-2">
          <Link to={`/customer/reservations/${r.id}`} className="btn-outline btn-sm">
            Details
          </Link>
          {r.status === 'confirmed' && (
            <Link to={`/customer/reservations/${r.id}`} className="btn-ghost btn-sm">
              <QrCode size={14} aria-hidden /> View QR
            </Link>
          )}
          {r.canCancel && onCancel && (
            <button className="btn-danger btn-sm" onClick={() => onCancel(r)}>
              Cancel
            </button>
          )}
        </div>
      </div>
    </article>
  );
}
