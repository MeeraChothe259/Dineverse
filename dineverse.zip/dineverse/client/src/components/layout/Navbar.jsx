import { useEffect, useState } from 'react';
import { Link, NavLink, useLocation, useNavigate } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import { HOME_BY_ROLE, useAuth } from '../../context/AuthContext.jsx';
import { cn } from '../../utils/format.js';

export const Wordmark = ({ className }) => (
  <Link to="/" className={cn('font-display text-2xl tracking-[0.18em] text-paper', className)} aria-label="DineVerse home">
    DINE<span className="text-gold">VERSE</span>
  </Link>
);

const LINKS = [
  { to: '/restaurants', label: 'Discover' },
  { to: '/#experiences', label: 'Experiences' },
  { to: '/#how-it-works', label: 'How It Works' },
  { to: '/register?type=owner', label: 'For Restaurants' },
];

export default function Navbar() {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const overHero = pathname === '/' && !scrolled && !open;

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  useEffect(() => setOpen(false), [pathname]);
  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => e.key === 'Escape' && setOpen(false);
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open]);

  const signOut = async () => {
    await logout();
    navigate('/');
  };

  return (
    <header className={cn('fixed inset-x-0 top-0 z-50 transition-colors duration-300', overHero ? 'bg-gradient-to-b from-black/70 to-transparent' : 'border-b border-line bg-ink/95 backdrop-blur')}>
      <div className="container-x flex h-16 items-center justify-between">
        <Wordmark />
        <nav aria-label="Primary" className="hidden items-center gap-8 lg:flex">
          {LINKS.map((l) => (
            <NavLink key={l.label} to={l.to} className={({ isActive }) => cn('text-sm transition hover:text-champagne', isActive && l.to === '/restaurants' ? 'text-champagne' : 'text-paper-2')}>
              {l.label}
            </NavLink>
          ))}
        </nav>
        <div className="hidden items-center gap-3 lg:flex">
          {user ? (
            <>
              <Link to={HOME_BY_ROLE[user.role]} className="btn-outline btn-sm">
                My dashboard
              </Link>
              <button onClick={signOut} className="btn-ghost btn-sm">
                Sign out
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className="btn-ghost btn-sm">
                Login
              </Link>
              <Link to="/register" className="btn-primary btn-sm">
                Get Started
              </Link>
            </>
          )}
        </div>
        <button className="rounded-md p-2 text-paper lg:hidden" aria-label={open ? 'Close menu' : 'Open menu'} aria-expanded={open} aria-controls="mobile-nav" onClick={() => setOpen((o) => !o)}>
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>
      {open && (
        <nav id="mobile-nav" aria-label="Mobile" className="border-t border-line bg-ink px-4 pb-6 pt-3 lg:hidden">
          <ul className="flex flex-col">
            {LINKS.map((l) => (
              <li key={l.label}>
                <Link to={l.to} className="block py-3 text-lg text-paper">
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
          <div className="mt-4 flex gap-3">
            {user ? (
              <>
                <Link to={HOME_BY_ROLE[user.role]} className="btn-outline flex-1">
                  My dashboard
                </Link>
                <button onClick={signOut} className="btn-ghost flex-1">
                  Sign out
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="btn-outline flex-1">
                  Login
                </Link>
                <Link to="/register" className="btn-primary flex-1">
                  Get Started
                </Link>
              </>
            )}
          </div>
        </nav>
      )}
    </header>
  );
}
