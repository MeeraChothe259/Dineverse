import { Link } from 'react-router-dom';
import { Wordmark } from './Navbar.jsx';

const COLS = [
  { title: 'Discover', links: [['Restaurants', '/restaurants'], ['3D seating demo', '/restaurants'], ['Experiences', '/#experiences'], ['How it works', '/#how-it-works']] },
  { title: 'Partners', links: [['Partner with DineVerse', '/register?type=owner'], ['Restaurant login', '/login']] },
  { title: 'Support', links: [['About', '/about'], ['Contact', '/contact'], ['Forgot password', '/forgot-password']] },
  { title: 'Legal', links: [['Privacy', '/privacy'], ['Terms', '/terms']] },
];

export default function Footer() {
  return (
    <footer className="mt-24 border-t border-line bg-ink-2">
      <div className="container-x grid gap-10 py-14 md:grid-cols-[1.4fr_repeat(4,1fr)]">
        <div>
          <Wordmark />
          <p className="mt-3 max-w-xs text-sm text-paper-2">Dining, Reimagined. Explore the room, choose your table, reserve.</p>
        </div>
        {COLS.map((c) => (
          <nav key={c.title} aria-label={c.title}>
            <h2 className="font-sans text-xs font-medium uppercase tracking-[0.2em] text-gold">{c.title}</h2>
            <ul className="mt-4 space-y-2.5">
              {c.links.map(([label, to]) => (
                <li key={label}>
                  <Link to={to} className="text-sm text-paper-2 hover:text-champagne">
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>
        ))}
      </div>
      <div className="border-t border-line">
        <p className="container-x py-5 text-xs text-paper-2">
          © {new Date().getFullYear()} DineVerse. This is a demo build: all restaurants, ratings, reviews and statistics are fictional sample content and no email or SMS is sent.
        </p>
      </div>
    </footer>
  );
}
