import { useEffect, useState } from 'react';
import { Link, NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import {
  BarChart3, CalendarCheck, CalendarDays, Heart, LayoutDashboard, LayoutGrid, LogOut, Menu, QrCode, ScanLine, Settings,
  ShieldCheck, Store, Users, UserPlus, Utensils, X, Armchair, UserRound, ScrollText, Footprints,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.jsx';
import { WorkplaceProvider, useWorkplace } from '../../context/WorkplaceContext.jsx';
import { Wordmark } from './Navbar.jsx';
import { cn } from '../../utils/format.js';

const NAV = {
  customer: () => [
    ['/customer/dashboard', 'Overview', LayoutDashboard],
    ['/customer/reservations', 'My reservations', CalendarDays],
    ['/customer/favorites', 'Favorites', Heart],
    ['/customer/profile', 'Profile', UserRound],
    ['/restaurants', 'Discover restaurants', Utensils],
  ],
  owner: (rid) => [
    ['/owner/dashboard', 'Overview', LayoutDashboard],
    ['/owner/restaurants', 'My Restaurants', Store],
    ['/owner/reservations', 'Reservations', CalendarCheck],
    [rid ? `/owner/restaurants/${rid}/floor-plan` : '/owner/restaurants', 'Floor Plan', LayoutGrid],
    [rid ? `/owner/restaurants/${rid}/tables` : '/owner/restaurants', 'Tables', Armchair],
    [rid ? `/owner/restaurants/${rid}/menu` : '/owner/restaurants', 'Menu Management', Utensils],
    ['/owner/staff', 'Staff', Users],
    ['/owner/analytics', 'Analytics', BarChart3],
    ['/owner/settings', 'Settings', Settings],
  ],
  staff: () => [
    ['/staff/dashboard', 'Today', LayoutDashboard],
    ['/staff/reservations', 'Reservations', CalendarCheck],
    ['/staff/check-in', 'Check-in scanner', ScanLine],
    ['/staff/walk-in', 'Walk-ins', Footprints],
    ['/staff/tables', 'Table status', Armchair],
  ],
  admin: () => [
    ['/admin/dashboard', 'Overview', LayoutDashboard],
    ['/admin/restaurants', 'Restaurants', Store],
    ['/admin/customers', 'Users', Users],
    ['/admin/reservations', 'Reservations', CalendarCheck],
    ['/admin/settings', 'Audit & settings', ScrollText],
  ],
};

function Switcher() {
  const { restaurants, currentId, select } = useWorkplace() || {};
  if (!restaurants || restaurants.length < 2) return null;
  return (
    <div className="px-3 pb-3">
      <label htmlFor="ws" className="label">
        Restaurant
      </label>
      <select id="ws" className="input" value={currentId || ''} onChange={(e) => select(e.target.value)}>
        {restaurants.map((r) => (
          <option key={r.id} value={r.id}>
            {r.name}
          </option>
        ))}
      </select>
    </div>
  );
}

function Shell({ role }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const wp = useWorkplace();
  const [open, setOpen] = useState(false);
  useEffect(() => setOpen(false), [pathname]);

  const items = NAV[role](wp?.currentId);
  const nav = (
    <>
      {(role === 'owner' || role === 'staff') && <Switcher />}
      <ul className="space-y-1 px-3">
        {items.map(([to, label, Icon]) => (
          <li key={label}>
            <NavLink
              to={to}
              end={to.split('/').length <= 3}
              className={({ isActive }) => cn('flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition', isActive ? 'bg-gold/10 text-champagne' : 'text-paper-2 hover:bg-ink-3 hover:text-paper')}
            >
              <Icon size={17} aria-hidden /> {label}
            </NavLink>
          </li>
        ))}
      </ul>
    </>
  );

  return (
    <div className="min-h-screen bg-ink lg:grid lg:grid-cols-[260px_1fr]">
      <aside className="hidden border-r border-line bg-ink-2 lg:flex lg:flex-col lg:py-6" aria-label="Dashboard navigation">
        <div className="px-6 pb-6">
          <Wordmark className="text-xl" />
          <p className="mt-1 text-xs uppercase tracking-[0.2em] text-gold">{role} area</p>
        </div>
        <div className="flex-1 overflow-y-auto">{nav}</div>
        <AccountBox user={user} onLogout={async () => { await logout(); navigate('/'); }} />
      </aside>

      <div className="flex min-w-0 flex-col">
        <header className="sticky top-0 z-40 flex h-14 items-center justify-between border-b border-line bg-ink/95 px-4 backdrop-blur lg:hidden">
          <Wordmark className="text-lg" />
          <button aria-label={open ? 'Close menu' : 'Open menu'} aria-expanded={open} onClick={() => setOpen((o) => !o)} className="rounded-md p-2">
            {open ? <X size={22} /> : <Menu size={22} />}
          </button>
        </header>
        {open && (
          <div className="border-b border-line bg-ink-2 pb-4 pt-3 lg:hidden">
            {nav}
            <AccountBox user={user} onLogout={async () => { await logout(); navigate('/'); }} />
          </div>
        )}
        <main id="main" className="mx-auto w-full max-w-7xl flex-1 px-4 py-8 sm:px-8 sm:py-10">
          {role === 'staff' && wp && !wp.loading && !wp.restaurants.length ? (
            <div className="card p-8 text-center">
              <ShieldCheck className="mx-auto mb-3 text-gold" />
              <h1 className="text-3xl">No restaurant assigned yet</h1>
              <p className="mt-2 text-sm text-paper-2">Ask a restaurant owner to add you from their Staff page.</p>
            </div>
          ) : (
            <Outlet />
          )}
        </main>
      </div>
    </div>
  );
}

function AccountBox({ user, onLogout }) {
  return (
    <div className="mt-4 border-t border-line px-6 pt-4">
      <p className="truncate text-sm text-paper">{user?.name}</p>
      <p className="truncate text-xs text-paper-2">{user?.email}</p>
      <div className="mt-3 flex gap-2">
        <Link to="/" className="btn-outline btn-sm flex-1">
          Site
        </Link>
        <button onClick={onLogout} className="btn-ghost btn-sm flex-1">
          <LogOut size={14} aria-hidden /> Sign out
        </button>
      </div>
    </div>
  );
}

export default function DashboardLayout({ role }) {
  return role === 'owner' || role === 'staff' ? (
    <WorkplaceProvider>
      <Shell role={role} />
    </WorkplaceProvider>
  ) : (
    <Shell role={role} />
  );
}

export { QrCode, UserPlus };
