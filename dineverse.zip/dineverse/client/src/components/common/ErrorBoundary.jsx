import { Component } from 'react';

/** Catches render errors (e.g. WebGL failing inside the 3D scene) and renders `fallback`. */
export default class ErrorBoundary extends Component {
  state = { error: null };
  static getDerivedStateFromError(error) {
    return { error };
  }
  componentDidCatch(error) {
    this.props.onError?.(error);
  }
  render() {
    if (this.state.error) return typeof this.props.fallback === 'function' ? this.props.fallback(this.state.error) : this.props.fallback ?? null;
    return this.props.children;
  }
}
