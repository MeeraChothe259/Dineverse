import { forwardRef, useEffect, useId, useRef } from 'react';
import { createPortal } from 'react-dom';
import { Loader2, X, TriangleAlert, Inbox, FlaskConical } from 'lucide-react';
import { cn, humanize } from '../../utils/format.js';

export function Button({ variant = 'primary', size, loading, children, className, disabled, ...rest }) {
  const base = { primary: 'btn-primary', outline: 'btn-outline', ghost: 'btn-ghost', danger: 'btn-danger' }[variant];
  return (
    <button className={cn(base, size === 'sm' && 'btn-sm', className)} disabled={disabled || loading} aria-busy={loading || undefined} {...rest}>
      {loading && <Loader2 size={16} className="animate-spin" aria-hidden />}
      {children}
    </button>
  );
}

export const Spinner = ({ label = 'Loading' }) => (
  <div role="status" className="flex items-center justify-center gap-2 py-16 text-paper-2">
    <Loader2 className="animate-spin" size={20} aria-hidden />
    <span className="text-sm">{label}…</span>
  </div>
);

/** Labelled form control with error text wired up for assistive tech. */
export const Field = forwardRef(function Field({ label, error, hint, as = 'input', className, children, id, ...rest }, ref) {
  const auto = useId();
  const fid = id || auto;
  const Tag = as;
  return (
    <div className={className}>
      {label && (
        <label htmlFor={fid} className="label">
          {label}
        </label>
      )}
      <Tag
        id={fid}
        ref={ref}
        className={cn('input', error && 'input-error', as === 'select' && 'pr-8')}
        aria-invalid={error ? true : undefined}
        aria-describedby={error ? `${fid}-err` : hint ? `${fid}-hint` : undefined}
        {...rest}
      >
        {children}
      </Tag>
      {hint && !error && (
        <p id={`${fid}-hint`} className="mt-1 text-xs text-paper-2">
          {hint}
        </p>
      )}
      {error && (
        <p id={`${fid}-err`} role="alert" className="field-error">
          {error}
        </p>
      )}
    </div>
  );
});

/** Accessible modal dialog: focus moves in, Escape closes, focus returns on close, background scroll locked. */
export function Modal({ open, onClose, title, children, footer, size = 'md' }) {
  const ref = useRef(null);
  const titleId = useId();
  useEffect(() => {
    if (!open) return undefined;
    const prev = document.activeElement;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const el = ref.current;
    const focusables = () => el?.querySelectorAll('a[href],button:not([disabled]),input:not([disabled]),select,textarea,[tabindex]:not([tabindex="-1"])') || [];
    (focusables()[0] || el)?.focus();
    const onKey = (e) => {
      if (e.key === 'Escape') onClose?.();
      if (e.key === 'Tab') {
        const f = [...focusables()];
        if (!f.length) return;
        const first = f[0];
        const last = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = prevOverflow;
      prev?.focus?.();
    };
  }, [open, onClose]);
  if (!open) return null;
  const width = { sm: 'max-w-md', md: 'max-w-lg', lg: 'max-w-2xl' }[size];
  return createPortal(
    <div className="fixed inset-0 z-[90] flex items-end justify-center sm:items-center sm:p-4">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} aria-hidden />
      <div ref={ref} role="dialog" aria-modal="true" aria-labelledby={titleId} tabIndex={-1} className={cn('relative max-h-[92vh] w-full overflow-y-auto rounded-t-2xl border border-line bg-ink-2 p-6 shadow-soft sm:rounded-2xl', width)}>
        <div className="mb-4 flex items-start justify-between gap-4">
          <h2 id={titleId} className="text-2xl text-paper">
            {title}
          </h2>
          <button onClick={onClose} aria-label="Close dialog" className="rounded-md p-1 text-paper-2 hover:bg-ink-3 hover:text-paper">
            <X size={18} />
          </button>
        </div>
        <div>{children}</div>
        {footer && <div className="mt-6 flex flex-wrap justify-end gap-3">{footer}</div>}
      </div>
    </div>,
    document.body
  );
}

export function ConfirmDialog({ open, title, message, confirmLabel = 'Confirm', danger, loading, onConfirm, onClose }) {
  return (
    <Modal
      open={open}
      onClose={onClose}
      title={title}
      size="sm"
      footer={
        <>
          <Button variant="ghost" onClick={onClose} disabled={loading}>
            Keep it
          </Button>
          <Button variant={danger ? 'danger' : 'primary'} onClick={onConfirm} loading={loading}>
            {confirmLabel}
          </Button>
        </>
      }
    >
      <p className="text-sm text-paper-2">{message}</p>
    </Modal>
  );
}

export const Skeleton = ({ className }) => <div aria-hidden className={cn('skeleton rounded-lg', className)} />;

export function EmptyState({ icon: Icon = Inbox, title, message, action }) {
  return (
    <div className="flex flex-col items-center rounded-xl border border-dashed border-line px-6 py-14 text-center">
      <Icon size={28} className="mb-3 text-gold" aria-hidden />
      <h3 className="text-xl text-paper">{title}</h3>
      {message && <p className="mt-1 max-w-md text-sm text-paper-2">{message}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function ErrorState({ message, onRetry }) {
  return (
    <div role="alert" className="flex flex-col items-center rounded-xl border border-bad/40 bg-bad/5 px-6 py-12 text-center">
      <TriangleAlert size={28} className="mb-3 text-bad" aria-hidden />
      <h3 className="text-xl text-paper">We hit a snag</h3>
      <p className="mt-1 max-w-md text-sm text-paper-2">{message || 'Something went wrong.'}</p>
      {onRetry && (
        <Button variant="outline" className="mt-5" onClick={() => onRetry()}>
          Try again
        </Button>
      )}
    </div>
  );
}

const STATUS_TONE = {
  confirmed: 'border-ok/40 text-ok bg-ok/10',
  checked_in: 'border-champagne/40 text-champagne bg-champagne/10',
  seated: 'border-champagne/40 text-champagne bg-champagne/10',
  completed: 'border-line text-paper-2',
  cancelled: 'border-bad/40 text-bad bg-bad/10',
  no_show: 'border-bad/40 text-bad bg-bad/10',
  pending: 'border-gold/40 text-gold bg-gold/10',
  active: 'border-ok/40 text-ok bg-ok/10',
  suspended: 'border-bad/40 text-bad bg-bad/10',
  rejected: 'border-bad/40 text-bad bg-bad/10',
  available: 'border-ok/40 text-ok bg-ok/10',
  reserved: 'border-gold/40 text-gold bg-gold/10',
  occupied: 'border-champagne/40 text-champagne bg-champagne/10',
  cleaning: 'border-line text-paper-2',
  out_of_service: 'border-off text-off',
};
export const StatusBadge = ({ status }) => <span className={cn('badge', STATUS_TONE[status] || 'border-line text-paper-2')}>{humanize(status)}</span>;

/** Marks fictional / simulated content so it is never mistaken for a real business. */
export const DemoBadge = ({ label = 'Demo content', className }) => (
  <span className={cn('badge border-gold/40 bg-gold/10 text-gold', className)} title="This is fictional sample data created for the DineVerse demo.">
    <FlaskConical size={12} aria-hidden /> {label}
  </span>
);

export function PageHeader({ title, subtitle, actions }) {
  return (
    <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
      <div>
        <h1 className="text-4xl text-paper">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-paper-2">{subtitle}</p>}
      </div>
      {actions && <div className="flex flex-wrap gap-3">{actions}</div>}
    </div>
  );
}

export const StatCard = ({ label, value, hint, icon: Icon }) => (
  <div className="card p-5">
    <div className="flex items-center justify-between text-paper-2">
      <span className="text-xs uppercase tracking-wider">{label}</span>
      {Icon && <Icon size={16} aria-hidden className="text-gold" />}
    </div>
    <div className="mt-2 font-display text-4xl text-paper">{value}</div>
    {hint && <div className="mt-1 text-xs text-paper-2">{hint}</div>}
  </div>
);

export function Pagination({ meta, onPage }) {
  if (!meta || meta.pages <= 1) return null;
  return (
    <nav aria-label="Pagination" className="mt-8 flex items-center justify-center gap-3">
      <Button variant="outline" size="sm" disabled={meta.page <= 1} onClick={() => onPage(meta.page - 1)}>
        Previous
      </Button>
      <span className="text-sm text-paper-2" aria-live="polite">
        Page {meta.page} of {meta.pages}
      </span>
      <Button variant="outline" size="sm" disabled={meta.page >= meta.pages} onClick={() => onPage(meta.page + 1)}>
        Next
      </Button>
    </nav>
  );
}

/** Simple responsive table. `columns`: [{ key, header, render? }] */
export function DataTable({ columns, rows, rowKey = 'id', empty }) {
  if (!rows?.length) return empty || null;
  return (
    <div className="overflow-x-auto rounded-xl border border-line">
      <table className="w-full min-w-[640px] border-collapse">
        <thead className="border-b border-line bg-ink-2">
          <tr>
            {columns.map((c) => (
              <th key={c.key} scope="col" className="th">
                {c.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-line">
          {rows.map((r) => (
            <tr key={r[rowKey]} className="hover:bg-ink-3/60">
              {columns.map((c) => (
                <td key={c.key} className="td">
                  {c.render ? c.render(r) : r[c.key]}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export const LiveBadge = ({ connected }) => (
  <span className={cn('badge', connected ? 'border-ok/40 text-ok' : 'border-line text-paper-2')} role="status">
    <span className={cn('h-1.5 w-1.5 rounded-full', connected ? 'bg-ok' : 'bg-off')} aria-hidden />
    {connected ? 'Live updates on' : 'Live updates off · refreshing every 30s'}
  </span>
);
