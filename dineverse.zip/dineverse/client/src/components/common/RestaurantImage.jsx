import { useState } from 'react';
import { gradientFor } from '../../utils/assets.js';
import { cn } from '../../utils/format.js';

/**
 * Shows a restaurant image, or a generated editorial placeholder when none is configured or the
 * image fails to load. Never renders a broken-image icon.
 */
export default function RestaurantImage({ image, name = '', seed, className, rounded = 'rounded-xl' }) {
  const [failed, setFailed] = useState(false);
  const [from, via, accent] = gradientFor(seed || name);
  if (image?.url && !failed) {
    return (
      <img
        src={image.url}
        alt={image.alt || `${name} interior`}
        loading="lazy"
        onError={() => setFailed(true)}
        className={cn('h-full w-full object-cover', rounded, className)}
      />
    );
  }
  return (
    <div
      role="img"
      aria-label={`${name}: illustrative placeholder, no photo supplied`}
      className={cn('relative flex h-full w-full items-center justify-center overflow-hidden', rounded, className)}
      style={{ background: `radial-gradient(circle at 70% 20%, ${accent}33 0%, transparent 55%), linear-gradient(135deg, ${from}, ${via})` }}
    >
      <svg viewBox="0 0 200 120" className="absolute inset-0 h-full w-full opacity-40" aria-hidden preserveAspectRatio="xMidYMid slice">
        {[40, 100, 160].map((x) => (
          <g key={x} fill="none" stroke={accent} strokeWidth="0.8">
            <circle cx={x} cy="60" r="16" />
            <circle cx={x} cy="60" r="26" strokeDasharray="2 3" />
          </g>
        ))}
      </svg>
      <span className="relative px-4 text-center font-display text-2xl text-paper/80">{name}</span>
    </div>
  );
}
