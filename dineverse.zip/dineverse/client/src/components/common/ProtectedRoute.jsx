import { Link, Navigate, Outlet, useLocation } from 'react-router-dom';
import { ShieldAlert } from 'lucide-react';
import { HOME_BY_ROLE, useAuth } from '../../context/AuthContext.jsx';
import { Spinner } from './ui.jsx';

export function AccessDenied({ role }) {
  const { user } = useAuth();
  return (
    <div className="container-x flex min-h-[60vh] flex-col items-center justify-center py-20 text-center">
      <ShieldAlert size={36} className="mb-4 text-gold" aria-hidden />
      <h1 className="text-4xl">Access denied</h1>
      <p className="mt-2 max-w-md text-paper-2">
        Your account ({user?.role}) doesn't have permission to view this area{role ? ` (requires ${role})` : ''}.
      </p>
      <Link className="btn-primary mt-6" to={user ? HOME_BY_ROLE[user.role] : '/'}>
        Go to my dashboard
      </Link>
    </div>
  );
}

/** Route guard for UX only; every endpoint re-checks permissions on the server. */
export default function ProtectedRoute({ roles }) {
  const { user, ready } = useAuth();
  const location = useLocation();
  if (!ready) return <Spinner label="Checking your session" />;
  if (!user) return <Navigate to="/login" replace state={{ from: location.pathname + location.search }} />;
  if (roles && !roles.includes(user.role)) return <AccessDenied role={roles.join(' / ')} />;
  return <Outlet />;
}
