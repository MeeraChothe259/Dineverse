import { useState } from 'react';
import { CalendarX } from 'lucide-react';
import { Button, ConfirmDialog, DataTable, EmptyState, StatusBadge } from '../common/ui.jsx';
import { useToast } from '../../context/ToastContext.jsx';
import { errorMessage, patch, post } from '../../services/api.js';
import { fmtDate, fmtTime } from '../../utils/format.js';

/**
 * Operational reservation list with lifecycle actions (check in, seat, complete, no-show, cancel).
 * All transitions are validated by the server; this only offers the sensible next step.
 */
export default function ReservationsTable({ rows, tz, onChanged, showDate = false, showRestaurant = false, emptyText = 'No reservations match.' }) {
  const toast = useToast();
  const [busy, setBusy] = useState(null);
  const [confirm, setConfirm] = useState(null);

  const run = async (r, action) => {
    setBusy(r.id);
    try {
      if (action === 'checkin') await post('/checkin/confirm', { reference: r.bookingReference });
      else await patch(`/staff/reservations/${r.id}/status`, { status: action });
      toast.success('Reservation updated.');
      onChanged?.();
    } catch (e) {
      toast.error(errorMessage(e));
      onChanged?.(); // state may have changed elsewhere: refresh so the UI stays consistent
    } finally {
      setBusy(null);
      setConfirm(null);
    }
  };

  const actions = (r) => {
    const b = (label, action, variant = 'outline', ask = false) => (
      <Button key={action} size="sm" variant={variant} loading={busy === r.id} onClick={() => (ask ? setConfirm({ r, action, label }) : run(r, action))}>
        {label}
      </Button>
    );
    if (r.status === 'confirmed') return [b('Check in', 'checkin', 'primary'), b('No-show', 'no_show', 'ghost', true), b('Cancel', 'cancelled', 'danger', true)];
    if (r.status === 'checked_in') return [b('Seat', 'seated', 'primary')];
    if (r.status === 'seated') return [b('Complete', 'completed', 'primary')];
    return null;
  };

  const columns = [
    { key: 'time', header: showDate ? 'When' : 'Time', render: (r) => { const z = tz || r.restaurant?.timezone; return <span className="whitespace-nowrap">{showDate && `${fmtDate(r.startAt, z)} · `}{fmtTime(r.startAt, z)}</span>; } },
    ...(showRestaurant ? [{ key: 'restaurant', header: 'Restaurant', render: (r) => r.restaurant?.name }] : []),
    { key: 'bookingReference', header: 'Reference', render: (r) => <span className="font-mono text-xs">{r.bookingReference}</span> },
    { key: 'customerName', header: 'Guest', render: (r) => <div><p>{r.customerName}</p>{r.customerPhone && <p className="text-xs text-paper-2">{r.customerPhone}</p>}{r.specialRequests && <p className="text-xs text-gold">“{r.specialRequests}”</p>}</div> },
    { key: 'guestCount', header: 'Party' },
    { key: 'table', header: 'Table', render: (r) => r.table?.displayName },
    { key: 'source', header: 'Source', render: (r) => (r.source === 'walk_in' ? 'Walk-in' : 'Online') },
    { key: 'status', header: 'Status', render: (r) => <StatusBadge status={r.status} /> },
    { key: 'actions', header: 'Actions', render: (r) => <div className="flex flex-wrap gap-2">{actions(r)}</div> },
  ];

  return (
    <>
      <DataTable columns={columns} rows={rows} empty={<EmptyState icon={CalendarX} title={emptyText} />} />
      <ConfirmDialog
        open={!!confirm}
        danger
        loading={!!busy}
        title={`${confirm?.label}?`}
        confirmLabel={confirm?.label}
        message={confirm ? `${confirm.r.customerName} · ${confirm.r.bookingReference}. This frees up the table.` : ''}
        onConfirm={() => run(confirm.r, confirm.action)}
        onClose={() => setConfirm(null)}
      />
    </>
  );
}
