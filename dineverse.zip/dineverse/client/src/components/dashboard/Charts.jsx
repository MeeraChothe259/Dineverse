import { Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Legend, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { CalendarCheck, Percent, Users, XCircle, Footprints, Armchair } from 'lucide-react';
import { DemoBadge, StatCard } from '../common/ui.jsx';
import { humanize } from '../../utils/format.js';

const GOLD = '#C9A76A';
const CHAMP = '#E6D2A5';
const OK = '#70B58A';
const BAD = '#C76D6D';
const GREY = '#66666A';
const STATUS_COLORS = { confirmed: OK, completed: CHAMP, checked_in: GOLD, seated: GOLD, cancelled: BAD, no_show: '#a15555', pending: GREY };

const axis = { stroke: '#77736D', fontSize: 11, tickLine: false, axisLine: { stroke: '#302C26' } };
const tip = { contentStyle: { background: '#19191C', border: '1px solid #302C26', borderRadius: 8, color: '#F5F1E9', fontSize: 12 }, labelStyle: { color: '#AAA6A0' }, cursor: { fill: '#ffffff10' } };

function Box({ title, children, note }) {
  return (
    <section className="card p-5">
      <h3 className="mb-4 text-xl">{title}</h3>
      <div className="h-64">{children}</div>
      {note && <p className="mt-2 text-xs text-paper-2">{note}</p>}
    </section>
  );
}

export function MetricCards({ totals }) {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      <StatCard label="Bookings (30d)" value={totals.bookings} icon={CalendarCheck} />
      <StatCard label="Upcoming" value={totals.upcoming} hint={`${totals.confirmed} confirmed`} icon={CalendarCheck} />
      <StatCard label="Cancellation rate" value={`${totals.cancellationRate}%`} hint={`${totals.cancelled} cancelled · ${totals.noShow} no-show`} icon={XCircle} />
      <StatCard label="Occupancy" value={`${totals.occupancyPct}%`} hint="reserved table-time vs opening time" icon={Percent} />
      <StatCard label="Guests" value={totals.guests} hint="excluding cancelled" icon={Users} />
      <StatCard label="Online" value={totals.online} icon={CalendarCheck} />
      <StatCard label="Walk-in" value={totals.walkIn} icon={Footprints} />
      <StatCard label="Completed / seated" value={totals.completed} icon={Armchair} />
    </div>
  );
}

export function AnalyticsCharts({ data }) {
  const status = data.byStatus.map((s) => ({ ...s, name: humanize(s.status) }));
  const source = data.bySource.map((s) => ({ name: s.source === 'walk_in' ? 'Walk-in' : 'Online', value: s.count }));
  return (
    <div className="space-y-6">
      {data.containsDemoData && <DemoBadge label="Includes seeded demo data. Statistics are simulated." />}
      <div className="grid gap-6 lg:grid-cols-2">
        <Box title="Reservations over time" note="Count of non-cancelled bookings per day, including the next 14 days.">
          <ResponsiveContainer>
            <AreaChart data={data.byDay} margin={{ left: -20, right: 8 }}>
              <defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={GOLD} stopOpacity={0.5} /><stop offset="100%" stopColor={GOLD} stopOpacity={0} /></linearGradient></defs>
              <CartesianGrid stroke="#302C26" vertical={false} />
              <XAxis dataKey="date" {...axis} tickFormatter={(d) => d.slice(5)} minTickGap={24} />
              <YAxis {...axis} allowDecimals={false} />
              <Tooltip {...tip} />
              <Area type="monotone" dataKey="count" name="Bookings" stroke={GOLD} fill="url(#g)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </Box>
        <Box title="Bookings by weekday">
          <ResponsiveContainer>
            <BarChart data={data.byWeekday} margin={{ left: -20, right: 8 }}>
              <CartesianGrid stroke="#302C26" vertical={false} />
              <XAxis dataKey="weekday" {...axis} /><YAxis {...axis} allowDecimals={false} /><Tooltip {...tip} />
              <Bar dataKey="count" name="Bookings" fill={CHAMP} radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Box>
        <Box title="Status breakdown">
          <ResponsiveContainer>
            <PieChart>
              <Pie data={status} dataKey="count" nameKey="name" innerRadius={55} outerRadius={85} paddingAngle={2} label={({ name, value }) => `${name} ${value}`} labelLine={false}>
                {status.map((s) => <Cell key={s.status} fill={STATUS_COLORS[s.status] || GREY} stroke="#0B0B0C" />)}
              </Pie>
              <Tooltip {...tip} />
            </PieChart>
          </ResponsiveContainer>
        </Box>
        <Box title="Occupancy by hour" note="Share of table-time reserved in each local hour.">
          <ResponsiveContainer>
            <BarChart data={data.byHour} margin={{ left: -20, right: 8 }}>
              <CartesianGrid stroke="#302C26" vertical={false} />
              <XAxis dataKey="label" {...axis} /><YAxis {...axis} unit="%" domain={[0, 100]} /><Tooltip {...tip} formatter={(v) => `${v}%`} />
              <Bar dataKey="occupancyPct" name="Occupancy" fill={GOLD} radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Box>
        <Box title="Online vs walk-in">
          <ResponsiveContainer>
            <PieChart>
              <Pie data={source} dataKey="value" nameKey="name" outerRadius={85} label={({ name, value }) => `${name} ${value}`}>
                {source.map((s, i) => <Cell key={s.name} fill={i ? OK : GOLD} stroke="#0B0B0C" />)}
              </Pie>
              <Legend wrapperStyle={{ fontSize: 12, color: '#AAA6A0' }} /><Tooltip {...tip} />
            </PieChart>
          </ResponsiveContainer>
        </Box>
      </div>
    </div>
  );
}
