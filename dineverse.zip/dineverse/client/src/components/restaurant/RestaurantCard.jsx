import { Link } from 'react-router-dom';
import { MapPin, Star } from 'lucide-react';
import RestaurantImage from '../common/RestaurantImage.jsx';
import { DemoBadge } from '../common/ui.jsx';
import { priceLabel } from '../../utils/format.js';

export function Rating({ rating }) {
  if (!rating) return null;
  return (
    <span className="inline-flex items-center gap-1 text-sm text-paper" title={rating.isDemo ? 'Simulated demo rating, not from real reviews' : undefined}>
      <Star size={14} className="fill-gold text-gold" aria-hidden />
      {rating.value.toFixed(1)}
      <span className="text-xs text-paper-2">{rating.isDemo ? '(demo rating)' : `(${rating.count})`}</span>
    </span>
  );
}

export default function RestaurantCard({ restaurant: r, query = '' }) {
  return (
    <article className="group card overflow-hidden transition hover:border-gold/50">
      <Link to={`/restaurants/${r.slug}${query}`} className="block" aria-label={`View ${r.name}`}>
        <div className="relative aspect-[4/3] overflow-hidden">
          <div className="h-full w-full transition duration-700 group-hover:scale-105">
            <RestaurantImage image={r.images?.[0]} name={r.name} seed={r.slug} rounded="" />
          </div>
          {r.isDemo && <DemoBadge className="absolute left-3 top-3 bg-ink/80" label="Demo venue" />}
        </div>
        <div className="p-5">
          <div className="flex items-start justify-between gap-3">
            <h3 className="text-2xl leading-tight text-paper">{r.name}</h3>
            <span className="shrink-0 text-sm text-gold" aria-label={`Price range ${r.priceRange} of 4`}>
              {priceLabel(r.priceRange)}
            </span>
          </div>
          <p className="mt-1 text-sm text-paper-2">{r.cuisineTypes?.join(' · ')}</p>
          <div className="mt-4 flex items-center justify-between">
            <span className="inline-flex items-center gap-1 text-xs text-paper-2">
              <MapPin size={13} aria-hidden /> {r.address?.city}
            </span>
            <Rating rating={r.rating} />
          </div>
        </div>
      </Link>
    </article>
  );
}

export function RestaurantCardSkeleton() {
  return (
    <div className="card overflow-hidden" aria-hidden>
      <div className="skeleton aspect-[4/3]" />
      <div className="space-y-3 p-5">
        <div className="skeleton h-6 w-2/3 rounded" />
        <div className="skeleton h-4 w-1/2 rounded" />
        <div className="skeleton h-4 w-1/3 rounded" />
      </div>
    </div>
  );
}
