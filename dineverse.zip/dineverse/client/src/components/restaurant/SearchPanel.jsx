import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search } from 'lucide-react';
import { Button, Field } from '../common/ui.jsx';
import { dateInTz } from '../../utils/format.js';
import { useAsync } from '../../hooks/useAsync.js';
import { get } from '../../services/api.js';

const TIMES = Array.from({ length: 28 }, (_, i) => {
  const mins = 11 * 60 + i * 30;
  return `${String(Math.floor(mins / 60) % 24).padStart(2, '0')}:${mins % 60 === 0 ? '00' : '30'}`;
});

export function validateSearch(v) {
  const e = {};
  if (v.date && v.date < dateInTz(0)) e.date = 'Pick today or a future date';
  if (v.time && !v.date) e.date = 'Choose a date to search by time';
  if (v.date && !v.time) e.time = 'Choose a time';
  if (v.guests < 1 || v.guests > 20) e.guests = 'Between 1 and 20 guests';
  return e;
}

export function buildQuery(v) {
  const p = new URLSearchParams();
  if (v.city) p.set('city', v.city);
  if (v.cuisine) p.set('cuisine', v.cuisine);
  if (v.date) p.set('date', v.date);
  if (v.time) p.set('time', v.time);
  if (v.date && v.time) p.set('guests', String(v.guests));
  return p.toString();
}

/** Home-page search. Every control is real: values are validated and carried to /restaurants as query params. */
export default function SearchPanel({ className = '' }) {
  const navigate = useNavigate();
  const { data } = useAsync(() => get('/restaurants/facets'), []);
  const facets = data?.data;
  const [v, setV] = useState({ city: '', cuisine: '', date: '', time: '', guests: 2 });
  const [errors, setErrors] = useState({});
  const set = (patch) => setV((s) => ({ ...s, ...patch }));

  const submit = (e) => {
    e.preventDefault();
    const errs = validateSearch(v);
    setErrors(errs);
    if (Object.keys(errs).length) return;
    navigate(`/restaurants?${buildQuery(v)}`);
  };

  return (
    <form onSubmit={submit} noValidate aria-label="Search restaurants" className={`rounded-2xl border border-line bg-ink/85 p-4 shadow-soft backdrop-blur sm:p-5 ${className}`}>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-[1.2fr_1.2fr_1fr_1fr_.8fr_auto] lg:items-end">
        <Field label="Location" as="select" value={v.city} onChange={(e) => set({ city: e.target.value })}>
          <option value="">Any city</option>
          {facets?.cities.map((c) => <option key={c}>{c}</option>)}
        </Field>
        <Field label="Cuisine" as="select" value={v.cuisine} onChange={(e) => set({ cuisine: e.target.value })}>
          <option value="">Any cuisine</option>
          {facets?.cuisines.map((c) => <option key={c}>{c}</option>)}
        </Field>
        <Field label="Date" type="date" min={dateInTz(0)} value={v.date} error={errors.date} onChange={(e) => set({ date: e.target.value })} />
        <Field label="Time" as="select" value={v.time} error={errors.time} onChange={(e) => set({ time: e.target.value })}>
          <option value="">Any time</option>
          {TIMES.map((t) => <option key={t} value={t}>{new Date(`2000-01-01T${t}`).toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit' })}</option>)}
        </Field>
        <Field label="Guests" type="number" min={1} max={20} value={v.guests} error={errors.guests} onChange={(e) => set({ guests: Number(e.target.value) })} />
        <Button type="submit" className="h-[42px] w-full lg:w-auto">
          <Search size={16} aria-hidden /> Search
        </Button>
      </div>
    </form>
  );
}
