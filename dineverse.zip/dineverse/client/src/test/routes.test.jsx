import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import ProtectedRoute from '../components/common/ProtectedRoute.jsx';

let auth;
vi.mock('../context/AuthContext.jsx', () => ({
  useAuth: () => auth,
  HOME_BY_ROLE: { customer: '/customer/dashboard', owner: '/owner/dashboard', staff: '/staff/dashboard', admin: '/admin/dashboard' },
}));

const renderAt = (path) =>
  render(
    <MemoryRouter initialEntries={[path]}>
      <Routes>
        <Route path="/login" element={<p>login page</p>} />
        <Route path="/owner" element={<ProtectedRoute roles={['owner']} />}>
          <Route path="dashboard" element={<p>owner dashboard</p>} />
        </Route>
      </Routes>
    </MemoryRouter>
  );

describe('ProtectedRoute', () => {
  beforeEach(() => { auth = { user: null, ready: true }; });

  it('redirects unauthenticated visitors to login', () => {
    renderAt('/owner/dashboard');
    expect(screen.getByText('login page')).toBeInTheDocument();
  });
  it('waits for the session check before deciding', () => {
    auth = { user: null, ready: false };
    renderAt('/owner/dashboard');
    expect(screen.getByRole('status')).toHaveTextContent(/checking your session/i);
  });
  it('shows an access-denied state to the wrong role', () => {
    auth = { user: { role: 'customer' }, ready: true };
    renderAt('/owner/dashboard');
    expect(screen.getByRole('heading', { name: /access denied/i })).toBeInTheDocument();
    expect(screen.queryByText('owner dashboard')).not.toBeInTheDocument();
  });
  it('renders the page for the right role', () => {
    auth = { user: { role: 'owner' }, ready: true };
    renderAt('/owner/dashboard');
    expect(screen.getByText('owner dashboard')).toBeInTheDocument();
  });
});
