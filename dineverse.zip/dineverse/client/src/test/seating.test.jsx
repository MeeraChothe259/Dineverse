import { describe, it, expect, vi } from 'vitest';
import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import SceneFallback from '../three/SceneFallback.jsx';
import { SeatingLegend } from '../components/reservation/SeatingExperience.jsx';
import { chairLayout } from '../three/Table3D.jsx';
import { STATE_META, describeTable, effectiveState } from '../three/tableState.js';

vi.mock('@react-three/drei', () => ({ Html: () => null }));

const layout = { width: 20, depth: 14 };
const tables = [
  { id: 'a', tableNumber: '1', displayName: 'Table 1', capacity: 2, shape: 'round', dimensions: { width: 1.2, depth: 1.2 }, position: { x: 4, y: 4 }, rotation: 0, state: 'available', selectable: true },
  { id: 'b', tableNumber: '2', displayName: 'Table 2', capacity: 4, shape: 'square', dimensions: { width: 1.1, depth: 1.1 }, position: { x: 9, y: 4 }, rotation: 0, state: 'unavailable', selectable: false },
  { id: 'c', tableNumber: '3', displayName: 'Table 3', capacity: 6, shape: 'rectangle', dimensions: { width: 2, depth: 1 }, position: { x: 14, y: 4 }, rotation: 0, state: 'disabled', selectable: false },
];

describe('2D seating plan (accessible fallback)', () => {
  it('lists every table with text labels, so colour is never the only signal', () => {
    render(<SceneFallback layout={layout} tables={tables} />);
    const list = screen.getByRole('list', { name: 'Tables' });
    expect(within(list).getByText(/Available/)).toBeInTheDocument();
    expect(within(list).getByText(/Booked/)).toBeInTheDocument();
    expect(within(list).getByText(/Out of service/)).toBeInTheDocument();
  });

  it('reports a pick for the clicked table and exposes the selected state', async () => {
    const onPick = vi.fn();
    const { rerender } = render(<SceneFallback layout={layout} tables={tables} onPick={onPick} />);
    await userEvent.click(within(screen.getByRole('list', { name: 'Tables' })).getByRole('button', { name: /Table 1/ }));
    expect(onPick).toHaveBeenCalledWith(expect.objectContaining({ id: 'a' }));
    rerender(<SceneFallback layout={layout} tables={tables} selectedId="a" onPick={onPick} />);
    expect(within(screen.getByRole('list', { name: 'Tables' })).getByRole('button', { name: /Table 1/ })).toHaveAttribute('aria-pressed', 'true');
  });

  it('works from the keyboard on the SVG map', async () => {
    const onPick = vi.fn();
    render(<SceneFallback layout={layout} tables={tables} onPick={onPick} />);
    const t = screen.getByRole('button', { name: 'Table 2, seats 4, booked' });
    t.focus();
    await userEvent.keyboard('{Enter}');
    expect(onPick).toHaveBeenCalledWith(expect.objectContaining({ id: 'b' }));
  });

  it('is inert in read-only mode', async () => {
    const onPick = vi.fn();
    render(<SceneFallback layout={layout} tables={tables} onPick={onPick} readOnly />);
    await userEvent.click(within(screen.getByRole('list', { name: 'Tables' })).getByText('Table 1'));
    expect(onPick).not.toHaveBeenCalled();
  });
});

describe('table state helpers and legend', () => {
  it('selected overrides the server state; others keep it', () => {
    expect(effectiveState(tables[0], 'a')).toBe('selected');
    expect(effectiveState(tables[1], 'a')).toBe('unavailable');
    expect(describeTable(tables[0], 'a')).toBe('Table 1, seats 2, selected');
  });
  it('uses the specified legend colours', () => {
    expect(STATE_META.available.color).toBe('#70B58A');
    expect(STATE_META.selected.color).toBe('#E6D2A5');
    expect(STATE_META.unavailable.color).toBe('#C76D6D');
    expect(STATE_META.disabled.color).toBe('#66666A');
  });
  it('renders a persistent legend with text for every state', () => {
    render(<SeatingLegend />);
    for (const t of [/Available/, /Selected/, /Booked/, /out of service/i]) expect(screen.getByText(t)).toBeInTheDocument();
  });
  it('places one chair per seat around a table', () => {
    expect(chairLayout('round', 6, 1.7, 1.7)).toHaveLength(6);
    expect(chairLayout('rectangle', 5, 2, 1)).toHaveLength(5);
  });
});
