import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter } from 'react-router-dom';
import Restaurants from '../pages/public/Restaurants.jsx';
import { EmptyState, ErrorState } from '../components/common/ui.jsx';

const get = vi.fn();
vi.mock('../services/api.js', () => ({ get: (...a) => get(...a), errorMessage: (e) => e?.message || 'Something went wrong' }));

const rest = (n, city = 'Mumbai') => ({ id: `r${n}`, name: `Venue ${n}`, slug: `venue-${n}`, cuisineTypes: ['North Indian'], priceRange: 3, address: { city }, images: [], isDemo: true, rating: { value: 4.5, count: 10, isDemo: true } });
const facets = { data: { cities: ['Mumbai', 'Chennai'], cuisines: ['North Indian'], experiences: ['Fine Dining'] } };

function setup(path = '/restaurants') {
  return render(<MemoryRouter initialEntries={[path]}><Restaurants /></MemoryRouter>);
}

describe('Restaurants discovery', () => {
  beforeEach(() => {
    get.mockReset();
    get.mockImplementation((url, params) => (url === '/restaurants/facets' ? Promise.resolve(facets) : Promise.resolve({ data: [rest(1), rest(2)], meta: { page: 1, limit: 9, total: 2, pages: 1 } })));
  });

  it('loads restaurants from the API and shows the result count with a demo label', async () => {
    setup();
    expect(await screen.findByText('Venue 1')).toBeInTheDocument();
    expect(screen.getByText('2 restaurants')).toBeInTheDocument();
    expect(screen.getAllByText(/demo venue/i).length).toBeGreaterThan(0);
  });

  it('sends URL filters to the backend (filters run on server data)', async () => {
    setup('/restaurants?city=Chennai&price=3');
    await screen.findByText('Venue 1');
    const call = get.mock.calls.find(([u]) => u === '/restaurants');
    expect(call[1]).toMatchObject({ city: 'Chennai', price: '3' });
  });

  it('re-queries when a filter changes', async () => {
    setup();
    await screen.findByText('Venue 1');
    await userEvent.selectOptions(screen.getAllByLabelText('City')[0], 'Chennai');
    await waitFor(() => expect(get.mock.calls.some(([u, p]) => u === '/restaurants' && p?.city === 'Chennai')).toBe(true));
  });

  it('shows an empty state with a clear-filters action when nothing matches', async () => {
    get.mockImplementation((url) => (url === '/restaurants/facets' ? Promise.resolve(facets) : Promise.resolve({ data: [], meta: { page: 1, limit: 9, total: 0, pages: 1 } })));
    setup('/restaurants?city=Nowhere');
    expect(await screen.findByText('No restaurants match')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /clear all filters/i })).toBeInTheDocument();
  });

  it('shows an error state with retry when the API fails', async () => {
    get.mockImplementation((url) => (url === '/restaurants/facets' ? Promise.resolve(facets) : Promise.reject(new Error('Network down'))));
    setup();
    expect(await screen.findByRole('alert')).toHaveTextContent('Network down');
    get.mockImplementation((url) => (url === '/restaurants/facets' ? Promise.resolve(facets) : Promise.resolve({ data: [rest(1)], meta: { page: 1, limit: 9, total: 1, pages: 1 } })));
    await userEvent.click(screen.getByRole('button', { name: /try again/i }));
    expect(await screen.findByText('Venue 1')).toBeInTheDocument();
  });
});

describe('shared states', () => {
  it('EmptyState and ErrorState render their messages and actions', async () => {
    const retry = vi.fn();
    render(<><EmptyState title="Nothing here" message="Try later" /><ErrorState message="Boom" onRetry={retry} /></>);
    expect(screen.getByText('Nothing here')).toBeInTheDocument();
    await userEvent.click(screen.getByRole('button', { name: /try again/i }));
    expect(retry).toHaveBeenCalled();
  });
});
