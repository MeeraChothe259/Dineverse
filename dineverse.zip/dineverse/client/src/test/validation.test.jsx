import { describe, it, expect, vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter } from 'react-router-dom';
import { loginSchema, registerSchema, Login } from '../pages/public/Auth.jsx';
import { buildQuery, validateSearch } from '../components/restaurant/SearchPanel.jsx';

const login = vi.fn();
vi.mock('../context/AuthContext.jsx', () => ({
  useAuth: () => ({ user: null, ready: true, login }),
  HOME_BY_ROLE: { customer: '/customer/dashboard' },
}));
vi.mock('../context/ToastContext.jsx', () => ({ useToast: () => ({ success: vi.fn(), error: vi.fn(), info: vi.fn() }) }));

describe('auth schemas', () => {
  it('requires a valid email and password on login', () => {
    expect(loginSchema.safeParse({ email: '', password: '' }).success).toBe(false);
    expect(loginSchema.safeParse({ email: 'nope', password: 'x' }).success).toBe(false);
    expect(loginSchema.safeParse({ email: 'a@b.co', password: 'x' }).success).toBe(true);
  });
  it('enforces password strength and confirmation on register', () => {
    const base = { name: 'Asha', email: 'a@b.co', accountType: 'customer' };
    expect(registerSchema.safeParse({ ...base, password: 'short1', confirm: 'short1' }).success).toBe(false);
    expect(registerSchema.safeParse({ ...base, password: 'longenough', confirm: 'longenough' }).success).toBe(false); // no digit
    expect(registerSchema.safeParse({ ...base, password: 'Passw0rd1', confirm: 'different1' }).success).toBe(false);
    expect(registerSchema.safeParse({ ...base, password: 'Passw0rd1', confirm: 'Passw0rd1' }).success).toBe(true);
  });
  it('never offers admin as an account type', () => {
    expect(registerSchema.safeParse({ name: 'X Y', email: 'a@b.co', password: 'Passw0rd1', confirm: 'Passw0rd1', accountType: 'admin' }).success).toBe(false);
  });
});

describe('Login form', () => {
  it('shows field errors and does not submit invalid input', async () => {
    render(<MemoryRouter><Login /></MemoryRouter>);
    await userEvent.click(screen.getByRole('button', { name: /sign in/i }));
    expect(await screen.findByText('Enter your email')).toBeInTheDocument();
    expect(screen.getByText('Enter your password')).toBeInTheDocument();
    expect(login).not.toHaveBeenCalled();
  });

  it('shows the server error and re-enables the button after a failed login', async () => {
    login.mockRejectedValueOnce({ response: { data: { message: 'Incorrect email or password.' } } });
    render(<MemoryRouter><Login /></MemoryRouter>);
    await userEvent.type(screen.getByLabelText('Email'), 'a@b.co');
    await userEvent.type(screen.getByLabelText('Password'), 'WrongPass1');
    await userEvent.click(screen.getByRole('button', { name: /sign in/i }));
    expect(await screen.findByRole('alert')).toHaveTextContent('Incorrect email or password.');
    await waitFor(() => expect(screen.getByRole('button', { name: /sign in/i })).toBeEnabled());
  });
});

describe('search validation', () => {
  it('rejects past dates and a time without a date', () => {
    expect(validateSearch({ date: '2000-01-01', time: '19:00', guests: 2 }).date).toBeTruthy();
    expect(validateSearch({ date: '', time: '19:00', guests: 2 }).date).toBeTruthy();
    expect(validateSearch({ date: '2999-01-01', time: '', guests: 2 }).time).toBeTruthy();
    expect(validateSearch({ date: '', time: '', guests: 0 }).guests).toBeTruthy();
    expect(validateSearch({ date: '2999-01-01', time: '19:00', guests: 2 })).toEqual({});
  });
  it('carries filters to the listing page as query params', () => {
    expect(buildQuery({ city: 'Mumbai', cuisine: 'North Indian', date: '2999-01-01', time: '19:00', guests: 4 })).toBe('city=Mumbai&cuisine=North+Indian&date=2999-01-01&time=19%3A00&guests=4');
    expect(buildQuery({ city: '', cuisine: '', date: '', time: '', guests: 2 })).toBe('');
  });
});
