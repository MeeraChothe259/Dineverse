export const cn = (...a) => a.filter(Boolean).join(' ');

export const priceLabel = (n = 2) => '₹'.repeat(Math.min(4, Math.max(1, n)));

export const inr = (n) => (n == null ? '' : `₹${Number(n).toLocaleString('en-IN')}`);

const tzOpt = (tz) => (tz ? { timeZone: tz } : {});

export const fmtDate = (iso, tz = 'Asia/Kolkata') =>
  new Date(iso).toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric', ...tzOpt(tz) });

export const fmtTime = (iso, tz = 'Asia/Kolkata') =>
  new Date(iso).toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit', hour12: true, ...tzOpt(tz) });

export const fmtDateTime = (iso, tz) => `${fmtDate(iso, tz)} · ${fmtTime(iso, tz)}`;

export const to12h = (hhmm) => {
  if (!hhmm) return '';
  const [h, m] = hhmm.split(':').map(Number);
  return `${((h + 11) % 12) + 1}:${String(m).padStart(2, '0')} ${h < 12 ? 'AM' : 'PM'}`;
};

/** Today / tomorrow etc. as YYYY-MM-DD in a timezone (default India, where the demo venues are). */
export function dateInTz(offsetDays = 0, tz = 'Asia/Kolkata') {
  const d = new Date(Date.now() + offsetDays * 86400000);
  const p = Object.fromEntries(new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(d).map((x) => [x.type, x.value]));
  return `${p.year}-${p.month}-${p.day}`;
}

export const humanize = (s = '') => s.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());

export const WEEKDAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

export const initials = (name = '') => name.split(/\s+/).filter(Boolean).slice(0, 2).map((s) => s[0]).join('').toUpperCase();

/** "Mon–Sun 12:00 – 23:30" style summary for a restaurant's opening hours. */
export function hoursSummary(hours = []) {
  const open = hours.filter((h) => !h.closed);
  if (!open.length) return 'Closed';
  const first = open[0];
  const same = open.every((h) => h.open === first.open && h.close === first.close);
  return same ? `${open.length === 7 ? 'Daily' : `${open.length} days`} · ${to12h(first.open)} – ${to12h(first.close)}` : 'Hours vary by day';
}
