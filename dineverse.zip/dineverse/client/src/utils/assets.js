// Centralised asset configuration.
//
// DineVerse ships NO third-party photography: nothing here can be a broken link, and no image is
// used without a licence. Restaurants may supply their own image URLs (owner dashboard). When a
// venue has no image, or an image fails to load, a generated editorial placeholder is shown.

export const BRAND = {
  name: 'DineVerse',
  tagline: 'Dining, Reimagined.',
  contactEmail: import.meta.env.VITE_CONTACT_EMAIL || 'hello@dineverse.example',
};

// Hero / section backdrops are generated gradients (no external files).
export const GRADIENTS = [
  ['#2a1d12', '#0B0B0C', '#C9A76A'],
  ['#1a1a24', '#0B0B0C', '#8aa0c9'],
  ['#1f2a22', '#0B0B0C', '#70B58A'],
  ['#2a1618', '#0B0B0C', '#C76D6D'],
  ['#241f2e', '#0B0B0C', '#b49bd6'],
];

export function gradientFor(seed = '') {
  let h = 0;
  for (const c of seed) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  return GRADIENTS[h % GRADIENTS.length];
}

export const EXPERIENCE_META = {
  'Fine Dining': { icon: 'Wine', blurb: 'Tasting menus and refined service.' },
  'Rooftop Dining': { icon: 'Sunset', blurb: 'Open skies and city lights.' },
  'Romantic Evenings': { icon: 'Heart', blurb: 'Candlelight for two.' },
  'Private Dining': { icon: 'DoorOpen', blurb: 'Rooms for intimate gatherings.' },
  Celebrations: { icon: 'PartyPopper', blurb: 'Make the moment memorable.' },
  "Chef's Table": { icon: 'ChefHat', blurb: 'Sit at the heart of the kitchen.' },
};

// A small, clearly-labelled sample layout for the homepage 3D showcase (not a real venue).
export const SAMPLE_LAYOUT = {
  floorPlan: { width: 20, depth: 14 },
  tables: [
    { id: 's1', tableNumber: '1', displayName: 'Table 1', capacity: 2, shape: 'round', dimensions: { width: 1.2, depth: 1.2, height: 0.75 }, position: { x: 4, y: 3.5 }, rotation: 0, state: 'available', selectable: true },
    { id: 's2', tableNumber: '2', displayName: 'Table 2', capacity: 4, shape: 'square', dimensions: { width: 1.1, depth: 1.1, height: 0.75 }, position: { x: 8.5, y: 3.5 }, rotation: 0, state: 'unavailable', selectable: false },
    { id: 's3', tableNumber: '3', displayName: 'Table 3', capacity: 6, shape: 'round', dimensions: { width: 1.7, depth: 1.7, height: 0.75 }, position: { x: 13.5, y: 3.5 }, rotation: 0, state: 'available', selectable: true },
    { id: 's4', tableNumber: '4', displayName: 'Table 4', capacity: 4, shape: 'rectangle', dimensions: { width: 2, depth: 1, height: 0.75 }, position: { x: 5, y: 9 }, rotation: 0, state: 'available', selectable: true },
    { id: 's5', tableNumber: '5', displayName: 'Table 5', capacity: 2, shape: 'round', dimensions: { width: 1.2, depth: 1.2, height: 0.75 }, position: { x: 10, y: 9.5 }, rotation: 0, state: 'disabled', selectable: false },
    { id: 's6', tableNumber: '6', displayName: 'Table 6', capacity: 8, shape: 'rectangle', dimensions: { width: 2.6, depth: 1, height: 0.75 }, position: { x: 15, y: 9.5 }, rotation: 0, state: 'available', selectable: true },
  ],
};
