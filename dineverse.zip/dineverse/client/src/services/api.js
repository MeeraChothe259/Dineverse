import axios from 'axios';

export const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || '/api/v1',
  withCredentials: true, // HTTP-only auth cookie
  timeout: 20000,
});

// A 401 on a private call means the session expired: let the AuthContext react.
api.interceptors.response.use(
  (r) => r,
  (error) => {
    const url = error.config?.url || '';
    if (error.response?.status === 401 && !url.startsWith('/auth/login') && !url.startsWith('/auth/register') && !url.startsWith('/auth/me')) {
      window.dispatchEvent(new CustomEvent('dv:unauthorized'));
    }
    return Promise.reject(error);
  }
);

/** Friendly message for any thrown error (API, validation or network). */
export function errorMessage(error, fallback = 'Something went wrong. Please try again.') {
  if (error?.response?.data?.message) return error.response.data.message;
  if (error?.code === 'ECONNABORTED') return 'The request timed out. Please try again.';
  if (error?.message === 'Network Error') return "We couldn't reach the server. Check your connection and try again.";
  return fallback;
}

export const errorCode = (e) => e?.response?.data?.code;
export const errorDetails = (e) => e?.response?.data?.details;

const unwrap = (p) => p.then((r) => r.data);

export const get = (url, params) => unwrap(api.get(url, { params }));
export const post = (url, body) => unwrap(api.post(url, body));
export const patch = (url, body) => unwrap(api.patch(url, body));
export const put = (url, body) => unwrap(api.put(url, body));
export const del = (url) => unwrap(api.delete(url));
