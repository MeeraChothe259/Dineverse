export default function SceneLoading() {
  return (
    <div role="status" className="flex h-full min-h-[320px] w-full flex-col items-center justify-center gap-4 bg-ink-2">
      <div className="relative h-16 w-16" aria-hidden>
        <div className="absolute inset-0 animate-ping rounded-full border border-gold/50" />
        <div className="absolute inset-3 rounded-full border-2 border-gold" />
      </div>
      <p className="font-display text-2xl text-paper">Preparing the dining room…</p>
      <p className="text-xs text-paper-2">Loading the 3D scene</p>
    </div>
  );
}
