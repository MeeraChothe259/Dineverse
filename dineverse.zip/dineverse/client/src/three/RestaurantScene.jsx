import { Suspense, useEffect, useMemo, useState } from 'react';
import { Canvas } from '@react-three/fiber';
import { PerformanceMonitor } from '@react-three/drei';
import Table3D from './Table3D.jsx';
import RestaurantEnvironment from './RestaurantEnvironment.jsx';
import CameraControls from './CameraControls.jsx';
import { AssetsContext, createAssets } from './sceneAssets.js';

/**
 * The interactive 3D dining room. Tables are rendered from configuration (one backend table record
 * each); this component never decides availability. It only displays the `state` it is given.
 */
export default function RestaurantScene({ layout, tables, selectedId, onPick, readOnly = false, resetSignal, onContextLost }) {
  const assets = useMemo(() => createAssets(), []);
  const [dpr, setDpr] = useState(1.5);
  useEffect(() => () => assets.dispose(), [assets]);

  const { width, depth } = layout;
  const room = useMemo(() => ({ width, depth }), [width, depth]);
  const far = Math.max(width, depth);

  return (
    <Canvas
      shadows
      dpr={[1, dpr]}
      camera={{ position: [0, far * 0.62, far * 0.78], fov: 45, near: 0.1, far: 120 }}
      gl={{ antialias: true, powerPreference: 'high-performance' }}
      onCreated={({ gl, scene }) => {
        scene.background = null;
        gl.domElement.addEventListener('webglcontextlost', (e) => {
          e.preventDefault();
          onContextLost?.();
        });
      }}
      aria-label="Interactive 3D view of the restaurant seating"
    >
      <fog attach="fog" args={['#0B0B0C', far * 1.4, far * 3]} />
      <PerformanceMonitor onDecline={() => setDpr(1)} />
      <AssetsContext.Provider value={assets}>
        <Suspense fallback={null}>
          <RestaurantEnvironment width={width} depth={depth} />
          {tables.map((t) => (
            <Table3D key={t.id} table={t} room={room} selectedId={selectedId} onPick={onPick} readOnly={readOnly} />
          ))}
        </Suspense>
        <CameraControls width={width} depth={depth} resetSignal={resetSignal} />
      </AssetsContext.Provider>
    </Canvas>
  );
}
