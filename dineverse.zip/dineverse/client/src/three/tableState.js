// Shared meaning of table states across the 3D scene, the 2D fallback, the legend and the panels.
// Colour is never the only signal: every state also has a text label and a symbol.
export const STATE_META = {
  available: { label: 'Available', color: '#70B58A', symbol: '✓' },
  selected: { label: 'Selected', color: '#E6D2A5', symbol: '★' },
  unavailable: { label: 'Booked', color: '#C76D6D', symbol: '✕' },
  too_small: { label: 'Too small for party', color: '#66666A', symbol: '–' },
  disabled: { label: 'Out of service', color: '#66666A', symbol: '–' },
};

export const effectiveState = (table, selectedId) => (table.id === selectedId ? 'selected' : table.state || 'available');

export const describeTable = (t, selectedId) => {
  const s = effectiveState(t, selectedId);
  return `${t.displayName}, seats ${t.capacity}, ${STATE_META[s].label.toLowerCase()}`;
};

export function hasWebGL() {
  try {
    const c = document.createElement('canvas');
    return !!(window.WebGLRenderingContext && (c.getContext('webgl2') || c.getContext('webgl')));
  } catch {
    return false;
  }
}

export const LEGEND = ['available', 'selected', 'unavailable', 'disabled'];
