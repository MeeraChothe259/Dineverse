import { STATE_META, describeTable, effectiveState } from './tableState.js';

/**
 * Accessible 2D seating plan. It has the same functionality as the 3D scene (and is used when
 * WebGL is unavailable or the user prefers it): an SVG map plus a plain list of buttons, both
 * keyboard operable with screen-reader labels.
 */
export default function SceneFallback({ layout, tables, selectedId, onPick, readOnly = false }) {
  const { width, depth } = layout;
  const pick = (t) => !readOnly && onPick?.(t);

  return (
    <div className="space-y-4 bg-ink-2 p-3 sm:p-5">
      <svg viewBox={`-0.5 -0.5 ${width + 1} ${depth + 1}`} role="group" aria-label="2D seating plan" className="w-full rounded-lg border border-line bg-ink">
        <rect x="0" y="0" width={width} height={depth} fill="#141416" stroke="#302C26" strokeWidth="0.08" />
        <text x={width / 2} y="0.9" textAnchor="middle" fill="#77736D" fontSize="0.6" letterSpacing="0.15">
          WINDOWS / ENTRANCE SIDE
        </text>
        {tables.map((t) => {
          const state = effectiveState(t, selectedId);
          const meta = STATE_META[state];
          const w = t.dimensions?.width || 1.2;
          const d = t.shape === 'round' ? w : t.dimensions?.depth || 1.2;
          const { x, y } = t.position;
          return (
            <g
              key={t.id}
              transform={`translate(${x} ${y}) rotate(${t.rotation || 0})`}
              role={readOnly ? 'img' : 'button'}
              tabIndex={readOnly ? -1 : 0}
              aria-label={describeTable(t, selectedId)}
              aria-pressed={readOnly ? undefined : state === 'selected'}
              onClick={() => pick(t)}
              onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && (e.preventDefault(), pick(t))}
              style={{ cursor: readOnly ? 'default' : 'pointer', outline: 'none' }}
              className="focus-visible:[&>*:first-child]:stroke-white"
            >
              {t.shape === 'round' ? (
                <circle r={w / 2 + 0.35} fill={`${meta.color}22`} stroke={meta.color} strokeWidth={state === 'selected' ? 0.16 : 0.07} />
              ) : (
                <rect x={-(w / 2 + 0.35)} y={-(d / 2 + 0.35)} width={w + 0.7} height={d + 0.7} rx="0.3" fill={`${meta.color}22`} stroke={meta.color} strokeWidth={state === 'selected' ? 0.16 : 0.07} />
              )}
              <text textAnchor="middle" y="-0.05" fill="#F5F1E9" fontSize="0.55" fontWeight="600">
                {t.tableNumber}
              </text>
              <text textAnchor="middle" y="0.55" fill={meta.color} fontSize="0.5">
                {meta.symbol} {t.capacity}
              </text>
            </g>
          );
        })}
      </svg>

      <ul className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4" aria-label="Tables">
        {tables.map((t) => {
          const state = effectiveState(t, selectedId);
          const meta = STATE_META[state];
          return (
            <li key={t.id}>
              <button
                type="button"
                disabled={readOnly}
                onClick={() => pick(t)}
                aria-pressed={state === 'selected'}
                className="flex w-full items-center justify-between gap-2 rounded-lg border px-3 py-2 text-left text-sm transition hover:bg-ink-3 disabled:cursor-default"
                style={{ borderColor: meta.color }}
              >
                <span>
                  <span className="block text-paper">{t.displayName}</span>
                  <span className="block text-xs text-paper-2">Seats {t.capacity}</span>
                </span>
                <span className="text-xs" style={{ color: meta.color }}>
                  {meta.symbol} {meta.label}
                </span>
              </button>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
