import { useEffect, useMemo, useRef } from 'react';
import { OrbitControls } from '@react-three/drei';
import * as THREE from 'three';

/**
 * Orbit / zoom / pan with limits so the camera can never end up inside walls, under the floor or
 * far away from the room. Touch: one finger rotates, two fingers pinch-zoom and pan.
 */
export default function CameraControls({ width, depth, resetSignal }) {
  const ref = useRef();
  const bounds = useMemo(() => ({ min: new THREE.Vector3(-width / 2, 0, -depth / 2), max: new THREE.Vector3(width / 2, 1.5, depth / 2) }), [width, depth]);

  useEffect(() => {
    if (resetSignal) ref.current?.reset();
  }, [resetSignal]);

  return (
    <OrbitControls
      ref={ref}
      makeDefault
      enableDamping
      dampingFactor={0.08}
      minDistance={5}
      maxDistance={Math.max(width, depth) * 1.9}
      minPolarAngle={0.25}
      maxPolarAngle={Math.PI / 2.15}
      enablePan
      panSpeed={0.7}
      screenSpacePanning={false}
      target={[0, 0.4, 0]}
      touches={{ ONE: THREE.TOUCH.ROTATE, TWO: THREE.TOUCH.DOLLY_PAN }}
      onChange={() => ref.current?.target.clamp(bounds.min, bounds.max)}
    />
  );
}
