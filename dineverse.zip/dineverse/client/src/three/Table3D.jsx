import { memo, useMemo, useState } from 'react';
import { Html } from '@react-three/drei';
import { STATE_META, effectiveState } from './tableState.js';
import { useAssets } from './sceneAssets.js';

const rad = (deg) => (deg * Math.PI) / 180;

/** Chair positions (relative to the table centre) for a table shape and seat count. */
export function chairLayout(shape, capacity, w, d) {
  const out = [];
  if (shape === 'round') {
    const r = w / 2 + 0.42;
    for (let i = 0; i < capacity; i++) {
      const a = (i / capacity) * Math.PI * 2;
      out.push({ x: Math.sin(a) * r, z: Math.cos(a) * r });
    }
  } else {
    const top = Math.ceil(capacity / 2);
    const bottom = capacity - top;
    const row = (n, z) => {
      for (let i = 0; i < n; i++) out.push({ x: ((i + 0.5) / n - 0.5) * w * 0.9, z });
    };
    row(top, -(d / 2 + 0.42));
    row(bottom, d / 2 + 0.42);
  }
  return out.map((c) => ({ ...c, ry: Math.atan2(-c.x, -c.z) })); // face the table centre
}

function Chair({ x, z, ry, color }) {
  const a = useAssets();
  return (
    <group position={[x, 0, z]} rotation={[0, ry, 0]}>
      <mesh geometry={a.box(0.42, 0.06, 0.42)} material={a.mat(color)} position={[0, 0.45, 0]} castShadow dispose={null} />
      <mesh geometry={a.box(0.42, 0.45, 0.05)} material={a.mat(color)} position={[0, 0.72, -0.2]} castShadow dispose={null} />
      <mesh geometry={a.box(0.05, 0.45, 0.05)} material={a.mat('#2a2622')} position={[0, 0.22, 0]} dispose={null} />
    </group>
  );
}

function Table3D({ table, selectedId, onPick, room, readOnly }) {
  const a = useAssets();
  const [hover, setHover] = useState(false);
  const state = effectiveState(table, selectedId);
  const meta = STATE_META[state];
  const { width: w = 1.2, depth: d = 1.2, height: h = 0.75 } = table.dimensions || {};
  const dep = table.shape === 'round' ? w : d;
  const interactive = !readOnly;

  const chairs = useMemo(() => chairLayout(table.shape, table.capacity, w, dep), [table.shape, table.capacity, w, dep]);
  const top = a.mat(meta.color, { roughness: 0.35, emissive: meta.color, emissiveIntensity: state === 'selected' ? 0.45 : hover ? 0.28 : 0.1 });
  const chairColor = state === 'disabled' || state === 'too_small' ? '#3a3a3e' : '#4a3f33';

  return (
    <group position={[table.position.x - room.width / 2, table.position.z || 0, table.position.y - room.depth / 2]} rotation={[0, -rad(table.rotation || 0), 0]}>
      <group
        onClick={interactive ? (e) => { e.stopPropagation(); onPick?.(table); } : undefined}
        onPointerOver={interactive ? (e) => { e.stopPropagation(); setHover(true); document.body.style.cursor = 'pointer'; } : undefined}
        onPointerOut={interactive ? () => { setHover(false); document.body.style.cursor = 'auto'; } : undefined}
      >
        {table.shape === 'round' ? (
          <>
            <mesh geometry={a.cyl(w / 2, w / 2, 0.06)} material={top} position={[0, h, 0]} castShadow receiveShadow dispose={null} />
            <mesh geometry={a.cyl(0.08, 0.2, h)} material={a.mat('#2a2622')} position={[0, h / 2, 0]} castShadow dispose={null} />
          </>
        ) : (
          <>
            <mesh geometry={a.box(w, 0.06, d)} material={top} position={[0, h, 0]} castShadow receiveShadow dispose={null} />
            {[[-1, -1], [1, -1], [-1, 1], [1, 1]].map(([sx, sz]) => (
              <mesh key={`${sx}${sz}`} geometry={a.box(0.07, h, 0.07)} material={a.mat('#2a2622')} position={[sx * (w / 2 - 0.1), h / 2, sz * (d / 2 - 0.1)]} dispose={null} />
            ))}
          </>
        )}
        {/* slightly larger invisible hit area makes thin tables easy to tap on mobile */}
        <mesh position={[0, h / 2, 0]} visible={false}>
          <boxGeometry args={[w + 1.2, h + 0.6, dep + 1.2]} />
        </mesh>
      </group>
      {chairs.map((c, i) => (
        <Chair key={i} {...c} color={chairColor} />
      ))}
      {/* Position of the label stays upright regardless of table rotation */}
      <Html position={[0, h + 0.55, 0]} center distanceFactor={13} zIndexRange={[10, 0]} style={{ pointerEvents: 'none' }}>
        <div
          style={{ background: 'rgba(11,11,12,.82)', border: `1px solid ${meta.color}`, color: '#F5F1E9', fontSize: 12, padding: '2px 8px', borderRadius: 999, whiteSpace: 'nowrap', fontFamily: 'Inter, sans-serif' }}
        >
          <b style={{ color: meta.color }}>{meta.symbol}</b> {table.displayName} · {table.capacity}
        </div>
      </Html>
    </group>
  );
}

export default memo(Table3D);
