import { useAssets } from './sceneAssets.js';

/** Procedural dining room: floor, walls, windows, columns, pendant lights. Sized from the floor plan. */
export default function RestaurantEnvironment({ width, depth }) {
  const a = useAssets();
  const H = 4.2;
  const columns = [[-width / 2 + 0.3, -depth / 2 + 0.3], [width / 2 - 0.3, -depth / 2 + 0.3]];
  const windows = Array.from({ length: Math.max(2, Math.floor(width / 6)) }, (_, i, arr) => -width / 2 + ((i + 1) * width) / (arr.length + 1));

  return (
    <group>
      <ambientLight intensity={0.55} />
      <directionalLight position={[8, 14, 6]} intensity={0.9} castShadow shadow-mapSize={[1024, 1024]} shadow-camera-left={-16} shadow-camera-right={16} shadow-camera-top={16} shadow-camera-bottom={-16} />
      <pointLight position={[0, 3.6, 0]} intensity={14} color="#E6D2A5" distance={26} decay={2} />
      <pointLight position={[-width / 4, 3.4, depth / 4]} intensity={8} color="#C9A76A" distance={16} decay={2} />
      <pointLight position={[width / 4, 3.4, -depth / 4]} intensity={8} color="#C9A76A" distance={16} decay={2} />

      {/* floor + rug */}
      <mesh geometry={a.plane(width, depth)} material={a.mat('#1c1713', { roughness: 0.55 })} rotation={[-Math.PI / 2, 0, 0]} receiveShadow dispose={null} />
      <mesh geometry={a.plane(width * 0.6, depth * 0.55)} material={a.mat('#26201a', { roughness: 0.95 })} rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.01, 0]} dispose={null} />

      {/* back, left, right walls (front stays open for the camera) */}
      <mesh geometry={a.box(width, H, 0.2)} material={a.mat('#17171a')} position={[0, H / 2, -depth / 2 - 0.1]} receiveShadow dispose={null} />
      <mesh geometry={a.box(0.2, H, depth)} material={a.mat('#151518')} position={[-width / 2 - 0.1, H / 2, 0]} dispose={null} />
      <mesh geometry={a.box(0.2, H, depth)} material={a.mat('#151518')} position={[width / 2 + 0.1, H / 2, 0]} dispose={null} />
      {/* skirting + gold inlay */}
      <mesh geometry={a.box(width, 0.15, 0.06)} material={a.mat('#C9A76A', { metalness: 0.6, roughness: 0.35 })} position={[0, 0.9, -depth / 2 + 0.02]} dispose={null} />

      {/* tall windows with a warm glow */}
      {windows.map((x) => (
        <group key={x} position={[x, 2.1, -depth / 2 + 0.03]}>
          <mesh geometry={a.box(1.6, 2.6, 0.04)} material={a.mat('#E6D2A5', { emissive: '#C9A76A', emissiveIntensity: 0.55, roughness: 0.4 })} dispose={null} />
          <mesh geometry={a.box(0.05, 2.6, 0.06)} material={a.mat('#0B0B0C')} dispose={null} />
          <mesh geometry={a.box(1.6, 0.05, 0.06)} material={a.mat('#0B0B0C')} dispose={null} />
        </group>
      ))}

      {columns.map(([x, z]) => (
        <mesh key={x} geometry={a.cyl(0.22, 0.26, H)} material={a.mat('#222226', { roughness: 0.5 })} position={[x, H / 2, z]} castShadow dispose={null} />
      ))}

      {/* pendant lights */}
      {[[-width / 4, -depth / 4], [width / 4, -depth / 4], [-width / 4, depth / 4], [width / 4, depth / 4], [0, 0]].map(([x, z]) => (
        <group key={`${x}${z}`} position={[x, 0, z]}>
          <mesh geometry={a.cyl(0.01, 0.01, 1.2, 6)} material={a.mat('#0B0B0C')} position={[0, H - 0.6, 0]} dispose={null} />
          <mesh geometry={a.sphere(0.18)} material={a.mat('#E6D2A5', { emissive: '#E6D2A5', emissiveIntensity: 1.1 })} position={[0, H - 1.3, 0]} dispose={null} />
        </group>
      ))}
    </group>
  );
}
