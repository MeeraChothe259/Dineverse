import * as THREE from 'three';
import { createContext, useContext } from 'react';

/**
 * Per-scene cache so geometries and materials are created once and reused by every table and
 * chair. `dispose()` is called when the scene unmounts to free GPU memory.
 */
export function createAssets() {
  const geos = new Map();
  const mats = new Map();
  const geo = (key, make) => {
    if (!geos.has(key)) geos.set(key, make());
    return geos.get(key);
  };
  return {
    box: (w, h, d) => geo(`b${w}|${h}|${d}`, () => new THREE.BoxGeometry(w, h, d)),
    cyl: (rt, rb, h, seg = 40) => geo(`c${rt}|${rb}|${h}|${seg}`, () => new THREE.CylinderGeometry(rt, rb, h, seg)),
    sphere: (r) => geo(`s${r}`, () => new THREE.SphereGeometry(r, 16, 12)),
    plane: (w, h) => geo(`p${w}|${h}`, () => new THREE.PlaneGeometry(w, h)),
    mat: (color, opts = {}) => {
      const key = `${color}|${JSON.stringify(opts)}`;
      if (!mats.has(key)) mats.set(key, new THREE.MeshStandardMaterial({ color, roughness: 0.7, metalness: 0.05, ...opts }));
      return mats.get(key);
    },
    dispose() {
      geos.forEach((g) => g.dispose());
      mats.forEach((m) => m.dispose());
      geos.clear();
      mats.clear();
    },
  };
}

export const AssetsContext = createContext(null);
export const useAssets = () => useContext(AssetsContext);
