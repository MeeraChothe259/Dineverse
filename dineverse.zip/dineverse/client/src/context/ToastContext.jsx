import { createContext, useCallback, useContext, useMemo, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { CheckCircle2, Info, TriangleAlert, X } from 'lucide-react';

const ToastCtx = createContext(null);
export const useToast = () => useContext(ToastCtx);

const ICONS = { success: CheckCircle2, error: TriangleAlert, info: Info };
const TONE = { success: 'border-ok/40 text-ok', error: 'border-bad/50 text-bad', info: 'border-gold/40 text-champagne' };

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const id = useRef(0);

  const dismiss = useCallback((tid) => setToasts((t) => t.filter((x) => x.id !== tid)), []);
  const push = useCallback(
    (type, message, ms = 5000) => {
      const tid = ++id.current;
      setToasts((t) => [...t.slice(-3), { id: tid, type, message }]);
      if (ms) setTimeout(() => dismiss(tid), ms);
    },
    [dismiss]
  );

  const api = useMemo(
    () => ({ success: (m) => push('success', m), error: (m) => push('error', m, 8000), info: (m) => push('info', m) }),
    [push]
  );

  return (
    <ToastCtx.Provider value={api}>
      {children}
      <div className="pointer-events-none fixed inset-x-0 bottom-4 z-[100] flex flex-col items-center gap-2 px-4 sm:items-end sm:px-6" role="region" aria-label="Notifications">
        <AnimatePresence>
          {toasts.map((t) => {
            const Icon = ICONS[t.type];
            return (
              <motion.div
                key={t.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 8 }}
                role={t.type === 'error' ? 'alert' : 'status'}
                className={`pointer-events-auto flex w-full max-w-sm items-start gap-3 rounded-xl border bg-ink-3 p-4 shadow-soft ${TONE[t.type]}`}
              >
                <Icon size={18} className="mt-0.5 shrink-0" aria-hidden />
                <p className="flex-1 text-sm text-paper">{t.message}</p>
                <button onClick={() => dismiss(t.id)} aria-label="Dismiss notification" className="text-paper-2 hover:text-paper">
                  <X size={16} />
                </button>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
    </ToastCtx.Provider>
  );
}
