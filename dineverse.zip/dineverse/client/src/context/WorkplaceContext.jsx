import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { get } from '../services/api.js';
import { useAuth } from './AuthContext.jsx';

const Ctx = createContext(null);
export const useWorkplace = () => useContext(Ctx);

const KEY = 'dv_workplace';
const read = () => {
  try {
    return sessionStorage.getItem(KEY);
  } catch {
    return null;
  }
};

/** The restaurants an owner manages, or a staff member is assigned to, plus the currently selected one. */
export function WorkplaceProvider({ children }) {
  const { user } = useAuth();
  const [restaurants, setRestaurants] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentId, setCurrentId] = useState(read());

  const reload = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    setError(null);
    try {
      const r = user.role === 'owner' || user.role === 'admin' ? await get('/owner/restaurants') : await get('/staff/me');
      const list = (user.role === 'staff' ? r.data.restaurants : r.data).map((x) => ({ ...x, id: x.id || x._id }));
      setRestaurants(list);
      setCurrentId((cur) => (list.some((x) => x.id === cur) ? cur : list[0]?.id || null));
    } catch (e) {
      setError(e?.response?.data?.message || 'Could not load your restaurants.');
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    reload();
  }, [reload]);

  const select = useCallback((id) => {
    setCurrentId(id);
    try {
      sessionStorage.setItem(KEY, id);
    } catch {
      /* storage unavailable: selection just won't persist */
    }
  }, []);

  const value = useMemo(
    () => ({ restaurants, current: restaurants.find((r) => r.id === currentId) || null, currentId, select, loading, error, reload }),
    [restaurants, currentId, select, loading, error, reload]
  );
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
