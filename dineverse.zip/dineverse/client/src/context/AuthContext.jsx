import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { get, post } from '../services/api.js';
import { useToast } from './ToastContext.jsx';

const AuthCtx = createContext(null);
export const useAuth = () => useContext(AuthCtx);

export const HOME_BY_ROLE = {
  customer: '/customer/dashboard',
  owner: '/owner/dashboard',
  staff: '/staff/dashboard',
  admin: '/admin/dashboard',
};

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [ready, setReady] = useState(false);
  const toast = useToast();

  useEffect(() => {
    let alive = true;
    get('/auth/me')
      .then((r) => alive && setUser(r.data.user))
      .catch(() => alive && setUser(null))
      .finally(() => alive && setReady(true));
    return () => {
      alive = false;
    };
  }, []);

  // Session expired somewhere else in the app.
  useEffect(() => {
    const onExpired = () => {
      setUser((u) => {
        if (u) toast?.info('Your session has expired. Please sign in again.');
        return null;
      });
    };
    window.addEventListener('dv:unauthorized', onExpired);
    return () => window.removeEventListener('dv:unauthorized', onExpired);
  }, [toast]);

  const login = useCallback(async (email, password) => {
    const r = await post('/auth/login', { email, password });
    setUser(r.data.user);
    return r.data.user;
  }, []);

  const register = useCallback(async (payload) => {
    const r = await post('/auth/register', payload);
    setUser(r.data.user);
    return r.data.user;
  }, []);

  const logout = useCallback(async () => {
    try {
      await post('/auth/logout');
    } catch {
      /* cookie may already be invalid */
    }
    setUser(null);
  }, []);

  const value = useMemo(() => ({ user, ready, login, register, logout, setUser }), [user, ready, login, register, logout]);
  return <AuthCtx.Provider value={value}>{children}</AuthCtx.Provider>;
}
