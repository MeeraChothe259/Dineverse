import { Suspense, lazy } from 'react';
import { Route, Routes } from 'react-router-dom';
import PublicLayout from './components/layout/PublicLayout.jsx';
import DashboardLayout from './components/layout/DashboardLayout.jsx';
import ProtectedRoute from './components/common/ProtectedRoute.jsx';
import { Spinner } from './components/common/ui.jsx';
import Home from './pages/public/Home.jsx';
import { Login, Register, ForgotPassword } from './pages/public/Auth.jsx';
import { About, Contact, NotFound, Privacy, Terms } from './pages/public/Static.jsx';

// Heavy / role-specific routes load on demand.
const Restaurants = lazy(() => import('./pages/public/Restaurants.jsx'));
const RestaurantDetail = lazy(() => import('./pages/public/RestaurantDetail.jsx'));
const Experience = lazy(() => import('./pages/public/Experience.jsx'));

// lazy() needs default exports; adapt named exports.
const named = (loader, name) => lazy(() => loader().then((m) => ({ default: m[name] })));

const CustomerDashboard = named(() => import('./pages/customer/Customer.jsx'), 'CustomerDashboard');
const CustomerReservations = named(() => import('./pages/customer/Customer.jsx'), 'CustomerReservations');
const ReservationDetail = named(() => import('./pages/customer/Customer.jsx'), 'ReservationDetail');
const Profile = named(() => import('./pages/customer/Customer.jsx'), 'Profile');
const Favorites = named(() => import('./pages/customer/Customer.jsx'), 'Favorites');

const OwnerDashboard = named(() => import('./pages/owner/Owner.jsx'), 'OwnerDashboard');
const OwnerRestaurants = named(() => import('./pages/owner/Owner.jsx'), 'OwnerRestaurants');
const RestaurantEdit = named(() => import('./pages/owner/Owner.jsx'), 'RestaurantEdit');
const OwnerReservations = named(() => import('./pages/owner/Owner.jsx'), 'OwnerReservations');
const OwnerStaff = named(() => import('./pages/owner/Owner.jsx'), 'OwnerStaff');
const OwnerAnalytics = named(() => import('./pages/owner/Owner.jsx'), 'OwnerAnalytics');
const OwnerSettings = named(() => import('./pages/owner/Owner.jsx'), 'OwnerSettings');
const OwnerMenu = named(() => import('./pages/owner/OwnerFloor.jsx'), 'OwnerMenu');
const OwnerTables = named(() => import('./pages/owner/OwnerFloor.jsx'), 'OwnerTables');
const FloorPlanEditor = named(() => import('./pages/owner/OwnerFloor.jsx'), 'FloorPlanEditor');

const StaffDashboard = named(() => import('./pages/staff/Staff.jsx'), 'StaffDashboard');
const StaffReservations = named(() => import('./pages/staff/Staff.jsx'), 'StaffReservations');
const CheckIn = named(() => import('./pages/staff/Staff.jsx'), 'CheckIn');
const WalkIn = named(() => import('./pages/staff/Staff.jsx'), 'WalkIn');
const TableStatus = named(() => import('./pages/staff/Staff.jsx'), 'TableStatus');

const AdminDashboard = named(() => import('./pages/admin/Admin.jsx'), 'AdminDashboard');
const AdminRestaurants = named(() => import('./pages/admin/Admin.jsx'), 'AdminRestaurants');
const AdminUsers = named(() => import('./pages/admin/Admin.jsx'), 'AdminUsers');
const AdminReservations = named(() => import('./pages/admin/Admin.jsx'), 'AdminReservations');
const AdminSettings = named(() => import('./pages/admin/Admin.jsx'), 'AdminSettings');

export default function App() {
  return (
    <Suspense fallback={<Spinner label="Loading" />}>
      <Routes>
        <Route element={<PublicLayout />}>
          <Route index element={<Home />} />
          <Route path="restaurants" element={<Restaurants />} />
          <Route path="restaurants/:slug" element={<RestaurantDetail />} />
          <Route path="restaurants/:slug/experience" element={<Experience />} />
          <Route path="login" element={<Login />} />
          <Route path="register" element={<Register />} />
          <Route path="forgot-password" element={<ForgotPassword />} />
          <Route path="about" element={<About />} />
          <Route path="contact" element={<Contact />} />
          <Route path="privacy" element={<Privacy />} />
          <Route path="terms" element={<Terms />} />
        </Route>

        <Route element={<ProtectedRoute roles={['customer', 'owner', 'admin', 'staff']} />}>
          <Route path="customer" element={<ProtectedRoute roles={['customer']} />}>
            <Route element={<DashboardLayout role="customer" />}>
              <Route path="dashboard" element={<CustomerDashboard />} />
              <Route path="reservations" element={<CustomerReservations />} />
              <Route path="reservations/:id" element={<ReservationDetail />} />
              <Route path="profile" element={<Profile />} />
              <Route path="favorites" element={<Favorites />} />
            </Route>
          </Route>

          <Route path="owner" element={<ProtectedRoute roles={['owner']} />}>
            <Route element={<DashboardLayout role="owner" />}>
              <Route path="dashboard" element={<OwnerDashboard />} />
              <Route path="restaurants" element={<OwnerRestaurants />} />
              <Route path="restaurants/:id" element={<RestaurantEdit />} />
              <Route path="restaurants/:id/menu" element={<OwnerMenu />} />
              <Route path="restaurants/:id/tables" element={<OwnerTables />} />
              <Route path="restaurants/:id/floor-plan" element={<FloorPlanEditor />} />
              <Route path="reservations" element={<OwnerReservations />} />
              <Route path="staff" element={<OwnerStaff />} />
              <Route path="analytics" element={<OwnerAnalytics />} />
              <Route path="settings" element={<OwnerSettings />} />
            </Route>
          </Route>

          <Route path="staff" element={<ProtectedRoute roles={['staff']} />}>
            <Route element={<DashboardLayout role="staff" />}>
              <Route path="dashboard" element={<StaffDashboard />} />
              <Route path="reservations" element={<StaffReservations />} />
              <Route path="check-in" element={<CheckIn />} />
              <Route path="walk-in" element={<WalkIn />} />
              <Route path="tables" element={<TableStatus />} />
            </Route>
          </Route>

          <Route path="admin" element={<ProtectedRoute roles={['admin']} />}>
            <Route element={<DashboardLayout role="admin" />}>
              <Route path="dashboard" element={<AdminDashboard />} />
              <Route path="restaurants" element={<AdminRestaurants />} />
              <Route path="customers" element={<AdminUsers />} />
              <Route path="reservations" element={<AdminReservations />} />
              <Route path="settings" element={<AdminSettings />} />
            </Route>
          </Route>
        </Route>

        <Route element={<PublicLayout />}>
          <Route path="*" element={<NotFound />} />
        </Route>
      </Routes>
    </Suspense>
  );
}
