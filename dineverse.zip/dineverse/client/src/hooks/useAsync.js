import { useCallback, useEffect, useRef, useState } from 'react';
import { errorMessage } from '../services/api.js';

/**
 * Runs `fn` on mount and whenever `deps` change. Keeps the previous data visible while reloading
 * (no flicker) and never leaves the UI stuck in a loading state after an error.
 */
export function useAsync(fn, deps = []) {
  const [state, setState] = useState({ data: null, loading: true, error: null });
  const run = useRef(0);
  const fnRef = useRef(fn);
  fnRef.current = fn;

  const load = useCallback(async ({ silent = false } = {}) => {
    const id = ++run.current;
    if (!silent) setState((s) => ({ ...s, loading: true, error: null }));
    try {
      const data = await fnRef.current();
      if (id === run.current) setState({ data, loading: false, error: null });
      return data;
    } catch (e) {
      if (id === run.current) setState((s) => ({ data: silent ? s.data : null, loading: false, error: errorMessage(e), raw: e }));
    }
    return null;
  }, []);

  useEffect(() => {
    load();
    return () => {
      run.current++; // ignore stale responses
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);

  return { ...state, reload: load, setData: (updater) => setState((s) => ({ ...s, data: typeof updater === 'function' ? updater(s.data) : updater })) };
}

export function useDebounced(value, ms = 350) {
  const [v, setV] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setV(value), ms);
    return () => clearTimeout(t);
  }, [value, ms]);
  return v;
}
