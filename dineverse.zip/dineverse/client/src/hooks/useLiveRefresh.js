import { useEffect, useRef, useState } from 'react';
import { io } from 'socket.io-client';

const EVENTS = ['reservation:created', 'reservation:updated', 'reservation:cancelled', 'guest:checked_in', 'table:status'];

/**
 * Joins the authenticated restaurant room and calls `onChange` (debounced) when something
 * happens. If the socket is unavailable it falls back to polling the API every 30s, so the
 * dashboard never silently goes stale. Returns { connected }.
 */
export function useLiveRefresh(restaurantId, onChange) {
  const [connected, setConnected] = useState(false);
  const cb = useRef(onChange);
  cb.current = onChange;

  useEffect(() => {
    if (!restaurantId) return undefined;
    let timer;
    const fire = () => {
      clearTimeout(timer);
      timer = setTimeout(() => cb.current?.(), 400);
    };
    const socket = io(import.meta.env.VITE_SOCKET_URL || undefined, { withCredentials: true, reconnectionDelayMax: 8000 });
    socket.on('connect', () => {
      socket.emit('restaurant:join', restaurantId, (res) => setConnected(!!res?.ok));
    });
    socket.on('disconnect', () => setConnected(false));
    socket.on('connect_error', () => setConnected(false));
    EVENTS.forEach((e) => socket.on(e, fire));
    return () => {
      clearTimeout(timer);
      socket.emit('restaurant:leave', restaurantId);
      socket.disconnect();
      setConnected(false);
    };
  }, [restaurantId]);

  // Polling fallback while disconnected
  useEffect(() => {
    if (connected || !restaurantId) return undefined;
    const t = setInterval(() => cb.current?.(), 30000);
    return () => clearInterval(t);
  }, [connected, restaurantId]);

  return { connected };
}
