import { useState } from 'react';
import { CalendarCheck, Store, Users } from 'lucide-react';
import ReservationsTable from '../../components/dashboard/ReservationsTable.jsx';
import { Button, ConfirmDialog, DataTable, DemoBadge, EmptyState, ErrorState, Field, PageHeader, Pagination, Skeleton, StatCard, StatusBadge } from '../../components/common/ui.jsx';
import { useToast } from '../../context/ToastContext.jsx';
import { useAsync, useDebounced } from '../../hooks/useAsync.js';
import { errorMessage, get, patch } from '../../services/api.js';
import { fmtDateTime, humanize } from '../../utils/format.js';

export function AdminDashboard() {
  const { data, loading, error, reload } = useAsync(() => get('/admin/dashboard'), []);
  const d = data?.data;
  return (
    <>
      <PageHeader title="Platform overview" subtitle="Live counts from the database" />
      {loading && !d ? <Skeleton className="h-80" /> : error ? <ErrorState message={error} onRetry={reload} /> : (
        <div className="space-y-8">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard label="Restaurants" value={d.restaurants.total} hint={`${d.restaurants.active || 0} active · ${d.restaurants.pending || 0} pending`} icon={Store} />
            <StatCard label="Customers" value={d.users.customers} icon={Users} />
            <StatCard label="Owners / Staff" value={`${d.users.owners} / ${d.users.staff}`} icon={Users} />
            <StatCard label="Upcoming reservations" value={d.reservations.upcoming} hint={`${d.reservations.last30Days} created in 30 days`} icon={CalendarCheck} />
          </div>
          {d.restaurants.pending > 0 && <p role="status" className="rounded-lg border border-gold/40 bg-gold/10 p-3 text-sm text-champagne">{d.restaurants.pending} restaurant application(s) awaiting review.</p>}
          <section>
            <h2 className="mb-4 text-3xl">Recent activity</h2>
            {d.recentActivity.length ? (
              <ul className="divide-y divide-line rounded-xl border border-line">
                {d.recentActivity.map((a) => <li key={a.id} className="flex flex-wrap justify-between gap-2 px-4 py-3 text-sm"><span><b className="font-medium">{a.action}</b> <span className="text-paper-2">on {a.targetType}{a.actor ? ` by ${a.actor.name} (${a.actor.role})` : ''}</span></span><time className="text-xs text-paper-2">{fmtDateTime(a.timestamp)}</time></li>)}
              </ul>
            ) : <p className="text-sm text-paper-2">No activity recorded yet.</p>}
          </section>
        </div>
      )}
    </>
  );
}

const ACTIONS = {
  pending: [['active', 'Approve', 'primary'], ['rejected', 'Reject', 'danger']],
  active: [['suspended', 'Suspend', 'danger']],
  suspended: [['active', 'Reactivate', 'primary']],
  rejected: [['pending', 'Reopen', 'outline']],
};

export function AdminRestaurants() {
  const toast = useToast();
  const [status, setStatus] = useState('');
  const [q, setQ] = useState('');
  const [page, setPage] = useState(1);
  const dq = useDebounced(q);
  const { data, loading, error, reload } = useAsync(() => get('/admin/restaurants', { status: status || undefined, q: dq || undefined, page, limit: 15 }), [status, dq, page]);
  const [target, setTarget] = useState(null);
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);

  const apply = async () => {
    setBusy(true);
    try {
      await patch(`/admin/restaurants/${target.r.id}/status`, { status: target.status, note: note || undefined });
      toast.success(`Restaurant ${target.status}.`);
      reload({ silent: true });
    } catch (e) { toast.error(errorMessage(e)); } finally { setBusy(false); setTarget(null); setNote(''); }
  };

  return (
    <>
      <PageHeader title="Restaurants" subtitle="Review applications and manage account status. Every change is audited." />
      <div className="mb-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        <Field label="Search" placeholder="Name or city" value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} />
        <Field label="Status" as="select" value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }}><option value="">All</option>{['pending', 'active', 'suspended', 'rejected'].map((s) => <option key={s} value={s}>{humanize(s)}</option>)}</Field>
      </div>
      {error ? <ErrorState message={error} onRetry={reload} /> : loading && !data ? <Skeleton className="h-64" /> : (
        <>
          <DataTable rows={data.data} empty={<EmptyState icon={Store} title="No restaurants match" />} columns={[
            { key: 'name', header: 'Restaurant', render: (r) => <div><p>{r.name} {r.isDemo && <DemoBadge className="ml-1" label="Demo" />}</p><p className="text-xs text-paper-2">{r.city} · {r.cuisineTypes?.join(', ')}</p></div> },
            { key: 'owner', header: 'Owner', render: (r) => r.owner && <div><p>{r.owner.name}</p><p className="text-xs text-paper-2">{r.owner.email}</p></div> },
            { key: 'status', header: 'Status', render: (r) => <div><StatusBadge status={r.status} />{r.statusNote && <p className="mt-1 text-xs text-paper-2">{r.statusNote}</p>}</div> },
            { key: 'a', header: 'Actions', render: (r) => <div className="flex flex-wrap gap-2">{(ACTIONS[r.status] || []).map(([s, label, v]) => <Button key={s} size="sm" variant={v} onClick={() => setTarget({ r, status: s, label })}>{label}</Button>)}</div> },
          ]} />
          <Pagination meta={data.meta} onPage={setPage} />
        </>
      )}
      <ConfirmDialog open={!!target} danger={target?.status !== 'active'} loading={busy} title={`${target?.label} ${target?.r.name}?`} confirmLabel={target?.label} onConfirm={apply} onClose={() => { setTarget(null); setNote(''); }}
        message={<span className="block space-y-3"><span className="block">{target?.status === 'suspended' ? 'The restaurant will disappear from public listings and stop accepting reservations.' : target?.status === 'rejected' ? 'The application will be rejected and the owner informed in-app.' : 'This changes the restaurant account status.'}</span><Field label="Note (optional, visible to the owner)" value={note} onChange={(e) => setNote(e.target.value)} /></span>} />
    </>
  );
}

export function AdminUsers() {
  const toast = useToast();
  const [role, setRole] = useState('');
  const [q, setQ] = useState('');
  const [page, setPage] = useState(1);
  const dq = useDebounced(q);
  const { data, loading, error, reload } = useAsync(() => get('/admin/customers', { role: role || undefined, q: dq || undefined, page, limit: 15 }), [role, dq, page]);
  const [target, setTarget] = useState(null);
  const toggle = async () => {
    try { await patch(`/admin/users/${target.id}/active`, { isActive: !target.isActive }); toast.success(target.isActive ? 'User deactivated.' : 'User reactivated.'); reload({ silent: true }); } catch (e) { toast.error(errorMessage(e)); } finally { setTarget(null); }
  };
  return (
    <>
      <PageHeader title="Users" />
      <div className="mb-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        <Field label="Search" placeholder="Name or email" value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} />
        <Field label="Role" as="select" value={role} onChange={(e) => { setRole(e.target.value); setPage(1); }}><option value="">All</option>{['customer', 'owner', 'staff'].map((s) => <option key={s} value={s}>{humanize(s)}</option>)}</Field>
      </div>
      {error ? <ErrorState message={error} onRetry={reload} /> : loading && !data ? <Skeleton className="h-64" /> : (
        <>
          <DataTable rows={data.data} empty={<EmptyState icon={Users} title="No users match" />} columns={[
            { key: 'name', header: 'Name', render: (u) => <div><p>{u.name} {u.isDemo && <DemoBadge className="ml-1" label="Demo" />}</p><p className="text-xs text-paper-2">{u.email}</p></div> },
            { key: 'role', header: 'Role', render: (u) => humanize(u.role) },
            { key: 'createdAt', header: 'Joined', render: (u) => fmtDateTime(u.createdAt) },
            { key: 's', header: 'Status', render: (u) => <StatusBadge status={u.isActive ? 'active' : 'suspended'} /> },
            { key: 'a', header: '', render: (u) => <Button size="sm" variant={u.isActive ? 'danger' : 'outline'} onClick={() => setTarget(u)}>{u.isActive ? 'Deactivate' : 'Reactivate'}</Button> },
          ]} />
          <Pagination meta={data.meta} onPage={setPage} />
        </>
      )}
      <ConfirmDialog open={!!target} danger={target?.isActive} title={`${target?.isActive ? 'Deactivate' : 'Reactivate'} ${target?.name}?`} confirmLabel={target?.isActive ? 'Deactivate' : 'Reactivate'} message={target?.isActive ? 'They will be signed out immediately and unable to sign in.' : 'They will be able to sign in again.'} onConfirm={toggle} onClose={() => setTarget(null)} />
    </>
  );
}

export function AdminReservations() {
  const [status, setStatus] = useState('');
  const [q, setQ] = useState('');
  const [page, setPage] = useState(1);
  const dq = useDebounced(q);
  const { data, loading, error, reload } = useAsync(() => get('/admin/reservations', { status: status || undefined, q: dq || undefined, page, limit: 15 }), [status, dq, page]);
  return (
    <>
      <PageHeader title="Reservations" />
      <div className="mb-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        <Field label="Search" placeholder="Guest or reference" value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} />
        <Field label="Status" as="select" value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }}><option value="">All</option>{['confirmed', 'checked_in', 'seated', 'completed', 'cancelled', 'no_show'].map((s) => <option key={s} value={s}>{humanize(s)}</option>)}</Field>
      </div>
      {error ? <ErrorState message={error} onRetry={reload} /> : loading && !data ? <Skeleton className="h-64" /> : (
        <>
          <ReservationsTable rows={data.data.map((r) => ({ ...r, status: r.status }))} showDate showRestaurant onChanged={() => reload({ silent: true })} />
          <Pagination meta={data.meta} onPage={setPage} />
        </>
      )}
    </>
  );
}

export function AdminSettings() {
  const [page, setPage] = useState(1);
  const { data, loading, error, reload } = useAsync(() => get('/admin/audit', { page, limit: 20 }), [page]);
  return (
    <>
      <PageHeader title="Audit log" subtitle="Important owner and admin actions. Secrets are never logged." />
      {error ? <ErrorState message={error} onRetry={reload} /> : loading && !data ? <Skeleton className="h-64" /> : (
        <>
          <DataTable rows={data.data} empty={<EmptyState title="No audit entries yet" />} columns={[
            { key: 't', header: 'When', render: (a) => <span className="whitespace-nowrap">{fmtDateTime(a.timestamp)}</span> },
            { key: 'actor', header: 'Actor', render: (a) => (a.actor ? `${a.actor.name} (${a.actor.role})` : '-') },
            { key: 'action', header: 'Action', render: (a) => <code className="text-xs text-champagne">{a.action}</code> },
            { key: 'target', header: 'Target', render: (a) => <span className="text-xs text-paper-2">{a.targetType} {a.targetId?.slice(-6)}</span> },
            { key: 'meta', header: 'Details', render: (a) => <span className="text-xs text-paper-2">{a.metadata ? JSON.stringify(a.metadata).slice(0, 90) : ''}</span> },
          ]} />
          <Pagination meta={data.meta} onPage={setPage} />
        </>
      )}
    </>
  );
}
