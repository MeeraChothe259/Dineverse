import { Link } from 'react-router-dom';
import { Mail } from 'lucide-react';
import { BRAND } from '../../utils/assets.js';

function Page({ eyebrow, title, children }) {
  return (
    <article className="container-x max-w-3xl py-16">
      <p className="eyebrow">{eyebrow}</p>
      <h1 className="mt-2 text-5xl">{title}</h1>
      <div className="mt-8 space-y-5 leading-relaxed text-paper-2 [&_h2]:mt-8 [&_h2]:text-3xl [&_h2]:text-paper [&_a]:text-champagne [&_a:hover]:underline">{children}</div>
    </article>
  );
}

export const About = () => (
  <Page eyebrow="About" title="Dining, Reimagined">
    <p>DineVerse is a restaurant discovery and reservation platform built around one idea: you should be able to see the room and choose the exact table before you arrive.</p>
    <p>This build is a startup demonstration. Every restaurant, menu, rating and testimonial you see is fictional sample content created to show how the product works. None of them are real businesses or real customers.</p>
    <h2>What is real</h2>
    <p>The workflows are fully functional: accounts, availability checks, conflict-safe bookings, QR check-in, staff tools, owner management and administration all run against a real database.</p>
    <h2>Not included</h2>
    <p>Payments, online food ordering, delivery, and email/SMS delivery are not part of this version.</p>
    <Link to="/restaurants" className="btn-primary !text-ink no-underline">Explore restaurants</Link>
  </Page>
);

export const Contact = () => (
  <Page eyebrow="Support" title="Contact">
    <p>This is a demo deployment with no staffed support desk. For questions about the project, write to the address below; it opens your own email app, as the site does not send email itself.</p>
    <a href={`mailto:${BRAND.contactEmail}`} className="inline-flex items-center gap-2 text-xl"><Mail size={18} aria-hidden /> {BRAND.contactEmail}</a>
    <p>Restaurant owners and staff: your administrator can help with account access.</p>
  </Page>
);

export const Privacy = () => (
  <Page eyebrow="Legal" title="Privacy">
    <p>This demo stores the details you enter (name, email, optional phone, reservation details) in its database solely to operate the application. Passwords are stored only as salted bcrypt hashes.</p>
    <h2>QR codes</h2>
    <p>Reservation QR codes contain a signed random identifier, never your personal details.</p>
    <h2>Cookies</h2>
    <p>Sign-in uses a single HTTP-only session cookie. No advertising or tracking cookies are used.</p>
    <h2>Demo notice</h2>
    <p>Please do not enter sensitive personal information in a demo environment. This page is a project placeholder and not a substitute for a legally reviewed privacy policy.</p>
  </Page>
);

export const Terms = () => (
  <Page eyebrow="Legal" title="Terms of use">
    <p>DineVerse is provided as a demonstration without warranty. Sample restaurants are fictional and reservations made with them do not correspond to real tables.</p>
    <h2>Reservations</h2>
    <p>Cancellation rules are set per restaurant and shown before you confirm. No payment is taken.</p>
    <h2>Acceptable use</h2>
    <p>Do not attempt to disrupt the service or access data that is not yours. This page is a project placeholder and not a legally reviewed agreement.</p>
  </Page>
);

export const NotFound = () => (
  <div className="container-x flex min-h-[60vh] flex-col items-center justify-center py-20 text-center">
    <p className="eyebrow">404</p>
    <h1 className="mt-2 text-6xl">Page not found</h1>
    <p className="mt-3 text-paper-2">The page you're looking for doesn't exist or has moved.</p>
    <Link to="/" className="btn-primary mt-8">Back to home</Link>
  </div>
);
