import { useEffect, useMemo, useState } from 'react';
import { Link, useLocation, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { ArrowLeft, Armchair, CalendarDays, Info } from 'lucide-react';
import SeatingExperience from '../../components/reservation/SeatingExperience.jsx';
import BookingControls, { SlotChips } from '../../components/reservation/BookingControls.jsx';
import { Button, ErrorState, Field, Modal, Skeleton } from '../../components/common/ui.jsx';
import { useAuth } from '../../context/AuthContext.jsx';
import { useToast } from '../../context/ToastContext.jsx';
import { useAsync, useDebounced } from '../../hooks/useAsync.js';
import { errorCode, errorDetails, errorMessage, get, post } from '../../services/api.js';
import { dateInTz, fmtDate, to12h } from '../../utils/format.js';
import { STATE_META } from '../../three/tableState.js';

const detailsSchema = z.object({
  phone: z.string().trim().max(30, 'Phone number is too long').optional().or(z.literal('')),
  specialRequests: z.string().trim().max(500, 'Keep it under 500 characters').optional().or(z.literal('')),
});

export default function Experience() {
  const { slug } = useParams();
  const [sp, setSp] = useSearchParams();
  const { user } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const location = useLocation();

  const restaurant = useAsync(() => get(`/restaurants/${slug}`), [slug]);
  const r = restaurant.data?.data;

  const [booking, setBooking] = useState({ date: sp.get('date') || dateInTz(1), time: sp.get('time') || '19:00', guests: Number(sp.get('guests')) || 2 });
  const debounced = useDebounced(booking, 250);
  const [selectedId, setSelectedId] = useState(null);
  const [inspect, setInspect] = useState(null);
  const [open, setOpen] = useState(false);
  const [conflict, setConflict] = useState(null);

  // keep the URL shareable
  useEffect(() => {
    setSp({ date: booking.date, time: booking.time, guests: String(booking.guests) }, { replace: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [booking.date, booking.time, booking.guests]);

  const avail = useAsync(() => (r ? get(`/restaurants/${r.id}/availability`, debounced) : Promise.resolve(null)), [r?.id, debounced.date, debounced.time, debounced.guests]);
  const data = avail.data?.data;
  const tables = data?.tables || [];

  // Drop the selection when it stops being valid (slot or party size changed, or someone else booked it)
  useEffect(() => {
    if (selectedId && data && !tables.find((t) => t.id === selectedId && t.selectable)) setSelectedId(null);
  }, [data, selectedId, tables]);

  const selected = useMemo(() => tables.find((t) => t.id === selectedId), [tables, selectedId]);
  const slotProblem = data?.slot?.problem;

  const onPick = (t) => {
    setInspect(t);
    if (t.selectable) setSelectedId((cur) => (cur === t.id ? null : t.id));
  };

  const form = useForm({ resolver: zodResolver(detailsSchema), defaultValues: { phone: user?.phone || '', specialRequests: '' } });

  const proceed = () => {
    if (!user) {
      toast.info('Please sign in to complete your reservation. Your selection is kept in the link.');
      return navigate('/login', { state: { from: location.pathname + location.search } });
    }
    if (user.role !== 'customer') return toast.error('Reservations can only be made with a guest account. Please sign out and use a guest account.');
    setConflict(null);
    setOpen(true);
  };

  const submit = form.handleSubmit(async (values) => {
    try {
      const res = await post('/reservations', { restaurantId: r.id, tableId: selectedId, date: booking.date, time: booking.time, guestCount: booking.guests, ...values });
      toast.success('Reservation confirmed.');
      navigate(`/customer/reservations/${res.data.id}`, { state: { justBooked: true } });
    } catch (e) {
      const details = errorDetails(e);
      if (errorCode(e) === 'SLOT_CONFLICT') {
        setConflict(details || {});
        setSelectedId(null);
        avail.reload({ silent: true });
      }
      toast.error(errorMessage(e));
    }
  });

  if (restaurant.error) return <div className="container-x py-24"><ErrorState message={restaurant.error} onRetry={restaurant.reload} /></div>;
  if (!r) return <div className="container-x space-y-4 py-12"><Skeleton className="h-10 w-1/3" /><Skeleton className="h-[540px]" /></div>;

  return (
    <div className="container-x py-8">
      <Link to={`/restaurants/${r.slug}`} className="inline-flex items-center gap-1 text-sm text-paper-2 hover:text-champagne"><ArrowLeft size={14} aria-hidden /> {r.name}</Link>
      <h1 className="mt-2 text-4xl sm:text-5xl">Choose your table</h1>
      <p className="mt-1 text-sm text-paper-2">Availability is checked live on the server for {fmtDate(`${booking.date}T12:00:00`, r.timezone)} at {to12h(booking.time)}.</p>

      <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_360px]">
        <div className="min-w-0">
          {avail.error && !data ? (
            <ErrorState message={avail.error} onRetry={avail.reload} />
          ) : data ? (
            <SeatingExperience layout={data.restaurant.floorPlan} tables={tables} selectedId={selectedId} onPick={onPick} height={560} />
          ) : (
            <Skeleton className="h-[560px]" />
          )}

          <div aria-live="polite" className="mt-4 min-h-[76px]">
            {slotProblem && (
              <p role="alert" className="flex items-start gap-2 rounded-lg border border-bad/40 bg-bad/5 p-3 text-sm text-bad">
                <Info size={16} className="mt-0.5 shrink-0" aria-hidden />
                {{ OUTSIDE_HOURS: 'The restaurant is closed at this time (or the stay would run past closing). Pick another time.', PAST_TIME: 'That time has already passed.', TOO_FAR_AHEAD: 'That date is too far ahead to book.', NOT_ACCEPTING: 'Online reservations are paused for this restaurant.', RESTAURANT_UNAVAILABLE: 'This restaurant is not taking reservations.' }[slotProblem]}
              </p>
            )}
            {!slotProblem && inspect && !inspect.selectable && (
              <p className="rounded-lg border border-line bg-ink-2 p-3 text-sm text-paper-2">
                <b className="text-paper">{inspect.displayName}</b> (seats {inspect.capacity}) is not selectable: {inspect.state === 'too_small' ? `it is too small for ${booking.guests} guests.` : STATE_META[inspect.state]?.label.toLowerCase() + ' for this time.'}
              </p>
            )}
          </div>
        </div>

        <aside className="space-y-5" aria-label="Booking details">
          <div className="card p-5">
            <BookingControls value={booking} onChange={setBooking} slots={data?.slots} maxGuests={Math.min(12, r.reservationSettings.maxPartySize)} tz={r.timezone} />
            <div className="mt-4"><SlotChips slots={data?.slots} value={booking.time} onPick={(time) => setBooking((b) => ({ ...b, time }))} /></div>
          </div>

          <div className="card p-5" aria-live="polite">
            <h2 className="flex items-center gap-2 text-2xl"><Armchair size={18} className="text-gold" aria-hidden /> Your table</h2>
            {selected ? (
              <>
                <p className="mt-3 font-display text-3xl text-champagne">{selected.displayName}</p>
                <p className="text-sm text-paper-2">Seats {selected.capacity} · {STATE_META.available.symbol} Available for your slot</p>
                <p className="mt-2 flex items-center gap-1.5 text-sm text-paper-2"><CalendarDays size={14} aria-hidden /> {fmtDate(`${booking.date}T12:00:00`, r.timezone)}, {to12h(booking.time)} · {booking.guests} guests</p>
              </>
            ) : (
              <p className="mt-3 text-sm text-paper-2">{data?.summary ? `${data.summary.available} of ${data.summary.total} tables are free and large enough.` : ''} Select an available table in the room or from the list.</p>
            )}
            <Button className="mt-5 w-full" disabled={!selected} onClick={proceed}>Continue to reservation</Button>
            {!user && <p className="mt-2 text-xs text-paper-2">You'll be asked to sign in first.</p>}
          </div>

          {conflict && (
            <div role="alert" className="card border-bad/40 p-5 text-sm">
              <p className="font-medium text-paper">That table was just taken.</p>
              {conflict.alternativeTables?.length > 0 && <p className="mt-2 text-paper-2">Free right now: {conflict.alternativeTables.map((t) => `${t.displayName} (${t.capacity})`).join(', ')}.</p>}
              {conflict.alternativeSlots?.length > 0 && <p className="mt-2 text-paper-2">Other times: {conflict.alternativeSlots.slice(0, 5).map((s) => to12h(s.time)).join(', ')}.</p>}
            </div>
          )}
        </aside>
      </div>

      <Modal open={open} onClose={() => setOpen(false)} title="Confirm your reservation" footer={<><Button variant="ghost" onClick={() => setOpen(false)}>Back</Button><Button onClick={submit} loading={form.formState.isSubmitting}>Confirm reservation</Button></>}>
        <dl className="mb-5 grid grid-cols-2 gap-3 rounded-lg border border-line bg-ink-3 p-4 text-sm">
          <div><dt className="text-xs uppercase text-paper-2">Restaurant</dt><dd>{r.name}</dd></div>
          <div><dt className="text-xs uppercase text-paper-2">Table</dt><dd>{selected?.displayName} (seats {selected?.capacity})</dd></div>
          <div><dt className="text-xs uppercase text-paper-2">When</dt><dd>{fmtDate(`${booking.date}T12:00:00`, r.timezone)}, {to12h(booking.time)}</dd></div>
          <div><dt className="text-xs uppercase text-paper-2">Guests</dt><dd>{booking.guests}</dd></div>
        </dl>
        <form onSubmit={submit} className="space-y-4" noValidate>
          <Field label="Contact phone (optional)" type="tel" autoComplete="tel" error={form.formState.errors.phone?.message} {...form.register('phone')} />
          <Field label="Special requests (optional)" as="textarea" rows={3} error={form.formState.errors.specialRequests?.message} {...form.register('specialRequests')} />
          <p className="text-xs text-paper-2">Free cancellation up to {r.reservationSettings.cancellationCutoffHours} hour(s) before. This demo does not send email or SMS; your confirmation and QR code appear on the next page.</p>
          <button type="submit" className="sr-only-live">Submit</button>
        </form>
      </Modal>
    </div>
  );
}
