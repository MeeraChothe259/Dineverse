import { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion, useReducedMotion } from 'framer-motion';
import { ArrowRight, ChefHat, ChevronDown, DoorOpen, Heart, PartyPopper, Sunset, Wine, Armchair, Compass, MousePointerClick, CalendarCheck } from 'lucide-react';
import SearchPanel from '../../components/restaurant/SearchPanel.jsx';
import RestaurantCard, { RestaurantCardSkeleton } from '../../components/restaurant/RestaurantCard.jsx';
import SeatingExperience from '../../components/reservation/SeatingExperience.jsx';
import { DemoBadge, ErrorState } from '../../components/common/ui.jsx';
import { useAsync } from '../../hooks/useAsync.js';
import { get } from '../../services/api.js';
import { EXPERIENCE_META, SAMPLE_LAYOUT } from '../../utils/assets.js';

const ICONS = { Wine, Sunset, Heart, DoorOpen, PartyPopper, ChefHat };
const STEPS = [
  { icon: Compass, title: 'Discover', text: 'Browse venues by cuisine, city, price and experience.' },
  { icon: Armchair, title: 'Explore', text: 'Walk the room in interactive 3D before you decide.' },
  { icon: MousePointerClick, title: 'Select', text: 'Choose the exact table that fits your party and mood.' },
  { icon: CalendarCheck, title: 'Reserve', text: 'Confirm instantly and get a QR code for easy arrival.' },
];
const TESTIMONIALS = [
  { quote: 'Seeing the room before booking took all the guesswork out of choosing a table.', who: 'Sample guest A' },
  { quote: 'Check-in with the QR code took seconds. The host barely had to ask my name.', who: 'Sample guest B' },
  { quote: 'The floor plan editor made reorganising our dining room a five-minute job.', who: 'Sample restaurateur' },
];

const fade = { hidden: { opacity: 0, y: 22 }, show: { opacity: 1, y: 0 } };

export default function Home() {
  const reduce = useReducedMotion();
  const { data, loading, error, reload } = useAsync(() => get('/restaurants', { limit: 3, sort: 'rating' }), []);
  const [picked, setPicked] = useState('s1');
  const sample = SAMPLE_LAYOUT.tables;
  const sel = sample.find((t) => t.id === picked);

  return (
    <>
      {/* HERO */}
      <section className="relative -mt-16 flex min-h-[88vh] items-center overflow-hidden" aria-labelledby="hero-title">
        <div className="absolute inset-0" style={{ background: 'radial-gradient(ellipse at 75% 20%, #C9A76A33, transparent 55%), radial-gradient(ellipse at 15% 80%, #3a2a1a66, transparent 55%), linear-gradient(160deg, #1a1510, #0B0B0C 65%)' }} aria-hidden />
        <svg className="absolute inset-0 h-full w-full opacity-[.18]" viewBox="0 0 800 600" preserveAspectRatio="xMidYMid slice" aria-hidden>
          {[[560, 180, 90], [640, 330, 60], [470, 360, 120], [700, 130, 40]].map(([x, y, r], i) => (
            <g key={i} fill="none" stroke="#C9A76A" strokeWidth="0.8">
              <circle cx={x} cy={y} r={r} />
              <circle cx={x} cy={y} r={r * 0.62} strokeDasharray="3 5" />
            </g>
          ))}
        </svg>
        <div className="absolute inset-0 bg-gradient-to-t from-ink via-transparent to-ink/50" aria-hidden />

        <div className="container-x relative pb-24 pt-32">
          <motion.div initial={reduce ? false : 'hidden'} animate="show" transition={{ staggerChildren: 0.12 }} className="max-w-3xl">
            <motion.p variants={fade} className="eyebrow">THE ART OF DINING, REIMAGINED</motion.p>
            <motion.h1 variants={fade} id="hero-title" className="mt-5 text-5xl leading-[1.02] sm:text-7xl lg:text-8xl">
              Your Table.<br /><span className="text-champagne">Your Experience.</span>
            </motion.h1>
            <motion.p variants={fade} className="mt-6 max-w-xl text-lg text-paper-2">
              Discover exceptional restaurants, explore every corner, and reserve the seat that feels just right.
            </motion.p>
            <motion.div variants={fade} className="mt-9 flex flex-wrap gap-3">
              <Link to="/restaurants" className="btn-primary px-6 py-3">Explore Restaurants</Link>
              <a href="#experience-3d" className="btn-outline px-6 py-3">Experience 3D Dining</a>
            </motion.div>
          </motion.div>
          <motion.div initial={reduce ? false : { opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5, duration: 0.7 }} className="mt-14 max-w-6xl">
            <SearchPanel />
          </motion.div>
        </div>
        <a href="#featured" aria-label="Scroll to featured restaurants" className="absolute bottom-6 left-1/2 hidden -translate-x-1/2 text-paper-2 motion-safe:animate-bounce md:block">
          <ChevronDown />
        </a>
      </section>

      {/* FEATURED */}
      <section id="featured" className="container-x pt-24">
        <div className="mb-10 flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="eyebrow">Featured</p>
            <h2 className="mt-2 text-4xl sm:text-5xl">Tables worth planning around</h2>
          </div>
          <div className="flex items-center gap-4">
            <DemoBadge label="Sample venues & ratings" />
            <Link to="/restaurants" className="inline-flex items-center gap-1 text-sm text-champagne hover:underline">View all <ArrowRight size={14} aria-hidden /></Link>
          </div>
        </div>
        {error ? (
          <ErrorState message={error} onRetry={reload} />
        ) : (
          <div className="grid gap-6 md:grid-cols-3">
            {loading ? [0, 1, 2].map((i) => <RestaurantCardSkeleton key={i} />) : data?.data.map((r) => <RestaurantCard key={r.id} restaurant={r} />)}
          </div>
        )}
      </section>

      {/* 3D SHOWCASE */}
      <section id="experience-3d" className="container-x grid items-center gap-10 pt-28 lg:grid-cols-[.8fr_1.2fr]">
        <div>
          <p className="eyebrow">Interactive 3D seating</p>
          <h2 className="mt-2 text-4xl sm:text-5xl">Walk the room before you arrive</h2>
          <p className="mt-4 text-paper-2">
            Every table you see maps to a real table record, and availability always comes from the server. This is a simplified sample room: open any restaurant's "Experience" page to book a real table.
          </p>
          <div aria-live="polite" className="card mt-6 p-4 text-sm">
            {sel ? (
              <>
                <p className="font-display text-2xl">{sel.displayName}</p>
                <p className="text-paper-2">Seats {sel.capacity} · sample table</p>
              </>
            ) : (
              <p className="text-paper-2">Select an available table to inspect it.</p>
            )}
          </div>
          <Link to="/restaurants" className="btn-primary mt-6">Find a restaurant to book <ArrowRight size={16} aria-hidden /></Link>
        </div>
        <SeatingExperience layout={SAMPLE_LAYOUT.floorPlan} tables={SAMPLE_LAYOUT.tables} selectedId={picked} onPick={(t) => t.selectable && setPicked(t.id)} height={440} />
      </section>

      {/* HOW IT WORKS */}
      <section id="how-it-works" className="container-x pt-28">
        <p className="eyebrow">How it works</p>
        <h2 className="mt-2 text-4xl sm:text-5xl">Four steps to the right seat</h2>
        <ol className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {STEPS.map(({ icon: Icon, title, text }, i) => (
            <li key={title} className="card p-6">
              <div className="flex items-center justify-between">
                <Icon className="text-gold" aria-hidden />
                <span className="font-display text-3xl text-line">0{i + 1}</span>
              </div>
              <h3 className="mt-5 text-2xl">{title}</h3>
              <p className="mt-1 text-sm text-paper-2">{text}</p>
            </li>
          ))}
        </ol>
      </section>

      {/* EXPERIENCES */}
      <section id="experiences" className="container-x pt-28">
        <p className="eyebrow">Experiences</p>
        <h2 className="mt-2 text-4xl sm:text-5xl">Find the occasion</h2>
        <ul className="mt-10 grid gap-px overflow-hidden rounded-xl border border-line bg-line sm:grid-cols-2 lg:grid-cols-3">
          {Object.entries(EXPERIENCE_META).map(([name, m]) => {
            const Icon = ICONS[m.icon];
            return (
              <li key={name} className="bg-ink-2">
                <Link to={`/restaurants?experience=${encodeURIComponent(name)}`} className="group flex h-full items-start gap-4 p-6 transition hover:bg-ink-3">
                  <Icon className="mt-1 shrink-0 text-gold" aria-hidden />
                  <div className="flex-1">
                    <h3 className="text-2xl">{name}</h3>
                    <p className="text-sm text-paper-2">{m.blurb}</p>
                  </div>
                  <ArrowRight size={16} className="mt-2 text-paper-2 transition group-hover:translate-x-1 group-hover:text-champagne" aria-hidden />
                </Link>
              </li>
            );
          })}
        </ul>
      </section>

      {/* PARTNERS */}
      <section className="container-x pt-28">
        <div className="relative overflow-hidden rounded-2xl border border-line bg-ink-2 p-8 sm:p-14">
          <div className="absolute -right-20 -top-20 h-72 w-72 rounded-full border border-gold/20" aria-hidden />
          <div className="absolute -right-8 -top-8 h-48 w-48 rounded-full border border-gold/20" aria-hidden />
          <p className="eyebrow">For restaurants</p>
          <h2 className="mt-2 max-w-2xl text-4xl sm:text-5xl">Run your floor, your bookings and your team from one place</h2>
          <p className="mt-4 max-w-xl text-paper-2">Design your layout in 2D, see it rendered in 3D, manage reservations and check guests in with QR codes.</p>
          <Link to="/register?type=owner" className="btn-primary mt-7">Partner With DineVerse</Link>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="container-x pt-28">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <h2 className="text-4xl sm:text-5xl">What people might say</h2>
          <DemoBadge label="Illustrative, not real reviews" />
        </div>
        <div className="mt-8 grid gap-6 md:grid-cols-3">
          {TESTIMONIALS.map((t) => (
            <figure key={t.who} className="card p-6">
              <blockquote className="font-display text-2xl leading-snug text-paper">“{t.quote}”</blockquote>
              <figcaption className="mt-4 text-xs uppercase tracking-wider text-paper-2">{t.who} · sample testimonial</figcaption>
            </figure>
          ))}
        </div>
      </section>
    </>
  );
}
