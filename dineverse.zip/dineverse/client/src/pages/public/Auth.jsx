import { useState } from 'react';
import { Link, Navigate, useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button, Field } from '../../components/common/ui.jsx';
import { HOME_BY_ROLE, useAuth } from '../../context/AuthContext.jsx';
import { useToast } from '../../context/ToastContext.jsx';
import { errorDetails, errorMessage, post } from '../../services/api.js';

export const loginSchema = z.object({
  email: z.string().trim().min(1, 'Enter your email').email('Enter a valid email'),
  password: z.string().min(1, 'Enter your password'),
});

export const registerSchema = z
  .object({
    name: z.string().trim().min(2, 'Enter your name'),
    email: z.string().trim().min(1, 'Enter your email').email('Enter a valid email'),
    password: z.string().min(8, 'Use at least 8 characters').regex(/[A-Za-z]/, 'Include a letter').regex(/\d/, 'Include a number'),
    confirm: z.string(),
    accountType: z.enum(['customer', 'owner']),
  })
  .refine((v) => v.password === v.confirm, { path: ['confirm'], message: 'Passwords do not match' });

function Shell({ title, subtitle, children, footer }) {
  return (
    <div className="container-x flex min-h-[78vh] items-center justify-center py-16">
      <div className="w-full max-w-md">
        <p className="eyebrow text-center">DineVerse</p>
        <h1 className="mt-2 text-center text-5xl">{title}</h1>
        <p className="mt-2 text-center text-sm text-paper-2">{subtitle}</p>
        <div className="card mt-8 p-6 sm:p-8">{children}</div>
        <p className="mt-6 text-center text-sm text-paper-2">{footer}</p>
      </div>
    </div>
  );
}

export function Login() {
  const { user, login } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const toast = useToast();
  const [formError, setFormError] = useState('');
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm({ resolver: zodResolver(loginSchema) });
  if (user) return <Navigate to={location.state?.from || HOME_BY_ROLE[user.role]} replace />;

  const onSubmit = handleSubmit(async ({ email, password }) => {
    setFormError('');
    try {
      const u = await login(email, password);
      toast.success(`Welcome back, ${u.name.split(' ')[0]}.`);
      navigate(location.state?.from || HOME_BY_ROLE[u.role], { replace: true });
    } catch (e) {
      setFormError(errorMessage(e));
    }
  });

  return (
    <Shell title="Welcome back" subtitle="Sign in to manage your reservations." footer={<>New here? <Link className="text-champagne hover:underline" to="/register">Create an account</Link></>}>
      <form onSubmit={onSubmit} noValidate className="space-y-5">
        {formError && <p role="alert" className="rounded-lg border border-bad/40 bg-bad/10 p-3 text-sm text-bad">{formError}</p>}
        <Field label="Email" type="email" autoComplete="email" error={errors.email?.message} {...register('email')} />
        <Field label="Password" type="password" autoComplete="current-password" error={errors.password?.message} {...register('password')} />
        <Button type="submit" className="w-full" loading={isSubmitting}>Sign in</Button>
        <p className="text-center text-sm"><Link to="/forgot-password" className="text-paper-2 hover:text-champagne">Forgot your password?</Link></p>
      </form>
      {import.meta.env.DEV && <p className="mt-6 border-t border-line pt-4 text-xs text-paper-2">Development demo accounts are listed in the README (after running <code>npm run seed</code>).</p>}
    </Shell>
  );
}

export function Register() {
  const { user, register: signUp } = useAuth();
  const navigate = useNavigate();
  const toast = useToast();
  const [sp] = useSearchParams();
  const [formError, setFormError] = useState('');
  const { register, handleSubmit, setError, watch, formState: { errors, isSubmitting } } = useForm({
    resolver: zodResolver(registerSchema),
    defaultValues: { accountType: sp.get('type') === 'owner' ? 'owner' : 'customer' },
  });
  if (user) return <Navigate to={HOME_BY_ROLE[user.role]} replace />;
  const owner = watch('accountType') === 'owner';

  const onSubmit = handleSubmit(async ({ name, email, password, accountType }) => {
    setFormError('');
    try {
      const u = await signUp({ name, email, password, accountType });
      toast.success('Account created.');
      navigate(HOME_BY_ROLE[u.role], { replace: true });
    } catch (e) {
      (errorDetails(e) || []).forEach((d) => d.path && setError(d.path, { message: d.message }));
      setFormError(errorMessage(e));
    }
  });

  return (
    <Shell title="Create your account" subtitle={owner ? 'Apply to list your restaurant on DineVerse.' : 'Reserve the perfect table in minutes.'} footer={<>Already registered? <Link className="text-champagne hover:underline" to="/login">Sign in</Link></>}>
      <form onSubmit={onSubmit} noValidate className="space-y-5">
        {formError && <p role="alert" className="rounded-lg border border-bad/40 bg-bad/10 p-3 text-sm text-bad">{formError}</p>}
        <fieldset>
          <legend className="label">I am a</legend>
          <div className="grid grid-cols-2 gap-2">
            {[['customer', 'Guest'], ['owner', 'Restaurant owner']].map(([v, l]) => (
              <label key={v} className="flex cursor-pointer items-center justify-center rounded-lg border border-line px-3 py-2.5 text-sm has-[:checked]:border-gold has-[:checked]:bg-gold/10 has-[:checked]:text-champagne">
                <input type="radio" value={v} className="sr-only" {...register('accountType')} /> {l}
              </label>
            ))}
          </div>
          {owner && <p className="mt-2 text-xs text-paper-2">Owner accounts submit restaurants as applications that a platform administrator must approve before they go live.</p>}
        </fieldset>
        <Field label="Full name" autoComplete="name" error={errors.name?.message} {...register('name')} />
        <Field label="Email" type="email" autoComplete="email" error={errors.email?.message} {...register('email')} />
        <Field label="Password" type="password" autoComplete="new-password" hint="8+ characters with a letter and a number" error={errors.password?.message} {...register('password')} />
        <Field label="Confirm password" type="password" autoComplete="new-password" error={errors.confirm?.message} {...register('confirm')} />
        <Button type="submit" className="w-full" loading={isSubmitting}>Create account</Button>
      </form>
    </Shell>
  );
}

export function ForgotPassword() {
  const [msg, setMsg] = useState('');
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm({ resolver: zodResolver(z.object({ email: z.string().trim().email('Enter a valid email') })) });
  const onSubmit = handleSubmit(async () => {
    try {
      const r = await post('/auth/forgot-password', {});
      setMsg(r.message);
    } catch (e) {
      setMsg(errorMessage(e));
    }
  });
  return (
    <Shell title="Reset password" subtitle="Password recovery by email is not available in this version." footer={<Link className="text-champagne hover:underline" to="/login">Back to sign in</Link>}>
      <form onSubmit={onSubmit} noValidate className="space-y-5">
        <Field label="Email" type="email" error={errors.email?.message} {...register('email')} />
        <Button type="submit" className="w-full" loading={isSubmitting}>Request reset</Button>
        {msg && <p role="status" className="rounded-lg border border-gold/40 bg-gold/10 p-3 text-sm text-champagne">{msg}</p>}
      </form>
    </Shell>
  );
}
