import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { SlidersHorizontal, Search, SearchX } from 'lucide-react';
import RestaurantCard, { RestaurantCardSkeleton } from '../../components/restaurant/RestaurantCard.jsx';
import { Button, EmptyState, ErrorState, Field, Modal, Pagination } from '../../components/common/ui.jsx';
import { useAsync, useDebounced } from '../../hooks/useAsync.js';
import { get } from '../../services/api.js';
import { priceLabel } from '../../utils/format.js';

const SORTS = [['recommended', 'Recommended'], ['rating', 'Highest rated'], ['price_asc', 'Price: low to high'], ['price_desc', 'Price: high to low']];

/** Filter form: all state lives in the URL, so results are shareable and survive refresh. */
function Filters({ params, setParam, facets, clear }) {
  const cuisines = params.get('cuisine')?.split(',').filter(Boolean) || [];
  const prices = params.get('price')?.split(',').filter(Boolean) || [];
  const toggle = (key, list, v) => setParam(key, list.includes(v) ? list.filter((x) => x !== v).join(',') : [...list, v].join(','));
  return (
    <div className="space-y-6">
      <Field label="City" as="select" value={params.get('city') || ''} onChange={(e) => setParam('city', e.target.value)}>
        <option value="">All cities</option>
        {facets?.cities.map((c) => <option key={c}>{c}</option>)}
      </Field>
      <Field label="Experience" as="select" value={params.get('experience') || ''} onChange={(e) => setParam('experience', e.target.value)}>
        <option value="">Any experience</option>
        {facets?.experiences.map((c) => <option key={c}>{c}</option>)}
      </Field>
      <fieldset>
        <legend className="label">Cuisine</legend>
        <div className="flex flex-wrap gap-2">
          {facets?.cuisines.map((c) => (
            <button key={c} type="button" aria-pressed={cuisines.includes(c)} onClick={() => toggle('cuisine', cuisines, c)} className={`rounded-full border px-3 py-1 text-xs transition ${cuisines.includes(c) ? 'border-gold bg-gold text-ink' : 'border-line text-paper-2 hover:border-gold'}`}>
              {c}
            </button>
          ))}
        </div>
      </fieldset>
      <fieldset>
        <legend className="label">Price</legend>
        <div className="flex gap-2">
          {[1, 2, 3, 4].map((p) => (
            <button key={p} type="button" aria-pressed={prices.includes(String(p))} aria-label={`Price level ${p} of 4`} onClick={() => toggle('price', prices, String(p))} className={`rounded-lg border px-3 py-1.5 text-xs transition ${prices.includes(String(p)) ? 'border-gold bg-gold text-ink' : 'border-line text-paper-2 hover:border-gold'}`}>
              {priceLabel(p)}
            </button>
          ))}
        </div>
      </fieldset>
      <Field label="Minimum rating (demo ratings)" as="select" value={params.get('minRating') || ''} onChange={(e) => setParam('minRating', e.target.value)}>
        <option value="">Any rating</option>
        {[3.5, 4, 4.5].map((r) => <option key={r} value={r}>{r}+</option>)}
      </Field>
      <fieldset className="space-y-3">
        <legend className="label">Availability</legend>
        <Field label="Date" type="date" value={params.get('date') || ''} onChange={(e) => setParam('date', e.target.value)} />
        <Field label="Time" type="time" step="1800" value={params.get('time') || ''} onChange={(e) => setParam('time', e.target.value)} />
        <Field label="Guests" type="number" min={1} max={20} value={params.get('guests') || 2} onChange={(e) => setParam('guests', e.target.value)} />
        <p className="text-xs text-paper-2">Set a date and time to show only venues with a free table.</p>
      </fieldset>
      <Button variant="outline" className="w-full" onClick={clear}>Clear filters</Button>
    </div>
  );
}

export default function Restaurants() {
  const [params, setParams] = useSearchParams();
  const [drawer, setDrawer] = useState(false);
  const [q, setQ] = useState(params.get('q') || '');
  const dq = useDebounced(q, 350);

  const setParam = (key, value) =>
    setParams((p) => {
      const n = new URLSearchParams(p);
      if (value) n.set(key, value);
      else n.delete(key);
      if (key !== 'page') n.delete('page');
      return n;
    }, { replace: true });

  // keep ?q= in sync with the (debounced) search box
  useEffect(() => {
    if ((params.get('q') || '') !== dq) setParam('q', dq);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dq]);

  const query = params.toString();
  const { data, loading, error, reload } = useAsync(() => get('/restaurants', Object.fromEntries(params)), [query]);
  const facets = useAsync(() => get('/restaurants/facets'), []).data?.data;

  const clear = () => {
    setQ('');
    setParams({}, { replace: true });
  };
  const activeCount = [...params.keys()].filter((k) => !['page', 'sort'].includes(k)).length;
  const meta = data?.meta;
  const carry = ['date', 'time', 'guests'].some((k) => params.get(k)) ? `?${['date', 'time', 'guests'].filter((k) => params.get(k)).map((k) => `${k}=${params.get(k)}`).join('&')}` : '';

  return (
    <div className="container-x py-12">
      <p className="eyebrow">Discover</p>
      <h1 className="mt-2 text-5xl">Restaurants</h1>
      <p className="mt-2 text-sm text-paper-2">All venues in this demo are fictional sample restaurants.</p>

      <div className="mt-8 flex flex-wrap items-end gap-3">
        <div className="relative min-w-[220px] flex-1">
          <label htmlFor="rq" className="sr-only">Search restaurants, cuisines or cities</label>
          <Search size={16} className="pointer-events-none absolute left-3 top-3.5 text-paper-2" aria-hidden />
          <input id="rq" type="search" className="input pl-9" placeholder="Search restaurants, cuisines, cities" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <Field label="Sort by" as="select" className="w-48" value={params.get('sort') || 'recommended'} onChange={(e) => setParam('sort', e.target.value)}>
          {SORTS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
        </Field>
        <Button variant="outline" className="lg:hidden" onClick={() => setDrawer(true)}>
          <SlidersHorizontal size={16} aria-hidden /> Filters{activeCount ? ` (${activeCount})` : ''}
        </Button>
      </div>

      <div className="mt-8 grid gap-8 lg:grid-cols-[280px_1fr]">
        <aside className="hidden lg:block" aria-label="Filters">
          <div className="card sticky top-24 p-5"><Filters params={params} setParam={setParam} facets={facets} clear={clear} /></div>
        </aside>
        <section aria-live="polite" aria-busy={loading}>
          <div className="mb-4 flex items-center justify-between text-sm text-paper-2">
            <span>{loading ? 'Loading…' : `${meta?.total ?? 0} ${meta?.total === 1 ? 'restaurant' : 'restaurants'}`}</span>
            {activeCount > 0 && <button className="text-champagne hover:underline" onClick={clear}>Clear filters</button>}
          </div>
          {error ? (
            <ErrorState message={error} onRetry={reload} />
          ) : loading && !data ? (
            <div className="grid gap-6 sm:grid-cols-2 xl:grid-cols-3">{Array.from({ length: 6 }, (_, i) => <RestaurantCardSkeleton key={i} />)}</div>
          ) : data?.data.length ? (
            <>
              <div className="grid gap-6 sm:grid-cols-2 xl:grid-cols-3">{data.data.map((r) => <RestaurantCard key={r.id} restaurant={r} query={carry} />)}</div>
              <Pagination meta={meta} onPage={(p) => setParam('page', String(p))} />
            </>
          ) : (
            <EmptyState icon={SearchX} title="No restaurants match" message="Try removing a filter or searching for something broader." action={<Button onClick={clear}>Clear all filters</Button>} />
          )}
        </section>
      </div>

      <Modal open={drawer} onClose={() => setDrawer(false)} title="Filters" footer={<Button onClick={() => setDrawer(false)}>Show results</Button>}>
        <Filters params={params} setParam={setParam} facets={facets} clear={clear} />
      </Modal>
    </div>
  );
}
