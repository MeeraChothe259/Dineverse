import { useState } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { Clock, Globe, Heart, MapPin, Phone, ScrollText, Sparkles } from 'lucide-react';
import RestaurantImage from '../../components/common/RestaurantImage.jsx';
import { DemoBadge, ErrorState, Skeleton } from '../../components/common/ui.jsx';
import { Rating } from '../../components/restaurant/RestaurantCard.jsx';
import SeatingExperience from '../../components/reservation/SeatingExperience.jsx';
import BookingControls from '../../components/reservation/BookingControls.jsx';
import { useAuth } from '../../context/AuthContext.jsx';
import { useToast } from '../../context/ToastContext.jsx';
import { useAsync } from '../../hooks/useAsync.js';
import { del, errorMessage, get, put } from '../../services/api.js';
import { WEEKDAYS, dateInTz, inr, priceLabel, to12h } from '../../utils/format.js';

const GUEST_CAP = 12;

function FavoriteButton({ restaurantId }) {
  const { user } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const { data, setData } = useAsync(() => (user?.role === 'customer' ? get('/favorites/ids') : Promise.resolve({ data: [] })), [user?.id]);
  const fav = data?.data?.includes(restaurantId);
  if (user && user.role !== 'customer') return null;
  const toggle = async () => {
    if (!user) return navigate('/login', { state: { from: window.location.pathname } });
    try {
      if (fav) await del(`/favorites/${restaurantId}`);
      else await put(`/favorites/${restaurantId}`);
      setData((d) => ({ data: fav ? d.data.filter((x) => x !== restaurantId) : [...(d?.data || []), restaurantId] }));
      toast.success(fav ? 'Removed from favorites.' : 'Saved to favorites.');
    } catch (e) {
      toast.error(errorMessage(e));
    }
  };
  return (
    <button onClick={toggle} aria-pressed={!!fav} className="btn-outline btn-sm">
      <Heart size={14} className={fav ? 'fill-gold text-gold' : ''} aria-hidden /> {fav ? 'Saved' : 'Save'}
    </button>
  );
}

export default function RestaurantDetail() {
  const { slug } = useParams();
  const [sp] = useSearchParams();
  const { data, loading, error, reload } = useAsync(() => get(`/restaurants/${slug}`), [slug]);
  const r = data?.data;
  const menu = useAsync(() => (r ? get(`/restaurants/${r.id}/menu`) : Promise.resolve({ data: [] })), [r?.id]).data?.data || [];
  const [booking, setBooking] = useState({ date: sp.get('date') || dateInTz(1), time: sp.get('time') || '19:00', guests: Number(sp.get('guests')) || 2 });
  const [photo, setPhoto] = useState(0);

  // preview (read-only) of the real layout with the chosen slot's live availability
  const av = useAsync(() => (r ? get(`/restaurants/${r.id}/availability`, booking) : Promise.resolve(null)), [r?.id, booking.date, booking.time, booking.guests]);
  const slots = av.data?.data?.slots;

  if (error) return <div className="container-x py-24"><ErrorState message={error} onRetry={reload} /></div>;
  if (loading || !r)
    return (
      <div className="container-x space-y-6 py-12">
        <Skeleton className="h-[360px]" /><Skeleton className="h-10 w-1/2" /><Skeleton className="h-40" />
      </div>
    );

  const categories = [...new Set(menu.map((m) => m.category))];
  const experienceUrl = `/restaurants/${r.slug}/experience?date=${booking.date}&time=${booking.time}&guests=${booking.guests}`;
  const addr = [r.address?.line1, r.address?.city, r.address?.state].filter(Boolean).join(', ');

  return (
    <div className="container-x py-10">
      {/* gallery */}
      <div className="grid gap-3 lg:grid-cols-[2fr_1fr]">
        <div className="h-[320px] overflow-hidden rounded-xl sm:h-[440px]">
          <RestaurantImage image={r.images?.[photo]} name={r.name} seed={r.slug} />
        </div>
        <div className="hidden grid-rows-2 gap-3 lg:grid">
          {[1, 2].map((i) => (
            <button key={i} className="overflow-hidden rounded-xl" onClick={() => r.images?.[i] && setPhoto(i)} aria-label={`Show photo ${i + 1}`} disabled={!r.images?.[i]}>
              <RestaurantImage image={r.images?.[i]} name={r.name} seed={`${r.slug}${i}`} />
            </button>
          ))}
        </div>
      </div>

      <div className="mt-10 grid gap-10 lg:grid-cols-[1fr_380px]">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-3">
            {r.isDemo && <DemoBadge label="Demo venue · fictional" />}
            <Rating rating={r.rating} />
          </div>
          <h1 className="mt-3 text-5xl sm:text-6xl">{r.name}</h1>
          {r.tagline && <p className="mt-2 font-display text-2xl text-champagne">{r.tagline}</p>}
          <p className="mt-3 text-sm text-paper-2">{r.cuisineTypes.join(' · ')} · <span aria-label={`Price range ${r.priceRange} of 4`}>{priceLabel(r.priceRange)}</span></p>
          <div className="mt-4"><FavoriteButton restaurantId={r.id} /></div>

          <p className="mt-6 max-w-3xl leading-relaxed text-paper-2">{r.description}</p>

          {r.experiences?.length > 0 && (
            <div className="mt-5 flex flex-wrap gap-2">
              {r.experiences.map((e) => <Link key={e} to={`/restaurants?experience=${encodeURIComponent(e)}`} className="badge border-line text-paper-2 hover:border-gold">{e}</Link>)}
            </div>
          )}

          <section className="mt-12" aria-labelledby="seat-h">
            <h2 id="seat-h" className="text-3xl">Explore the seating</h2>
            <p className="mb-4 mt-1 text-sm text-paper-2">Live availability for {booking.date} at {to12h(booking.time)} for {booking.guests}. Open the full experience to pick a table.</p>
            {av.data?.data ? (
              <SeatingExperience layout={av.data.data.restaurant.floorPlan} tables={av.data.data.tables} readOnly height={380} />
            ) : av.error ? <ErrorState message={av.error} onRetry={av.reload} /> : <Skeleton className="h-[380px]" />}
            <Link to={experienceUrl} className="btn-primary mt-4">Choose your table in 3D</Link>
          </section>

          <section className="mt-12" aria-labelledby="menu-h">
            <h2 id="menu-h" className="text-3xl">Menu</h2>
            {r.isDemo && <p className="mt-1 text-xs text-paper-2">Sample menu, not a real restaurant's offering.</p>}
            {!menu.length ? <p className="mt-4 text-sm text-paper-2">The menu hasn't been published yet.</p> : categories.map((c) => (
              <div key={c} className="mt-6">
                <h3 className="border-b border-line pb-2 text-2xl text-champagne">{c}</h3>
                <ul className="divide-y divide-line">
                  {menu.filter((m) => m.category === c).map((m) => (
                    <li key={m.id} className={`flex items-start justify-between gap-4 py-3 ${m.isAvailable ? '' : 'opacity-50'}`}>
                      <div>
                        <p className="text-paper">{m.name}{!m.isAvailable && <span className="ml-2 text-xs text-paper-2">(unavailable)</span>}</p>
                        {m.description && <p className="text-sm text-paper-2">{m.description}</p>}
                        {m.dietaryLabels?.length > 0 && <p className="mt-1 text-xs text-ok">{m.dietaryLabels.map((l) => l.replace('_', ' ')).join(' · ')}</p>}
                      </div>
                      <span className="shrink-0 text-paper">{inr(m.price)}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </section>

          <section className="mt-12 grid gap-8 sm:grid-cols-2">
            <div>
              <h2 className="text-3xl">Opening hours</h2>
              <ul className="mt-3 space-y-1 text-sm">
                {r.openingHours.map((h) => (
                  <li key={h.day} className="flex justify-between border-b border-line/60 py-1.5">
                    <span className="text-paper-2">{WEEKDAYS[h.day]}</span>
                    <span>{h.closed ? 'Closed' : `${to12h(h.open)} – ${to12h(h.close)}`}</span>
                  </li>
                ))}
              </ul>
              <p className="mt-2 text-xs text-paper-2">Times are in the restaurant's local timezone ({r.timezone}).</p>
            </div>
            <div className="space-y-5 text-sm">
              <div>
                <h2 className="text-3xl">Details</h2>
                <ul className="mt-3 space-y-2 text-paper-2">
                  {addr && <li className="flex gap-2"><MapPin size={16} className="mt-0.5 shrink-0 text-gold" aria-hidden />{addr}</li>}
                  {r.contact?.phone && <li className="flex gap-2"><Phone size={16} className="shrink-0 text-gold" aria-hidden />{r.contact.phone}</li>}
                  {r.contact?.website && <li className="flex gap-2"><Globe size={16} className="shrink-0 text-gold" aria-hidden /><a className="text-champagne hover:underline" href={r.contact.website} target="_blank" rel="noreferrer noopener">Website</a></li>}
                  <li className="flex gap-2"><Clock size={16} className="shrink-0 text-gold" aria-hidden />Typical stay {r.reservationSettings.durationMinutes} minutes</li>
                </ul>
              </div>
              {r.amenities?.length > 0 && (
                <div>
                  <h3 className="flex items-center gap-2 text-xl"><Sparkles size={16} className="text-gold" aria-hidden /> Amenities</h3>
                  <ul className="mt-2 flex flex-wrap gap-2">{r.amenities.map((a) => <li key={a} className="badge border-line text-paper-2">{a}</li>)}</ul>
                </div>
              )}
              <div>
                <h3 className="flex items-center gap-2 text-xl"><ScrollText size={16} className="text-gold" aria-hidden /> Reservation policy</h3>
                <p className="mt-2 text-paper-2">{r.policies || `Free cancellation up to ${r.reservationSettings.cancellationCutoffHours} hour(s) before your reservation.`}</p>
              </div>
            </div>
          </section>
        </div>

        {/* sticky booking summary (desktop) */}
        <aside className="hidden lg:block" aria-label="Reservation summary">
          <div className="card sticky top-24 p-6">
            <h2 className="text-3xl">Reserve a table</h2>
            <div className="mt-5">
              <BookingControls value={booking} onChange={setBooking} slots={slots} maxGuests={Math.min(GUEST_CAP, r.reservationSettings.maxPartySize)} tz={r.timezone} />
            </div>
            <Link to={experienceUrl} className="btn-primary mt-6 w-full">Choose your table</Link>
            <p className="mt-3 text-xs text-paper-2">No payment is taken. Confirmation is shown here; email isn't sent in this demo.</p>
          </div>
        </aside>
      </div>

      {/* mobile CTA: sits in the flow's end so it never covers content */}
      <div className="sticky bottom-0 -mx-4 mt-10 border-t border-line bg-ink/95 p-4 backdrop-blur lg:hidden">
        <Link to={experienceUrl} className="btn-primary w-full">Choose your table · {booking.date}, {to12h(booking.time)}</Link>
      </div>
    </div>
  );
}
