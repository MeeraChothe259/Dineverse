import { useEffect, useMemo, useRef, useState } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { AlertTriangle, Camera, CheckCircle2, Clock, Footprints, Search, ShieldAlert, Users, XCircle } from 'lucide-react';
import ReservationsTable from '../../components/dashboard/ReservationsTable.jsx';
import { Button, EmptyState, ErrorState, Field, LiveBadge, PageHeader, Skeleton, StatCard, StatusBadge } from '../../components/common/ui.jsx';
import { useWorkplace } from '../../context/WorkplaceContext.jsx';
import { useToast } from '../../context/ToastContext.jsx';
import { useAsync, useDebounced } from '../../hooks/useAsync.js';
import { useLiveRefresh } from '../../hooks/useLiveRefresh.js';
import { errorMessage, get, patch, post } from '../../services/api.js';
import { fmtTime, humanize } from '../../utils/format.js';

function useVenue() {
  const wp = useWorkplace();
  return { wp, id: wp?.currentId, restaurant: wp?.current };
}

/** Standard wrapper: loads while the workplace resolves, shows an error when it can't. */
function NeedVenue({ wp, children }) {
  if (wp.loading) return <Skeleton className="h-64" />;
  if (wp.error) return <ErrorState message={wp.error} onRetry={wp.reload} />;
  if (!wp.current) return <EmptyState title="No restaurant selected" />;
  return children;
}

export function StaffDashboard() {
  const { wp, id, restaurant } = useVenue();
  const dash = useAsync(() => (id ? get('/staff/dashboard', { restaurantId: id }) : Promise.resolve(null)), [id]);
  const list = useAsync(() => (id ? get('/staff/reservations', { restaurantId: id, status: 'confirmed,checked_in,seated' }) : Promise.resolve(null)), [id]);
  const refresh = () => { dash.reload({ silent: true }); list.reload({ silent: true }); };
  const { connected } = useLiveRefresh(id, refresh);
  const s = dash.data?.data?.stats;
  const tz = restaurant?.timezone;

  return (
    <NeedVenue wp={wp}>
      <PageHeader title={`Today at ${restaurant?.name}`} subtitle={dash.data?.data?.date} actions={<LiveBadge connected={connected} />} />
      {dash.error ? <ErrorState message={dash.error} onRetry={dash.reload} /> : (
        <>
          <div className="mb-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard label="Reservations today" value={s?.reservationsToday ?? '–'} icon={Clock} />
            <StatCard label="Expected guests" value={s?.expectedGuests ?? '–'} icon={Users} />
            <StatCard label="Checked in" value={s?.checkedInGuests ?? '–'} hint="guests arrived" icon={CheckCircle2} />
            <StatCard label="Upcoming arrivals" value={s?.upcomingArrivals ?? '–'} />
            <StatCard label="Available tables" value={s ? `${s.availableTables}/${s.totalTables}` : '–'} />
            <StatCard label="Occupied tables" value={s?.occupiedTables ?? '–'} />
          </div>
          <h2 className="mb-4 text-3xl">Arrivals & seated</h2>
          {list.loading && !list.data ? <Skeleton className="h-40" /> : <ReservationsTable rows={list.data?.data?.reservations || []} tz={tz} onChanged={refresh} emptyText="No upcoming arrivals" />}
        </>
      )}
    </NeedVenue>
  );
}

export function StaffReservations() {
  const { wp, id, restaurant } = useVenue();
  const [date, setDate] = useState('');
  const [status, setStatus] = useState('');
  const [q, setQ] = useState('');
  const dq = useDebounced(q);
  const { data, loading, error, reload } = useAsync(() => (id ? get('/staff/reservations', { restaurantId: id, date: date || undefined, status: status || undefined, q: dq || undefined }) : Promise.resolve(null)), [id, date, status, dq]);
  const { connected } = useLiveRefresh(id, () => reload({ silent: true }));

  return (
    <NeedVenue wp={wp}>
      <PageHeader title="Reservations" subtitle={data?.data?.date} actions={<LiveBadge connected={connected} />} />
      <div className="mb-6 grid gap-3 sm:grid-cols-3">
        <Field label="Search" placeholder="Guest name or reference" value={q} onChange={(e) => setQ(e.target.value)} />
        <Field label="Date" type="date" value={date} onChange={(e) => setDate(e.target.value)} hint="Defaults to today" />
        <Field label="Status" as="select" value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">All</option>
          {['confirmed', 'checked_in', 'seated', 'completed', 'cancelled', 'no_show'].map((s) => <option key={s} value={s}>{humanize(s)}</option>)}
        </Field>
      </div>
      {error ? <ErrorState message={error} onRetry={reload} /> : loading && !data ? <Skeleton className="h-64" /> : <ReservationsTable rows={data?.data?.reservations || []} tz={restaurant?.timezone} onChanged={() => reload({ silent: true })} />}
    </NeedVenue>
  );
}

const STATE_UI = {
  valid: { icon: CheckCircle2, tone: 'border-ok/50 bg-ok/10 text-ok', title: 'Valid reservation' },
  checked_in: { icon: CheckCircle2, tone: 'border-ok/50 bg-ok/10 text-ok', title: 'Checked in' },
  already_used: { icon: AlertTriangle, tone: 'border-gold/50 bg-gold/10 text-gold', title: 'Already checked in' },
  too_early: { icon: Clock, tone: 'border-gold/50 bg-gold/10 text-gold', title: 'Too early' },
  expired: { icon: XCircle, tone: 'border-bad/50 bg-bad/10 text-bad', title: 'Expired' },
  cancelled: { icon: XCircle, tone: 'border-bad/50 bg-bad/10 text-bad', title: 'Cancelled' },
  invalid: { icon: XCircle, tone: 'border-bad/50 bg-bad/10 text-bad', title: 'Invalid code' },
  wrong_restaurant: { icon: ShieldAlert, tone: 'border-bad/50 bg-bad/10 text-bad', title: 'Wrong restaurant' },
};

export function CheckIn() {
  const { wp, restaurant } = useVenue();
  const toast = useToast();
  const [result, setResult] = useState(null);
  const [last, setLast] = useState(null); // what was scanned (token or reference)
  const [busy, setBusy] = useState(false);
  const [cameras, setCameras] = useState([]);
  const [cameraId, setCameraId] = useState('');
  const [camError, setCamError] = useState('');
  const [scanning, setScanning] = useState(false);
  const scanner = useRef(null);
  const lock = useRef({ code: null, at: 0 });
  const [ref, setRef] = useState('');

  const verify = async (input) => {
    setBusy(true);
    setLast(input);
    try {
      const r = await post('/checkin/verify', input);
      setResult(r.data);
    } catch (e) {
      setResult({ valid: false, state: 'invalid', message: errorMessage(e) });
    } finally {
      setBusy(false);
    }
  };

  const confirm = async () => {
    setBusy(true);
    try {
      const r = await post('/checkin/confirm', last);
      setResult(r.data);
      toast.success('Guest checked in.');
    } catch (e) {
      const state = e?.response?.data?.details?.state;
      setResult((cur) => ({ ...cur, valid: false, state: state || 'invalid', message: errorMessage(e) }));
    } finally {
      setBusy(false);
    }
  };

  const stop = async () => {
    const s = scanner.current;
    scanner.current = null;
    setScanning(false);
    if (s) {
      try { if (s.isScanning) await s.stop(); s.clear(); } catch { /* already stopped */ }
    }
  };

  const loadCameras = async () => {
    setCamError('');
    try {
      const { Html5Qrcode } = await import('html5-qrcode');
      const list = await Html5Qrcode.getCameras();
      if (!list.length) throw new Error('No camera found');
      setCameras(list);
      setCameraId((cur) => cur || (list.find((c) => /back|rear|environment/i.test(c.label)) || list[0]).id);
    } catch {
      setCamError('Camera access was blocked or no camera was found. Allow camera permission for this site in your browser settings (usually the lock icon in the address bar), or use manual reference entry below.');
    }
  };

  const start = async () => {
    setCamError('');
    try {
      const { Html5Qrcode } = await import('html5-qrcode');
      await stop();
      const s = new Html5Qrcode('qr-reader');
      scanner.current = s;
      await s.start(cameraId ? { deviceId: { exact: cameraId } } : { facingMode: 'environment' }, { fps: 10, qrbox: { width: 240, height: 240 } }, (text) => {
        const now = Date.now();
        if (lock.current.code === text && now - lock.current.at < 4000) return; // ignore repeat frames
        lock.current = { code: text, at: now };
        verify({ token: text });
      });
      setScanning(true);
    } catch {
      setScanning(false);
      setCamError('Could not start the camera. Check permission and that no other app is using it, or use manual entry.');
    }
  };

  useEffect(() => () => { stop(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const ui = result && (STATE_UI[result.state] || STATE_UI.invalid);
  const Icon = ui?.icon;
  const res = result?.reservation;

  return (
    <NeedVenue wp={wp}>
      <PageHeader title="Check-in" subtitle={`Scan a guest's QR code at ${restaurant?.name}`} />
      <div className="grid gap-8 lg:grid-cols-2">
        <section className="card p-5" aria-labelledby="scan-h">
          <h2 id="scan-h" className="mb-3 text-2xl">QR scanner</h2>
          <div id="qr-reader" className="min-h-[260px] overflow-hidden rounded-lg border border-line bg-ink-2" />
          {camError && <p role="alert" className="mt-3 rounded-lg border border-bad/40 bg-bad/10 p-3 text-sm text-bad">{camError}</p>}
          <div className="mt-4 flex flex-wrap items-end gap-3">
            {cameras.length > 1 && (
              <Field label="Camera" as="select" className="min-w-[180px] flex-1" value={cameraId} onChange={(e) => { setCameraId(e.target.value); }}>
                {cameras.map((c) => <option key={c.id} value={c.id}>{c.label || c.id}</option>)}
              </Field>
            )}
            {!cameras.length ? <Button onClick={loadCameras}><Camera size={16} aria-hidden /> Enable camera</Button> : scanning ? <Button variant="outline" onClick={stop}>Stop scanning</Button> : <Button onClick={start}><Camera size={16} aria-hidden /> Start scanning</Button>}
          </div>
          <p className="mt-3 text-xs text-paper-2">Your browser will ask for camera permission. Scanning happens on this device; images are not uploaded.</p>
        </section>

        <section className="space-y-6">
          <form className="card p-5" onSubmit={(e) => { e.preventDefault(); if (ref.trim()) verify({ reference: ref.trim().toUpperCase() }); }}>
            <h2 className="mb-3 text-2xl">Manual entry</h2>
            <div className="flex gap-3">
              <Field label="Booking reference" className="flex-1" placeholder="DV-XXXXXXXX" value={ref} onChange={(e) => setRef(e.target.value)} />
              <Button type="submit" className="self-end" loading={busy}><Search size={16} aria-hidden /> Look up</Button>
            </div>
          </form>

          <div aria-live="assertive">
            {result && (
              <div className={`rounded-xl border p-5 ${ui.tone}`} role="status">
                <div className="flex items-center gap-2"><Icon aria-hidden /><h3 className="text-2xl">{ui.title}</h3></div>
                <p className="mt-1 text-sm text-paper">{result.message}</p>
                {res && (
                  <dl className="mt-4 grid grid-cols-2 gap-3 text-sm text-paper">
                    <div><dt className="text-xs uppercase text-paper-2">Guest</dt><dd>{res.customerName}</dd></div>
                    <div><dt className="text-xs uppercase text-paper-2">Party</dt><dd>{res.guestCount}</dd></div>
                    <div><dt className="text-xs uppercase text-paper-2">Time</dt><dd>{fmtTime(res.startAt, restaurant?.timezone)}</dd></div>
                    <div><dt className="text-xs uppercase text-paper-2">Table</dt><dd>{res.table?.displayName}</dd></div>
                    <div><dt className="text-xs uppercase text-paper-2">Reference</dt><dd className="font-mono">{res.bookingReference}</dd></div>
                    <div><dt className="text-xs uppercase text-paper-2">Status</dt><dd><StatusBadge status={res.status} /></dd></div>
                    {res.specialRequests && <div className="col-span-2"><dt className="text-xs uppercase text-paper-2">Requests</dt><dd>{res.specialRequests}</dd></div>}
                  </dl>
                )}
                {result.state === 'valid' && <Button className="mt-5 w-full" onClick={confirm} loading={busy}>Confirm check-in</Button>}
                <button className="mt-3 text-xs text-paper-2 underline" onClick={() => setResult(null)}>Clear</button>
              </div>
            )}
          </div>
        </section>
      </div>
    </NeedVenue>
  );
}

const walkSchema = z.object({
  guestName: z.string().trim().min(1, 'Enter a name'),
  phone: z.string().trim().max(30).optional().or(z.literal('')),
  guestCount: z.coerce.number().int().min(1, 'At least 1').max(40),
  tableId: z.string().min(1, 'Choose a table'),
  durationMinutes: z.coerce.number().int().min(15).max(360),
  notes: z.string().trim().max(500).optional().or(z.literal('')),
});

export function WalkIn() {
  const { wp, id } = useVenue();
  const toast = useToast();
  const dash = useAsync(() => (id ? get('/staff/dashboard', { restaurantId: id }) : Promise.resolve(null)), [id]);
  const { register, handleSubmit, watch, reset, formState: { errors, isSubmitting } } = useForm({ resolver: zodResolver(walkSchema), defaultValues: { guestCount: 2, durationMinutes: 75, tableId: '' } });
  const guests = Number(watch('guestCount')) || 1;
  const tables = useMemo(() => (dash.data?.data?.tables || []).filter((t) => t.status === 'available' && t.capacity >= guests), [dash.data, guests]);

  const onSubmit = handleSubmit(async (v) => {
    try {
      await post('/staff/walk-ins', { restaurantId: id, guestName: v.guestName, phone: v.phone || undefined, guestCount: v.guestCount, tableId: v.tableId, notes: v.notes || undefined, durationMinutes: v.durationMinutes });
      toast.success('Walk-in seated.');
      reset({ guestCount: 2, durationMinutes: 75, tableId: '', guestName: '', phone: '', notes: '' });
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      dash.reload({ silent: true });
    }
  });

  return (
    <NeedVenue wp={wp}>
      <PageHeader title="Walk-in" subtitle="Seat a party that arrived without a reservation. Availability is validated by the server." />
      <form onSubmit={onSubmit} noValidate className="card grid max-w-2xl gap-5 p-6 sm:grid-cols-2">
        <Field label="Guest name" className="sm:col-span-2" error={errors.guestName?.message} {...register('guestName')} />
        <Field label="Contact (optional)" type="tel" error={errors.phone?.message} {...register('phone')} />
        <Field label="Party size" type="number" min={1} error={errors.guestCount?.message} {...register('guestCount')} />
        <Field label="Table" as="select" error={errors.tableId?.message} hint={tables.length ? 'Showing free tables that fit the party' : 'No free table fits this party right now'} {...register('tableId')}>
          <option value="">Choose a table</option>
          {tables.map((t) => <option key={t.id} value={t.id}>{t.displayName} (seats {t.capacity})</option>)}
        </Field>
        <Field label="Expected stay (minutes)" type="number" min={15} step={15} error={errors.durationMinutes?.message} hint="Must not clash with an upcoming reservation" {...register('durationMinutes')} />
        <Field label="Notes (optional)" as="textarea" rows={2} className="sm:col-span-2" error={errors.notes?.message} {...register('notes')} />
        <div className="sm:col-span-2"><Button type="submit" loading={isSubmitting}><Footprints size={16} aria-hidden /> Seat walk-in</Button></div>
      </form>
    </NeedVenue>
  );
}

const STATUSES = ['available', 'reserved', 'occupied', 'cleaning', 'out_of_service'];

export function TableStatus() {
  const { wp, id } = useVenue();
  const toast = useToast();
  const { data, loading, error, reload } = useAsync(() => (id ? get('/staff/dashboard', { restaurantId: id }) : Promise.resolve(null)), [id]);
  const { connected } = useLiveRefresh(id, () => reload({ silent: true }));
  const [busy, setBusy] = useState(null);

  const setStatus = async (t, status) => {
    setBusy(t.id);
    try {
      await patch(`/staff/tables/${t.id}/status`, { status });
      toast.success(`${t.displayName} is now ${humanize(status).toLowerCase()}.`);
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusy(null);
      reload({ silent: true });
    }
  };

  return (
    <NeedVenue wp={wp}>
      <PageHeader title="Table status" subtitle="Live status combines reservations with manual updates." actions={<LiveBadge connected={connected} />} />
      {error ? <ErrorState message={error} onRetry={reload} /> : loading && !data ? <Skeleton className="h-64" /> : (
        <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {data?.data?.tables.map((t) => (
            <li key={t.id} className="card p-4">
              <div className="flex items-start justify-between"><div><p className="font-display text-2xl">{t.displayName}</p><p className="text-xs text-paper-2">Seats {t.capacity}</p></div><StatusBadge status={t.status} /></div>
              <Field label="Set status" as="select" className="mt-4" value={t.manualStatus} disabled={busy === t.id} onChange={(e) => setStatus(t, e.target.value)}>
                {STATUSES.map((s) => <option key={s} value={s}>{humanize(s)}</option>)}
              </Field>
            </li>
          ))}
        </ul>
      )}
    </NeedVenue>
  );
}
