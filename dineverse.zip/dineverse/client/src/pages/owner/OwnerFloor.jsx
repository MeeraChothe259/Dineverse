import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Armchair, Pencil, Plus, Trash2, Utensils } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import SeatingExperience from '../../components/reservation/SeatingExperience.jsx';
import { Button, ConfirmDialog, DataTable, EmptyState, ErrorState, Field, Modal, PageHeader, Skeleton, StatusBadge } from '../../components/common/ui.jsx';
import { useToast } from '../../context/ToastContext.jsx';
import { useAsync } from '../../hooks/useAsync.js';
import { del, errorMessage, get, patch, post, put } from '../../services/api.js';
import { inr } from '../../utils/format.js';

/* ---------------------------------- Menu ---------------------------------- */
const DIET = ['vegetarian', 'vegan', 'gluten_free', 'contains_nuts', 'dairy_free', 'spicy', 'jain'];
const menuSchema = z.object({
  category: z.string().trim().min(1, 'Enter a category'),
  name: z.string().trim().min(1, 'Enter a name'),
  description: z.string().trim().max(500).optional(),
  price: z.coerce.number().min(0, 'Enter a price'),
  image: z.string().trim().max(600).optional(),
  dietaryLabels: z.array(z.string()).optional(),
  isAvailable: z.boolean(),
});

export function OwnerMenu() {
  const { id } = useParams();
  const toast = useToast();
  const { data, loading, error, reload } = useAsync(() => get(`/owner/restaurants/${id}/menu`), [id]);
  const [editing, setEditing] = useState(null); // item | {} for new
  const [removing, setRemoving] = useState(null);
  const { register, handleSubmit, reset, formState: { errors, isSubmitting } } = useForm({ resolver: zodResolver(menuSchema) });

  useEffect(() => {
    if (editing) reset({ category: editing.category || '', name: editing.name || '', description: editing.description || '', price: editing.price ?? '', image: editing.image || '', dietaryLabels: editing.dietaryLabels || [], isAvailable: editing.isAvailable ?? true });
  }, [editing, reset]);

  const save = handleSubmit(async (v) => {
    const body = { ...v, dietaryLabels: v.dietaryLabels || [], description: v.description || '', image: v.image || '' };
    try {
      if (editing._id) await patch(`/owner/menu/${editing._id}`, body);
      else await post(`/owner/restaurants/${id}/menu`, body);
      toast.success('Menu saved.');
      setEditing(null);
      reload({ silent: true });
    } catch (e) { toast.error(errorMessage(e)); }
  });
  const toggle = async (i) => { try { await patch(`/owner/menu/${i._id}`, { isAvailable: !i.isAvailable }); reload({ silent: true }); } catch (e) { toast.error(errorMessage(e)); } };
  const remove = async () => { try { await del(`/owner/menu/${removing._id}`); toast.success('Item deleted.'); reload({ silent: true }); } catch (e) { toast.error(errorMessage(e)); } finally { setRemoving(null); } };

  const items = data?.data || [];
  const cats = [...new Set(items.map((i) => i.category))];

  return (
    <>
      <PageHeader title="Menu management" actions={<Button onClick={() => setEditing({})}><Plus size={16} aria-hidden /> Add item</Button>} />
      {error ? <ErrorState message={error} onRetry={reload} /> : loading && !data ? <Skeleton className="h-64" /> : !items.length ? <EmptyState icon={Utensils} title="No menu items" action={<Button onClick={() => setEditing({})}>Add the first item</Button>} /> : cats.map((c) => (
        <section key={c} className="mb-8">
          <h2 className="mb-3 text-2xl text-champagne">{c}</h2>
          <DataTable rowKey="_id" rows={items.filter((i) => i.category === c)} columns={[
            { key: 'name', header: 'Item', render: (i) => <div><p>{i.name}</p>{i.description && <p className="text-xs text-paper-2">{i.description}</p>}</div> },
            { key: 'price', header: 'Price', render: (i) => inr(i.price) },
            { key: 'diet', header: 'Dietary', render: (i) => <span className="text-xs text-ok">{(i.dietaryLabels || []).join(', ')}</span> },
            { key: 'av', header: 'Available', render: (i) => <label className="flex items-center gap-2 text-xs"><input type="checkbox" className="accent-[#C9A76A]" checked={i.isAvailable} onChange={() => toggle(i)} aria-label={`${i.name} available`} />{i.isAvailable ? 'Yes' : 'No'}</label> },
            { key: 'a', header: '', render: (i) => <div className="flex gap-2"><Button size="sm" variant="outline" aria-label={`Edit ${i.name}`} onClick={() => setEditing(i)}><Pencil size={13} aria-hidden /></Button><Button size="sm" variant="danger" aria-label={`Delete ${i.name}`} onClick={() => setRemoving(i)}><Trash2 size={13} aria-hidden /></Button></div> },
          ]} />
        </section>
      ))}
      <Modal open={!!editing} onClose={() => setEditing(null)} title={editing?._id ? 'Edit menu item' : 'Add menu item'} footer={<><Button variant="ghost" onClick={() => setEditing(null)}>Cancel</Button><Button onClick={save} loading={isSubmitting}>Save</Button></>}>
        <form onSubmit={save} noValidate className="space-y-4">
          <Field label="Category" error={errors.category?.message} hint="e.g. Starters, Mains, Desserts" {...register('category')} />
          <Field label="Name" error={errors.name?.message} {...register('name')} />
          <Field label="Description" as="textarea" rows={2} {...register('description')} />
          <Field label="Price (₹)" type="number" step="1" error={errors.price?.message} {...register('price')} />
          <Field label="Image URL (optional)" {...register('image')} />
          <fieldset><legend className="label">Dietary labels</legend><div className="flex flex-wrap gap-3">{DIET.map((d) => <label key={d} className="flex items-center gap-1.5 text-xs"><input type="checkbox" value={d} className="accent-[#C9A76A]" {...register('dietaryLabels')} />{d.replace('_', ' ')}</label>)}</div></fieldset>
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" className="accent-[#C9A76A]" {...register('isAvailable')} /> Available</label>
          <button type="submit" className="sr-only-live">Save</button>
        </form>
      </Modal>
      <ConfirmDialog open={!!removing} danger title="Delete this item?" confirmLabel="Delete" message={removing ? `“${removing.name}” will be removed from the menu.` : ''} onConfirm={remove} onClose={() => setRemoving(null)} />
    </>
  );
}

/* --------------------------------- Tables --------------------------------- */
const tableSchema = z.object({
  tableNumber: z.string().trim().min(1, 'Enter a table number'),
  displayName: z.string().trim().optional(),
  capacity: z.coerce.number().int().min(1, 'At least 1').max(40),
  shape: z.enum(['round', 'square', 'rectangle']),
  width: z.coerce.number().min(0.4).max(8),
  depth: z.coerce.number().min(0.4).max(8),
});

export function OwnerTables() {
  const { id } = useParams();
  const toast = useToast();
  const { data, loading, error, reload } = useAsync(() => get(`/owner/restaurants/${id}/tables`), [id]);
  const [editing, setEditing] = useState(null);
  const [removing, setRemoving] = useState(null);
  const { register, handleSubmit, reset, formState: { errors, isSubmitting } } = useForm({ resolver: zodResolver(tableSchema) });
  useEffect(() => {
    if (editing) reset({ tableNumber: editing.tableNumber || '', displayName: editing.displayName || '', capacity: editing.capacity || 2, shape: editing.shape || 'round', width: editing.dimensions?.width || 1.2, depth: editing.dimensions?.depth || 1.2 });
  }, [editing, reset]);

  const save = handleSubmit(async (v) => {
    const body = { tableNumber: v.tableNumber, displayName: v.displayName || undefined, capacity: v.capacity, shape: v.shape, dimensions: { width: v.width, depth: v.shape === 'round' ? v.width : v.depth } };
    try {
      if (editing.id) await patch(`/owner/tables/${editing.id}`, body);
      else await post(`/owner/restaurants/${id}/tables`, { ...body, position: { x: 10, y: 7 } });
      toast.success('Table saved. Position it on the floor plan.');
      setEditing(null);
      reload({ silent: true });
    } catch (e) { toast.error(errorMessage(e)); }
  });
  const setActive = async (t, isActive) => { try { await patch(`/owner/tables/${t.id}`, { isActive }); reload({ silent: true }); } catch (e) { toast.error(errorMessage(e)); } };
  const remove = async () => { try { await del(`/owner/tables/${removing.id}`); toast.success('Table deactivated.'); reload({ silent: true }); } catch (e) { toast.error(errorMessage(e)); } finally { setRemoving(null); } };
  const tables = data?.data?.tables || [];

  return (
    <>
      <PageHeader title="Tables" subtitle="Capacity, shape and size. Drag tables into position on the floor plan." actions={<><Link to={`/owner/restaurants/${id}/floor-plan`} className="btn-outline">Open floor plan</Link><Button onClick={() => setEditing({})}><Plus size={16} aria-hidden /> Add table</Button></>} />
      {error ? <ErrorState message={error} onRetry={reload} /> : loading && !data ? <Skeleton className="h-64" /> : (
        <DataTable rows={tables} empty={<EmptyState icon={Armchair} title="No tables yet" action={<Button onClick={() => setEditing({})}>Add a table</Button>} />} columns={[
          { key: 'n', header: 'Table', render: (t) => <div><p>{t.displayName}</p><p className="text-xs text-paper-2">#{t.tableNumber}</p></div> },
          { key: 'capacity', header: 'Seats' },
          { key: 'shape', header: 'Shape', render: (t) => t.shape },
          { key: 'size', header: 'Size (m)', render: (t) => `${t.dimensions?.width} × ${t.shape === 'round' ? t.dimensions?.width : t.dimensions?.depth}` },
          { key: 's', header: 'Status', render: (t) => <StatusBadge status={t.isActive ? 'active' : 'suspended'} /> },
          { key: 'a', header: '', render: (t) => <div className="flex gap-2"><Button size="sm" variant="outline" onClick={() => setEditing(t)} aria-label={`Edit ${t.displayName}`}><Pencil size={13} aria-hidden /></Button>{t.isActive ? <Button size="sm" variant="danger" onClick={() => setRemoving(t)}>Deactivate</Button> : <Button size="sm" variant="outline" onClick={() => setActive(t, true)}>Reactivate</Button>}</div> },
        ]} />
      )}
      <Modal open={!!editing} onClose={() => setEditing(null)} title={editing?.id ? 'Edit table' : 'Add table'} footer={<><Button variant="ghost" onClick={() => setEditing(null)}>Cancel</Button><Button onClick={save} loading={isSubmitting}>Save</Button></>}>
        <form onSubmit={save} noValidate className="grid gap-4 sm:grid-cols-2">
          <Field label="Table number" error={errors.tableNumber?.message} {...register('tableNumber')} />
          <Field label="Display name" hint="Optional, e.g. Window 2" {...register('displayName')} />
          <Field label="Seats" type="number" error={errors.capacity?.message} {...register('capacity')} />
          <Field label="Shape" as="select" {...register('shape')}><option value="round">Round</option><option value="square">Square</option><option value="rectangle">Rectangle</option></Field>
          <Field label="Width / diameter (m)" type="number" step="0.1" error={errors.width?.message} {...register('width')} />
          <Field label="Depth (m)" type="number" step="0.1" error={errors.depth?.message} {...register('depth')} />
          <button type="submit" className="sr-only-live">Save</button>
        </form>
      </Modal>
      <ConfirmDialog open={!!removing} danger title="Deactivate this table?" confirmLabel="Deactivate" message="It will disappear from the floor plan and can no longer be booked. Tables with upcoming reservations can't be deactivated." onConfirm={remove} onClose={() => setRemoving(null)} />
    </>
  );
}

/* ------------------------------- Floor plan ------------------------------- */
const SNAP = 0.25;
const snap = (v) => Math.round(v / SNAP) * SNAP;
let tempId = 0;

export function FloorPlanEditor() {
  const { id } = useParams();
  const toast = useToast();
  const { data, loading, error, reload } = useAsync(() => get(`/owner/restaurants/${id}/floor-plan`), [id]);
  const [room, setRoom] = useState({ width: 20, depth: 14 });
  const [tables, setTables] = useState(null);
  const [sel, setSel] = useState(null);
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const [preview, setPreview] = useState(false);
  const svg = useRef(null);
  const drag = useRef(null);

  useEffect(() => {
    if (data?.data) {
      setRoom(data.data.floorPlan);
      setTables(data.data.tables.filter((t) => t.isActive).map((t) => ({ ...t, key: t.id })));
      setDirty(false);
    }
  }, [data]);

  const selected = tables?.find((t) => t.key === sel);
  const upd = useCallback((key, patchObj) => { setTables((ts) => ts.map((t) => (t.key === key ? { ...t, ...patchObj } : t))); setDirty(true); }, []);

  const toLocal = (e) => {
    const pt = svg.current.createSVGPoint();
    pt.x = e.clientX; pt.y = e.clientY;
    return pt.matrixTransform(svg.current.getScreenCTM().inverse());
  };
  const onDown = (e, t) => {
    e.currentTarget.setPointerCapture?.(e.pointerId);
    const p = toLocal(e);
    drag.current = { key: t.key, dx: t.position.x - p.x, dy: t.position.y - p.y };
    setSel(t.key);
  };
  const onMove = (e) => {
    const d = drag.current;
    if (!d) return;
    const p = toLocal(e);
    upd(d.key, { position: { x: Math.min(room.width - 0.5, Math.max(0.5, snap(p.x + d.dx))), y: Math.min(room.depth - 0.5, Math.max(0.5, snap(p.y + d.dy))), z: 0 } });
  };
  const onUp = () => { drag.current = null; };
  const onKey = (e, t) => {
    const step = e.shiftKey ? 1 : SNAP;
    const m = { ArrowLeft: [-step, 0], ArrowRight: [step, 0], ArrowUp: [0, -step], ArrowDown: [0, step] }[e.key];
    if (m) { e.preventDefault(); upd(t.key, { position: { x: Math.min(room.width - 0.5, Math.max(0.5, t.position.x + m[0])), y: Math.min(room.depth - 0.5, Math.max(0.5, t.position.y + m[1])), z: 0 } }); }
  };

  const add = () => {
    const nums = tables.map((t) => parseInt(t.tableNumber, 10)).filter(Number.isFinite);
    const n = String((nums.length ? Math.max(...nums) : 0) + 1);
    const key = `new-${++tempId}`;
    setTables((ts) => [...ts, { key, id: undefined, tableNumber: n, displayName: `Table ${n}`, capacity: 4, shape: 'round', dimensions: { width: 1.4, depth: 1.4, height: 0.75 }, position: { x: room.width / 2, y: room.depth / 2, z: 0 }, rotation: 0, isActive: true, state: 'available', selectable: true }]);
    setSel(key); setDirty(true);
  };
  const remove = () => { setTables((ts) => ts.filter((t) => t.key !== sel)); setSel(null); setDirty(true); };

  const save = async () => {
    setSaving(true);
    try {
      const res = await put(`/owner/restaurants/${id}/floor-plan`, {
        room,
        tables: tables.map((t) => ({ id: t.id, tableNumber: t.tableNumber, displayName: t.displayName || undefined, capacity: Number(t.capacity), shape: t.shape, dimensions: { width: Number(t.dimensions.width), depth: Number(t.shape === 'round' ? t.dimensions.width : t.dimensions.depth) }, position: { x: t.position.x, y: t.position.y, z: 0 }, rotation: Number(t.rotation) || 0, isActive: true })),
      });
      toast.success(res.message);
      setSel(null);
      await reload({ silent: true });
    } catch (e) { toast.error(errorMessage(e)); } finally { setSaving(false); }
  };

  const previewTables = useMemo(() => (tables || []).map((t) => ({ ...t, id: t.key, state: 'available', selectable: true })), [tables]);

  if (error) return <ErrorState message={error} onRetry={reload} />;
  if (loading && !tables) return <Skeleton className="h-[500px]" />;
  if (!tables) return null;

  return (
    <>
      <PageHeader title="Floor plan" subtitle="Drag tables to position them (arrow keys nudge the selected table). The saved layout is rendered in 3D for guests." actions={<><Button variant="outline" onClick={add}><Plus size={16} aria-hidden /> Add table</Button><Button onClick={save} loading={saving} disabled={!dirty}>{dirty ? 'Save layout' : 'Saved'}</Button></>} />
      <div className="grid gap-6 lg:grid-cols-[1fr_300px]">
        <div className="min-w-0">
          <svg ref={svg} viewBox={`-0.5 -0.5 ${room.width + 1} ${room.depth + 1}`} className="w-full touch-none select-none rounded-xl border border-line bg-ink-2" role="group" aria-label="Floor plan editor. Select a table and use arrow keys to move it." onPointerMove={onMove} onPointerUp={onUp} onPointerLeave={onUp} onClick={() => setSel(null)}>
            <defs><pattern id="grid" width="1" height="1" patternUnits="userSpaceOnUse"><path d="M1 0H0V1" fill="none" stroke="#302C26" strokeWidth="0.03" /></pattern></defs>
            <rect width={room.width} height={room.depth} fill="url(#grid)" stroke="#C9A76A" strokeWidth="0.08" />
            <text x={room.width / 2} y="0.8" textAnchor="middle" fill="#77736D" fontSize="0.55">WINDOWS / FRONT OF ROOM</text>
            {tables.map((t) => {
              const w = t.dimensions.width; const d = t.shape === 'round' ? w : t.dimensions.depth; const on = t.key === sel;
              return (
                <g key={t.key} transform={`translate(${t.position.x} ${t.position.y}) rotate(${t.rotation || 0})`} tabIndex={0} role="button" aria-label={`${t.displayName}, seats ${t.capacity}`} aria-pressed={on} style={{ cursor: 'grab', outline: 'none' }} onPointerDown={(e) => { e.stopPropagation(); onDown(e, t); }} onClick={(e) => { e.stopPropagation(); setSel(t.key); }} onKeyDown={(e) => onKey(e, t)}>
                  {t.shape === 'round' ? <circle r={w / 2 + 0.3} fill={on ? '#E6D2A533' : '#C9A76A1a'} stroke={on ? '#E6D2A5' : '#C9A76A'} strokeWidth={on ? 0.14 : 0.07} /> : <rect x={-(w / 2 + 0.3)} y={-(d / 2 + 0.3)} width={w + 0.6} height={d + 0.6} rx="0.25" fill={on ? '#E6D2A533' : '#C9A76A1a'} stroke={on ? '#E6D2A5' : '#C9A76A'} strokeWidth={on ? 0.14 : 0.07} />}
                  <text textAnchor="middle" y="-0.05" fill="#F5F1E9" fontSize="0.5" fontWeight="600" style={{ pointerEvents: 'none' }}>{t.tableNumber}</text>
                  <text textAnchor="middle" y="0.5" fill="#AAA6A0" fontSize="0.4" style={{ pointerEvents: 'none' }}>{t.capacity} seats</text>
                </g>
              );
            })}
          </svg>
        </div>
        <aside className="space-y-4">
          <section className="card space-y-3 p-4">
            <h2 className="text-xl">Room size (m)</h2>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Width" type="number" min={6} max={80} value={room.width} onChange={(e) => { setRoom((r) => ({ ...r, width: Number(e.target.value) || 6 })); setDirty(true); }} />
              <Field label="Depth" type="number" min={6} max={80} value={room.depth} onChange={(e) => { setRoom((r) => ({ ...r, depth: Number(e.target.value) || 6 })); setDirty(true); }} />
            </div>
          </section>
          <section className="card space-y-3 p-4" aria-live="polite">
            <h2 className="text-xl">{selected ? selected.displayName || `Table ${selected.tableNumber}` : 'Selected table'}</h2>
            {!selected ? <p className="text-sm text-paper-2">Select a table on the plan to edit it.</p> : (
              <>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Number" value={selected.tableNumber} onChange={(e) => upd(sel, { tableNumber: e.target.value })} />
                  <Field label="Seats" type="number" min={1} max={40} value={selected.capacity} onChange={(e) => upd(sel, { capacity: e.target.value })} />
                </div>
                <Field label="Display name" value={selected.displayName || ''} onChange={(e) => upd(sel, { displayName: e.target.value })} />
                <Field label="Shape" as="select" value={selected.shape} onChange={(e) => upd(sel, { shape: e.target.value })}><option value="round">Round</option><option value="square">Square</option><option value="rectangle">Rectangle</option></Field>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Width (m)" type="number" step="0.1" min={0.4} max={8} value={selected.dimensions.width} onChange={(e) => upd(sel, { dimensions: { ...selected.dimensions, width: Number(e.target.value) } })} />
                  {selected.shape !== 'round' && <Field label="Depth (m)" type="number" step="0.1" min={0.4} max={8} value={selected.dimensions.depth} onChange={(e) => upd(sel, { dimensions: { ...selected.dimensions, depth: Number(e.target.value) } })} />}
                </div>
                <Field label={`Rotation (${selected.rotation || 0}°)`} type="range" min={-180} max={180} step={15} value={selected.rotation || 0} onChange={(e) => upd(sel, { rotation: Number(e.target.value) })} />
                <Button variant="danger" size="sm" onClick={remove}><Trash2 size={13} aria-hidden /> Remove from plan</Button>
              </>
            )}
          </section>
        </aside>
      </div>
      <div className="mt-8">
        <Button variant="outline" onClick={() => setPreview((p) => !p)} aria-expanded={preview}>{preview ? 'Hide 3D preview' : 'Preview in 3D'}</Button>
        {dirty && preview && <p className="mt-2 text-xs text-gold">Previewing unsaved changes.</p>}
        {preview && <div className="mt-4"><SeatingExperience layout={room} tables={previewTables} readOnly height={460} showLegend={false} /></div>}
      </div>
    </>
  );
}
