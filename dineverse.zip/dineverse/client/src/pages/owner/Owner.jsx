import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { LayoutGrid, Plus, Store, Users } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import ReservationsTable from '../../components/dashboard/ReservationsTable.jsx';
import { AnalyticsCharts, MetricCards } from '../../components/dashboard/Charts.jsx';
import { Button, DataTable, DemoBadge, EmptyState, ErrorState, Field, Modal, PageHeader, Pagination, Skeleton, StatusBadge } from '../../components/common/ui.jsx';
import { useAuth } from '../../context/AuthContext.jsx';
import { useWorkplace } from '../../context/WorkplaceContext.jsx';
import { useToast } from '../../context/ToastContext.jsx';
import { useAsync, useDebounced } from '../../hooks/useAsync.js';
import { errorMessage, get, patch, post } from '../../services/api.js';
import { WEEKDAYS, humanize, hoursSummary } from '../../utils/format.js';
import { Profile } from '../customer/Customer.jsx';
import { EXPERIENCE_META } from '../../utils/assets.js';

export function OwnerDashboard() {
  const { data, loading, error, reload } = useAsync(() => get('/owner/dashboard'), []);
  const d = data?.data;
  return (
    <>
      <PageHeader title="Overview" subtitle="Last 30 days across your restaurants" actions={<Link to="/owner/restaurants" className="btn-outline">Manage restaurants</Link>} />
      {loading && !d ? <Skeleton className="h-96" /> : error ? <ErrorState message={error} onRetry={reload} /> : !d.restaurants.length ? (
        <EmptyState icon={Store} title="No restaurants yet" message="Submit your first restaurant. A platform administrator reviews applications before they go live." action={<Link to="/owner/restaurants" className="btn-primary">Add a restaurant</Link>} />
      ) : (
        <div className="space-y-8">
          {d.restaurants.some((r) => r.status !== 'active') && (
            <p role="status" className="rounded-lg border border-gold/40 bg-gold/10 p-3 text-sm text-champagne">
              {d.restaurants.filter((r) => r.status === 'pending').length > 0 && 'Some restaurants are awaiting administrator approval and are not publicly visible yet. '}
              {d.restaurants.filter((r) => ['suspended', 'rejected'].includes(r.status)).length > 0 && 'Some restaurants are suspended or rejected: contact the platform administrator.'}
            </p>
          )}
          <MetricCards totals={d.analytics.totals} />
          <AnalyticsCharts data={d.analytics} />
          <section>
            <h2 className="mb-4 text-3xl">Next reservations</h2>
            <ReservationsTable rows={d.upcoming} showDate showRestaurant onChanged={reload} emptyText="Nothing upcoming" />
          </section>
        </div>
      )}
    </>
  );
}

const createSchema = z.object({
  name: z.string().trim().min(2, 'Enter the restaurant name'),
  city: z.string().trim().min(1, 'Enter the city'),
  cuisine: z.string().trim().optional(),
  description: z.string().trim().max(4000).optional(),
});

export function OwnerRestaurants() {
  const wp = useWorkplace();
  const toast = useToast();
  const [open, setOpen] = useState(false);
  const { register, handleSubmit, reset, formState: { errors, isSubmitting } } = useForm({ resolver: zodResolver(createSchema) });

  const submit = handleSubmit(async (v) => {
    try {
      const r = await post('/owner/restaurants', { name: v.name, address: { city: v.city }, cuisineTypes: (v.cuisine || '').split(',').map((s) => s.trim()).filter(Boolean), description: v.description || '' });
      toast.success(r.message);
      setOpen(false);
      reset();
      wp.reload();
    } catch (e) {
      toast.error(errorMessage(e));
    }
  });

  return (
    <>
      <PageHeader title="My restaurants" actions={<Button onClick={() => setOpen(true)}><Plus size={16} aria-hidden /> Add restaurant</Button>} />
      {wp.loading ? <Skeleton className="h-40" /> : wp.error ? <ErrorState message={wp.error} onRetry={wp.reload} /> : !wp.restaurants.length ? (
        <EmptyState icon={Store} title="No restaurants yet" action={<Button onClick={() => setOpen(true)}>Add your first restaurant</Button>} />
      ) : (
        <ul className="grid gap-5 md:grid-cols-2">
          {wp.restaurants.map((r) => (
            <li key={r.id} className="card p-5">
              <div className="flex items-start justify-between gap-3">
                <div><h2 className="text-3xl">{r.name}</h2><p className="text-sm text-paper-2">{r.address?.city} · {r.cuisineTypes?.join(', ') || 'No cuisine set'}</p></div>
                <StatusBadge status={r.status} />
              </div>
              {r.isDemo && <DemoBadge className="mt-3" label="Demo venue" />}
              {r.status === 'pending' && <p className="mt-3 text-xs text-gold">Awaiting administrator approval. Not public yet.</p>}
              {r.statusNote && <p className="mt-3 text-xs text-paper-2">Admin note: {r.statusNote}</p>}
              <p className="mt-3 text-xs text-paper-2">{r.tableCount} active table(s) · {hoursSummary(r.openingHours)}</p>
              <div className="mt-4 flex flex-wrap gap-2">
                <Link className="btn-outline btn-sm" to={`/owner/restaurants/${r.id}`}>Edit profile</Link>
                <Link className="btn-outline btn-sm" to={`/owner/restaurants/${r.id}/floor-plan`}><LayoutGrid size={13} aria-hidden /> Floor plan</Link>
                <Link className="btn-outline btn-sm" to={`/owner/restaurants/${r.id}/tables`}>Tables</Link>
                <Link className="btn-outline btn-sm" to={`/owner/restaurants/${r.id}/menu`}>Menu</Link>
                {r.status === 'active' && <Link className="btn-ghost btn-sm" to={`/restaurants/${r.slug}`}>View public page</Link>}
              </div>
            </li>
          ))}
        </ul>
      )}
      <Modal open={open} onClose={() => setOpen(false)} title="Add a restaurant" footer={<><Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button><Button onClick={submit} loading={isSubmitting}>Submit application</Button></>}>
        <form onSubmit={submit} noValidate className="space-y-4">
          <Field label="Restaurant name" error={errors.name?.message} {...register('name')} />
          <Field label="City" error={errors.city?.message} {...register('city')} />
          <Field label="Cuisine types" hint="Comma separated, e.g. North Indian, Tasting Menu" {...register('cuisine')} />
          <Field label="Description" as="textarea" rows={3} {...register('description')} />
          <p className="text-xs text-paper-2">New restaurants are submitted for approval. You can complete the profile, floor plan and menu while you wait.</p>
          <button type="submit" className="sr-only-live">Submit</button>
        </form>
      </Modal>
    </>
  );
}

const toLines = (a) => (a || []).join('\n');
const fromList = (s) => s.split(/[\n,]/).map((x) => x.trim()).filter(Boolean);

export function RestaurantEdit() {
  const { id } = useParams();
  const toast = useToast();
  const wp = useWorkplace();
  const { data, loading, error, reload } = useAsync(() => get(`/owner/restaurants/${id}`), [id]);
  const [f, setF] = useState(null);
  const [saving, setSaving] = useState(false);
  const r = data?.data;
  if (r && !f) {
    setF({
      name: r.name, tagline: r.tagline || '', description: r.description || '', cuisine: toLines(r.cuisineTypes), experiences: r.experiences || [],
      line1: r.address?.line1 || '', city: r.address?.city || '', state: r.address?.state || '', postalCode: r.address?.postalCode || '',
      phone: r.contact?.phone || '', email: r.contact?.email || '', website: r.contact?.website || '',
      timezone: r.timezone, priceRange: r.priceRange, images: (r.images || []).map((i) => i.url).join('\n'), amenities: toLines(r.amenities),
      hours: r.openingHours, settings: r.reservationSettings, policies: r.policies || '',
    });
  }
  if (loading && !r) return <Skeleton className="h-96" />;
  if (error) return <ErrorState message={error} onRetry={reload} />;
  if (!f) return null;
  const set = (patchObj) => setF((s) => ({ ...s, ...patchObj }));
  const setSetting = (k, v) => setF((s) => ({ ...s, settings: { ...s.settings, [k]: v } }));
  const setHour = (day, patchObj) => setF((s) => ({ ...s, hours: s.hours.map((h) => (h.day === day ? { ...h, ...patchObj } : h)) }));
  const S = f.settings;

  const save = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await patch(`/owner/restaurants/${id}`, {
        name: f.name, tagline: f.tagline, description: f.description, cuisineTypes: fromList(f.cuisine), experiences: f.experiences,
        address: { line1: f.line1, city: f.city, state: f.state, postalCode: f.postalCode, country: r.address?.country || 'India' },
        contact: { phone: f.phone, email: f.email, website: f.website },
        timezone: f.timezone, priceRange: Number(f.priceRange),
        images: fromList(f.images).map((url) => ({ url, alt: `${f.name} photo` })), amenities: fromList(f.amenities),
        openingHours: f.hours.map(({ day, open, close, closed }) => ({ day, open, close, closed })),
        reservationSettings: Object.fromEntries(Object.entries(S).filter(([k]) => ['acceptingReservations', 'durationMinutes', 'bufferMinutes', 'slotIntervalMinutes', 'minPartySize', 'maxPartySize', 'advanceBookingDays', 'cancellationCutoffHours', 'checkInWindowMinutes'].includes(k)).map(([k, v]) => [k, typeof v === 'boolean' ? v : Number(v)])),
        policies: f.policies,
      });
      toast.success('Restaurant updated.');
      wp.reload();
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  const num = (k, label, props = {}) => <Field label={label} type="number" value={S[k]} onChange={(e) => setSetting(k, e.target.value)} {...props} />;

  return (
    <form onSubmit={save} className="space-y-8">
      <PageHeader title={`Edit ${r.name}`} subtitle={`Status: ${humanize(r.status)}`} actions={<Button type="submit" loading={saving}>Save changes</Button>} />
      <section className="card grid gap-5 p-6 sm:grid-cols-2">
        <h2 className="text-2xl sm:col-span-2">Profile</h2>
        <Field label="Name" value={f.name} onChange={(e) => set({ name: e.target.value })} required />
        <Field label="Tagline" value={f.tagline} onChange={(e) => set({ tagline: e.target.value })} />
        <Field label="Description" as="textarea" rows={4} className="sm:col-span-2" value={f.description} onChange={(e) => set({ description: e.target.value })} />
        <Field label="Cuisine types" as="textarea" rows={3} hint="One per line or comma separated" value={f.cuisine} onChange={(e) => set({ cuisine: e.target.value })} />
        <Field label="Amenities" as="textarea" rows={3} hint="One per line or comma separated" value={f.amenities} onChange={(e) => set({ amenities: e.target.value })} />
        <fieldset className="sm:col-span-2"><legend className="label">Experience categories</legend>
          <div className="flex flex-wrap gap-2">{Object.keys(EXPERIENCE_META).map((x) => <label key={x} className="flex cursor-pointer items-center gap-2 rounded-full border border-line px-3 py-1 text-xs has-[:checked]:border-gold has-[:checked]:text-champagne"><input type="checkbox" className="accent-[#C9A76A]" checked={f.experiences.includes(x)} onChange={(e) => set({ experiences: e.target.checked ? [...f.experiences, x] : f.experiences.filter((y) => y !== x) })} />{x}</label>)}</div>
        </fieldset>
        <Field label="Price range" as="select" value={f.priceRange} onChange={(e) => set({ priceRange: e.target.value })}>{[1, 2, 3, 4].map((p) => <option key={p} value={p}>{'₹'.repeat(p)}</option>)}</Field>
        <Field label="Timezone (IANA)" value={f.timezone} onChange={(e) => set({ timezone: e.target.value })} hint="e.g. Asia/Kolkata" />
      </section>

      <section className="card grid gap-5 p-6 sm:grid-cols-2">
        <h2 className="text-2xl sm:col-span-2">Location & contact</h2>
        <Field label="Address" className="sm:col-span-2" value={f.line1} onChange={(e) => set({ line1: e.target.value })} />
        <Field label="City" value={f.city} onChange={(e) => set({ city: e.target.value })} required />
        <Field label="State" value={f.state} onChange={(e) => set({ state: e.target.value })} />
        <Field label="Postal code" value={f.postalCode} onChange={(e) => set({ postalCode: e.target.value })} />
        <Field label="Phone" value={f.phone} onChange={(e) => set({ phone: e.target.value })} />
        <Field label="Contact email" value={f.email} onChange={(e) => set({ email: e.target.value })} />
        <Field label="Website" value={f.website} onChange={(e) => set({ website: e.target.value })} />
        <Field label="Image URLs" as="textarea" rows={3} className="sm:col-span-2" hint="One https image URL per line. Only use images you have the rights to. Missing images show a tasteful placeholder." value={f.images} onChange={(e) => set({ images: e.target.value })} />
      </section>

      <section className="card p-6">
        <h2 className="mb-4 text-2xl">Opening hours</h2>
        <ul className="space-y-3">
          {f.hours.map((h) => (
            <li key={h.day} className="grid items-center gap-3 sm:grid-cols-[120px_1fr_1fr_auto]">
              <span className="text-sm">{WEEKDAYS[h.day]}</span>
              <input aria-label={`${WEEKDAYS[h.day]} opens`} type="time" className="input" disabled={h.closed} value={h.open} onChange={(e) => setHour(h.day, { open: e.target.value })} />
              <input aria-label={`${WEEKDAYS[h.day]} closes`} type="time" className="input" disabled={h.closed} value={h.close} onChange={(e) => setHour(h.day, { close: e.target.value })} />
              <label className="flex items-center gap-2 text-sm text-paper-2"><input type="checkbox" className="accent-[#C9A76A]" checked={h.closed} onChange={(e) => setHour(h.day, { closed: e.target.checked })} /> Closed</label>
            </li>
          ))}
        </ul>
        <p className="mt-3 text-xs text-paper-2">A closing time earlier than the opening time means the restaurant closes after midnight.</p>
      </section>

      <section className="card grid gap-5 p-6 sm:grid-cols-3">
        <h2 className="text-2xl sm:col-span-3">Reservation settings</h2>
        <label className="flex items-center gap-2 text-sm sm:col-span-3"><input type="checkbox" className="accent-[#C9A76A]" checked={S.acceptingReservations} onChange={(e) => setSetting('acceptingReservations', e.target.checked)} /> Accepting online reservations</label>
        {num('durationMinutes', 'Booking duration (min)', { min: 30, max: 360, step: 15 })}
        {num('bufferMinutes', 'Buffer between bookings (min)', { min: 0, max: 120, step: 5 })}
        {num('slotIntervalMinutes', 'Time slot interval (min)', { min: 15, max: 120, step: 15 })}
        {num('minPartySize', 'Min party size', { min: 1 })}
        {num('maxPartySize', 'Max party size', { min: 1 })}
        {num('advanceBookingDays', 'Book up to (days ahead)', { min: 1 })}
        {num('cancellationCutoffHours', 'Free cancellation until (hours before)', { min: 0 })}
        {num('checkInWindowMinutes', 'Check-in opens (min before)', { min: 0 })}
        <Field label="Cancellation & reservation policy" as="textarea" rows={3} className="sm:col-span-3" value={f.policies} onChange={(e) => set({ policies: e.target.value })} />
      </section>
      <div className="flex justify-end"><Button type="submit" loading={saving}>Save changes</Button></div>
    </form>
  );
}

export function OwnerReservations() {
  const wp = useWorkplace();
  const [status, setStatus] = useState('');
  const [date, setDate] = useState('');
  const [rid, setRid] = useState('');
  const [q, setQ] = useState('');
  const [page, setPage] = useState(1);
  const dq = useDebounced(q);
  const { data, loading, error, reload } = useAsync(() => get('/owner/reservations', { restaurantId: rid || undefined, status: status || undefined, date: date || undefined, q: dq || undefined, page, limit: 15 }), [rid, status, date, dq, page]);
  return (
    <>
      <PageHeader title="Reservations" />
      <div className="mb-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Field label="Restaurant" as="select" value={rid} onChange={(e) => { setRid(e.target.value); setPage(1); }}><option value="">All</option>{wp.restaurants.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}</Field>
        <Field label="Status" as="select" value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }}><option value="">All</option>{['confirmed', 'checked_in', 'seated', 'completed', 'cancelled', 'no_show'].map((s) => <option key={s} value={s}>{humanize(s)}</option>)}</Field>
        <Field label="Date" type="date" value={date} onChange={(e) => { setDate(e.target.value); setPage(1); }} />
        <Field label="Search" placeholder="Guest or reference" value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} />
      </div>
      {error ? <ErrorState message={error} onRetry={reload} /> : loading && !data ? <Skeleton className="h-64" /> : (
        <>
          <ReservationsTable rows={data.data} showDate showRestaurant onChanged={() => reload({ silent: true })} />
          <Pagination meta={data.meta} onPage={setPage} />
        </>
      )}
    </>
  );
}

const staffSchema = z.object({
  restaurantId: z.string().min(1, 'Choose a restaurant'),
  email: z.string().trim().email('Enter a valid email'),
  name: z.string().trim().optional(),
  password: z.string().optional(),
  assignedRole: z.enum(['host', 'server', 'manager']),
});
const PERMS = [['reservations', 'View & manage reservations'], ['checkin', 'Check guests in'], ['walkin', 'Create walk-ins'], ['tables', 'Update table status']];

export function OwnerStaff() {
  const wp = useWorkplace();
  const toast = useToast();
  const { data, loading, error, reload } = useAsync(() => get('/owner/staff'), []);
  const [perms, setPerms] = useState(PERMS.map((p) => p[0]));
  const { register, handleSubmit, reset, formState: { errors, isSubmitting } } = useForm({ resolver: zodResolver(staffSchema), defaultValues: { assignedRole: 'host', restaurantId: wp.currentId || '' } });

  const add = handleSubmit(async (v) => {
    try {
      await post('/owner/staff', { restaurantId: v.restaurantId, email: v.email, name: v.name || undefined, password: v.password || undefined, assignedRole: v.assignedRole, permissions: perms });
      toast.success('Staff member assigned.');
      reset({ assignedRole: 'host', restaurantId: v.restaurantId });
      reload();
    } catch (e) {
      toast.error(errorMessage(e));
    }
  });
  const toggle = async (row) => {
    try { await patch(`/owner/staff/${row.id}`, { isActive: !row.isActive }); toast.success(row.isActive ? 'Access removed.' : 'Access restored.'); reload({ silent: true }); } catch (e) { toast.error(errorMessage(e)); }
  };

  return (
    <>
      <PageHeader title="Staff" subtitle="Staff can only see and act on the restaurants you assign them to." />
      <form onSubmit={add} noValidate className="card mb-8 grid gap-4 p-6 sm:grid-cols-2 lg:grid-cols-3">
        <h2 className="text-2xl sm:col-span-2 lg:col-span-3"><Users size={18} className="mr-2 inline text-gold" aria-hidden />Add or assign staff</h2>
        <Field label="Restaurant" as="select" error={errors.restaurantId?.message} {...register('restaurantId')}><option value="">Choose…</option>{wp.restaurants.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}</Field>
        <Field label="Email" type="email" error={errors.email?.message} {...register('email')} />
        <Field label="Role" as="select" {...register('assignedRole')}><option value="host">Host</option><option value="server">Server</option><option value="manager">Manager</option></Field>
        <Field label="Name (new accounts)" {...register('name')} />
        <Field label="Temporary password (new accounts)" type="password" autoComplete="new-password" hint="8+ chars, letter and number. Share it securely." {...register('password')} />
        <fieldset className="sm:col-span-2 lg:col-span-3"><legend className="label">Permissions</legend><div className="flex flex-wrap gap-4">{PERMS.map(([k, l]) => <label key={k} className="flex items-center gap-2 text-sm"><input type="checkbox" className="accent-[#C9A76A]" checked={perms.includes(k)} onChange={(e) => setPerms((p) => (e.target.checked ? [...p, k] : p.filter((x) => x !== k)))} />{l}</label>)}</div></fieldset>
        <div className="sm:col-span-2 lg:col-span-3"><Button type="submit" loading={isSubmitting}>Add staff member</Button></div>
      </form>
      {error ? <ErrorState message={error} onRetry={reload} /> : loading && !data ? <Skeleton className="h-40" /> : (
        <DataTable rows={data.data} empty={<EmptyState icon={Users} title="No staff yet" />} columns={[
          { key: 'u', header: 'Name', render: (r) => <div><p>{r.user.name}</p><p className="text-xs text-paper-2">{r.user.email}</p></div> },
          { key: 'r', header: 'Restaurant', render: (r) => r.restaurant.name },
          { key: 'role', header: 'Role', render: (r) => humanize(r.assignedRole) },
          { key: 'p', header: 'Permissions', render: (r) => <span className="text-xs text-paper-2">{r.permissions.join(', ')}</span> },
          { key: 's', header: 'Access', render: (r) => <StatusBadge status={r.isActive ? 'active' : 'suspended'} /> },
          { key: 'a', header: '', render: (r) => <Button size="sm" variant={r.isActive ? 'danger' : 'outline'} onClick={() => toggle(r)}>{r.isActive ? 'Remove access' : 'Restore'}</Button> },
        ]} />
      )}
    </>
  );
}

export function OwnerAnalytics() {
  const wp = useWorkplace();
  const [rid, setRid] = useState('');
  const [days, setDays] = useState(30);
  const { data, loading, error, reload } = useAsync(() => get('/owner/analytics', { restaurantId: rid || undefined, days }), [rid, days]);
  return (
    <>
      <PageHeader title="Analytics" subtitle="Calculated from stored reservations. No revenue figures are shown because payments aren't recorded." />
      <div className="mb-6 flex flex-wrap gap-3">
        <Field label="Restaurant" as="select" className="w-56" value={rid} onChange={(e) => setRid(e.target.value)}><option value="">All restaurants</option>{wp.restaurants.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}</Field>
        <Field label="Look-back" as="select" className="w-40" value={days} onChange={(e) => setDays(Number(e.target.value))}>{[7, 30, 90, 180].map((d) => <option key={d} value={d}>{d} days</option>)}</Field>
      </div>
      {error ? <ErrorState message={error} onRetry={reload} /> : loading && !data ? <Skeleton className="h-96" /> : (
        <div className="space-y-8"><MetricCards totals={data.data.totals} /><AnalyticsCharts data={data.data} /></div>
      )}
    </>
  );
}

export function OwnerSettings() {
  const { user } = useAuth();
  return (
    <>
      <Profile />
      <section className="card mt-8 p-6 text-sm text-paper-2">
        <h2 className="mb-2 text-2xl text-paper">Account</h2>
        <p>Role: <b className="text-paper">{user.role}</b>. Restaurant-level settings (hours, reservation rules, policies) live under <Link to="/owner/restaurants" className="text-champagne hover:underline">My Restaurants → Edit profile</Link>.</p>
        <p className="mt-2">Subscription billing is not part of this version.</p>
      </section>
    </>
  );
}
