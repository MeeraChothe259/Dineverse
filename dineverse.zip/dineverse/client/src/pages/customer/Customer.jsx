import { useState } from 'react';
import { Link, useLocation, useParams } from 'react-router-dom';
import { CalendarX, CheckCircle2, Heart, Info } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import ReservationCard from '../../components/reservation/ReservationCard.jsx';
import RestaurantCard from '../../components/restaurant/RestaurantCard.jsx';
import RestaurantImage from '../../components/common/RestaurantImage.jsx';
import { Button, ConfirmDialog, DemoBadge, EmptyState, ErrorState, Field, PageHeader, Pagination, Skeleton, StatusBadge, StatCard } from '../../components/common/ui.jsx';
import { useAuth } from '../../context/AuthContext.jsx';
import { useToast } from '../../context/ToastContext.jsx';
import { useAsync } from '../../hooks/useAsync.js';
import { errorMessage, get, patch, post } from '../../services/api.js';
import { fmtDate, fmtDateTime, fmtTime } from '../../utils/format.js';

const greeting = () => {
  const h = new Date().getHours();
  return h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening';
};

function ListSkeleton() {
  return <div className="space-y-4">{[0, 1].map((i) => <Skeleton key={i} className="h-40" />)}</div>;
}

export function CustomerDashboard() {
  const { user } = useAuth();
  const up = useAsync(() => get('/reservations/my', { group: 'upcoming', limit: 3 }), []);
  const past = useAsync(() => get('/reservations/my', { group: 'past', limit: 5 }), []);
  const favs = useAsync(() => get('/favorites'), []);
  const next = up.data?.data?.[0];

  return (
    <>
      <PageHeader title={`${greeting()}, ${user.name.split(' ')[0]}`} subtitle="Here's what's coming up." actions={<Link to="/restaurants" className="btn-primary">Quick book</Link>} />
      <section aria-labelledby="next-h" className="mb-10">
        <h2 id="next-h" className="mb-4 text-3xl">Next reservation</h2>
        {up.loading ? <Skeleton className="h-40" /> : up.error ? <ErrorState message={up.error} onRetry={up.reload} /> : next ? <ReservationCard reservation={next} /> : <EmptyState icon={CalendarX} title="Nothing booked yet" message="Find a restaurant and choose your table." action={<Link to="/restaurants" className="btn-primary">Discover restaurants</Link>} />}
      </section>
      <div className="mb-10 grid gap-4 sm:grid-cols-3">
        <StatCard label="Upcoming" value={up.data?.meta?.total ?? '–'} />
        <StatCard label="Past visits" value={past.data?.meta?.total ?? '–'} />
        <StatCard label="Favorites" value={favs.data?.data?.length ?? '–'} icon={Heart} />
      </div>
      <section className="mb-10">
        <div className="mb-4 flex items-end justify-between"><h2 className="text-3xl">Recent activity</h2><Link to="/customer/reservations" className="text-sm text-champagne hover:underline">All reservations</Link></div>
        {past.loading ? <Skeleton className="h-24" /> : past.data?.data?.length ? (
          <ul className="divide-y divide-line rounded-xl border border-line">
            {past.data.data.map((r) => (
              <li key={r.id} className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 text-sm">
                <span><Link className="text-paper hover:text-champagne" to={`/customer/reservations/${r.id}`}>{r.restaurant?.name}</Link> <span className="text-paper-2">· {fmtDate(r.startAt, r.restaurant?.timezone)}</span></span>
                <StatusBadge status={r.status} />
              </li>
            ))}
          </ul>
        ) : <p className="text-sm text-paper-2">No past reservations yet.</p>}
      </section>
      {favs.data?.data?.length > 0 && (
        <section>
          <h2 className="mb-4 text-3xl">Favorite restaurants</h2>
          <div className="grid gap-6 md:grid-cols-3">{favs.data.data.slice(0, 3).map((r) => <RestaurantCard key={r.id} restaurant={r} />)}</div>
        </section>
      )}
      <p className="mt-10 flex items-center gap-2 text-xs text-paper-2"><Info size={14} aria-hidden /> Confirmations are shown in the app; email and SMS are not sent in this version.</p>
    </>
  );
}

export function CustomerReservations() {
  const toast = useToast();
  const [group, setGroup] = useState('upcoming');
  const [page, setPage] = useState(1);
  const { data, loading, error, reload } = useAsync(() => get('/reservations/my', { group, page, limit: 8 }), [group, page]);
  const [target, setTarget] = useState(null);
  const [busy, setBusy] = useState(false);

  const cancel = async () => {
    setBusy(true);
    try {
      await patch(`/reservations/${target.id}/cancel`, {});
      toast.success('Reservation cancelled.');
      setTarget(null);
      reload();
    } catch (e) {
      toast.error(errorMessage(e));
      setTarget(null);
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <PageHeader title="My reservations" />
      <div role="tablist" aria-label="Reservation groups" className="mb-6 flex gap-1 border-b border-line">
        {[['upcoming', 'Upcoming'], ['past', 'Past'], ['cancelled', 'Cancelled']].map(([id, label]) => (
          <button key={id} role="tab" aria-selected={group === id} onClick={() => { setGroup(id); setPage(1); }} className={`-mb-px border-b-2 px-4 py-2.5 text-sm transition ${group === id ? 'border-gold text-champagne' : 'border-transparent text-paper-2 hover:text-paper'}`}>{label}</button>
        ))}
      </div>
      <div role="tabpanel" aria-busy={loading}>
        {loading && !data ? <ListSkeleton /> : error ? <ErrorState message={error} onRetry={reload} /> : data?.data?.length ? (
          <>
            <div className="space-y-4">{data.data.map((r) => <ReservationCard key={r.id} reservation={r} onCancel={setTarget} />)}</div>
            <Pagination meta={data.meta} onPage={setPage} />
          </>
        ) : <EmptyState icon={CalendarX} title={`No ${group} reservations`} message={group === 'upcoming' ? 'Ready for your next meal out?' : undefined} action={group === 'upcoming' ? <Link to="/restaurants" className="btn-primary">Discover restaurants</Link> : undefined} />}
      </div>
      <ConfirmDialog open={!!target} danger loading={busy} title="Cancel this reservation?" confirmLabel="Cancel reservation" message={target ? `${target.restaurant?.name} · ${fmtDateTime(target.startAt, target.restaurant?.timezone)}. The table will be released immediately.` : ''} onConfirm={cancel} onClose={() => setTarget(null)} />
    </>
  );
}

export function ReservationDetail() {
  const { id } = useParams();
  const { state } = useLocation();
  const toast = useToast();
  const { data, loading, error, reload } = useAsync(() => get(`/reservations/${id}`), [id]);
  const [confirm, setConfirm] = useState(false);
  const [busy, setBusy] = useState(false);
  const r = data?.data;

  const cancel = async () => {
    setBusy(true);
    try {
      await patch(`/reservations/${id}/cancel`, {});
      toast.success('Reservation cancelled.');
      reload();
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusy(false);
      setConfirm(false);
    }
  };

  if (loading && !r) return <Skeleton className="h-96" />;
  if (error) return <ErrorState message={error} onRetry={reload} />;
  const tz = r.restaurant?.timezone;
  return (
    <>
      {state?.justBooked && r.status === 'confirmed' && (
        <div role="status" className="mb-6 flex items-start gap-3 rounded-xl border border-ok/40 bg-ok/10 p-4">
          <CheckCircle2 className="mt-0.5 text-ok" aria-hidden />
          <div><p className="font-display text-2xl text-paper">Your table is confirmed</p><p className="text-sm text-paper-2">Show the QR code below when you arrive. A confirmation email was <b>not</b> sent because email delivery isn't enabled in this version, so keep this page handy.</p></div>
        </div>
      )}
      <PageHeader title={r.restaurant?.name} subtitle={`Reference ${r.bookingReference}`} actions={<StatusBadge status={r.status} />} />
      <div className="grid gap-8 lg:grid-cols-[1fr_320px]">
        <div className="space-y-6">
          <div className="h-56 overflow-hidden rounded-xl"><RestaurantImage image={r.restaurant?.image} name={r.restaurant?.name} seed={r.restaurant?.slug} /></div>
          <dl className="card grid gap-5 p-6 sm:grid-cols-2">
            {[['Date', fmtDate(r.startAt, tz)], ['Time', `${fmtTime(r.startAt, tz)} – ${fmtTime(r.endAt, tz)}`], ['Table', `${r.table?.displayName} (seats ${r.table?.capacity})`], ['Guests', r.guestCount], ['Name', r.customerName], ['Source', r.source === 'walk_in' ? 'Walk-in' : 'Online']].map(([k, v]) => (
              <div key={k}><dt className="text-xs uppercase tracking-wider text-paper-2">{k}</dt><dd className="mt-1 text-paper">{v}</dd></div>
            ))}
            {r.specialRequests && <div className="sm:col-span-2"><dt className="text-xs uppercase tracking-wider text-paper-2">Special requests</dt><dd className="mt-1">{r.specialRequests}</dd></div>}
          </dl>
          <div className="flex flex-wrap gap-3">
            <Link to={`/restaurants/${r.restaurant?.slug}`} className="btn-outline">View restaurant</Link>
            {r.canCancel && <Button variant="danger" onClick={() => setConfirm(true)}>Cancel reservation</Button>}
          </div>
          {!r.canCancel && ['confirmed', 'pending'].includes(r.status) && <p className="text-xs text-paper-2">The free-cancellation window has passed. Please contact the restaurant for changes.</p>}
          {r.restaurant?.isDemo && <DemoBadge label="Demo reservation · fictional venue" />}
        </div>
        <aside className="card h-fit p-6 text-center">
          <h2 className="text-2xl">Arrival QR</h2>
          {r.qrDataUrl ? (
            <>
              <img src={r.qrDataUrl} alt={`QR code for reservation ${r.bookingReference}`} className="mx-auto mt-4 h-56 w-56 rounded-lg" />
              <p className="mt-3 text-xs text-paper-2">Staff scan this at the door. It contains a secure token, not your personal details.</p>
            </>
          ) : <p className="mt-4 text-sm text-paper-2">A QR code is available for confirmed reservations only.</p>}
          <p className="mt-3 text-sm text-paper">Or give the reference: <b className="tracking-wider">{r.bookingReference}</b></p>
        </aside>
      </div>
      <ConfirmDialog open={confirm} danger loading={busy} title="Cancel this reservation?" confirmLabel="Cancel reservation" message="The table will be released immediately." onConfirm={cancel} onClose={() => setConfirm(false)} />
    </>
  );
}

const profileSchema = z.object({ name: z.string().trim().min(2, 'Enter your name'), phone: z.string().trim().max(30).optional().or(z.literal('')) });
const pwSchema = z.object({ currentPassword: z.string().min(1, 'Required'), newPassword: z.string().min(8, 'Use at least 8 characters').regex(/[A-Za-z]/, 'Include a letter').regex(/\d/, 'Include a number') });

export function Profile() {
  const { user, setUser } = useAuth();
  const toast = useToast();
  const p = useForm({ resolver: zodResolver(profileSchema), defaultValues: { name: user.name, phone: user.phone || '' } });
  const w = useForm({ resolver: zodResolver(pwSchema) });
  const saveProfile = p.handleSubmit(async (v) => {
    try {
      const r = await patch('/auth/me', v);
      setUser(r.data.user);
      toast.success('Profile updated.');
    } catch (e) { toast.error(errorMessage(e)); }
  });
  const savePw = w.handleSubmit(async (v) => {
    try {
      await post('/auth/change-password', v);
      toast.success('Password changed. Other devices have been signed out.');
      w.reset();
    } catch (e) { toast.error(errorMessage(e)); }
  });
  return (
    <>
      <PageHeader title="Profile" subtitle={user.email} />
      <div className="grid gap-8 lg:grid-cols-2">
        <form onSubmit={saveProfile} noValidate className="card space-y-5 p-6">
          <h2 className="text-2xl">Your details</h2>
          <Field label="Full name" error={p.formState.errors.name?.message} {...p.register('name')} />
          <Field label="Phone (optional)" type="tel" error={p.formState.errors.phone?.message} {...p.register('phone')} />
          <Button type="submit" loading={p.formState.isSubmitting}>Save changes</Button>
        </form>
        <form onSubmit={savePw} noValidate className="card space-y-5 p-6">
          <h2 className="text-2xl">Change password</h2>
          <Field label="Current password" type="password" autoComplete="current-password" error={w.formState.errors.currentPassword?.message} {...w.register('currentPassword')} />
          <Field label="New password" type="password" autoComplete="new-password" error={w.formState.errors.newPassword?.message} {...w.register('newPassword')} />
          <Button type="submit" variant="outline" loading={w.formState.isSubmitting}>Update password</Button>
        </form>
      </div>
    </>
  );
}

export function Favorites() {
  const { data, loading, error, reload } = useAsync(() => get('/favorites'), []);
  return (
    <>
      <PageHeader title="Favorites" subtitle="Restaurants you've saved." />
      {loading ? <Skeleton className="h-64" /> : error ? <ErrorState message={error} onRetry={reload} /> : data?.data?.length ? (
        <div className="grid gap-6 sm:grid-cols-2 xl:grid-cols-3">{data.data.map((r) => <RestaurantCard key={r.id} restaurant={r} />)}</div>
      ) : <EmptyState icon={Heart} title="No favorites yet" message="Tap Save on any restaurant page to keep it here." action={<Link to="/restaurants" className="btn-primary">Discover restaurants</Link>} />}
    </>
  );
}
