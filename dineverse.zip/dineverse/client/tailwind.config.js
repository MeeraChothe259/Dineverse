/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#0B0B0C',
        'ink-2': '#121214',
        'ink-3': '#19191C',
        gold: '#C9A76A',
        champagne: '#E6D2A5',
        paper: '#F5F1E9',
        'paper-2': '#AAA6A0',
        muted: '#77736D',
        line: '#302C26',
        ok: '#70B58A',
        bad: '#C76D6D',
        off: '#66666A',
      },
      fontFamily: {
        display: ['"Cormorant Garamond"', '"Playfair Display"', 'Georgia', 'serif'],
        sans: ['Inter', 'Manrope', 'system-ui', '-apple-system', 'Segoe UI', 'sans-serif'],
      },
      borderRadius: { xl2: '1.25rem' },
      boxShadow: { soft: '0 10px 40px -12px rgba(0,0,0,.6)' },
    },
  },
  plugins: [],
};
