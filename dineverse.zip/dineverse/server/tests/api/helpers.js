import { MongoMemoryServer } from 'mongodb-memory-server';
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import request from 'supertest';
import { createApp } from '../../src/app.js';
import { User } from '../../src/models/User.js';
import { Restaurant, defaultOpeningHours } from '../../src/models/Restaurant.js';
import { Table } from '../../src/models/Table.js';
import { Reservation } from '../../src/models/Reservation.js';
import { StaffAssignment } from '../../src/models/StaffAssignment.js';
import { DAY, localParts } from '../../src/utils/time.js';

let mongod;
export const app = createApp();
export const PASSWORD = 'Passw0rdTest';

export async function startDb() {
  mongod = await MongoMemoryServer.create();
  await mongoose.connect(mongod.getUri());
  await Promise.all([User, Restaurant, Table, Reservation, StaffAssignment].map((m) => m.init())); // build unique indexes
}
export async function stopDb() {
  await mongoose.disconnect();
  await mongod?.stop();
}
export async function resetDb() {
  await Promise.all([User, Restaurant, Table, Reservation, StaffAssignment].map((m) => m.deleteMany({})));
}

export async function makeUser(role, email, name = role) {
  return User.create({ name, email, role, passwordHash: await bcrypt.hash(PASSWORD, 4) });
}

export async function loginAgent(email) {
  const agent = request.agent(app);
  const res = await agent.post('/api/v1/auth/login').send({ email, password: PASSWORD });
  if (res.status !== 200) throw new Error(`login failed for ${email}: ${res.status} ${JSON.stringify(res.body)}`);
  return agent;
}

export async function makeRestaurant(owner, overrides = {}) {
  const r = await Restaurant.create({
    name: 'Test Bistro', slug: `test-bistro-${Math.random().toString(36).slice(2, 7)}`, ownerId: owner._id, status: 'active',
    address: { city: 'Mumbai' }, timezone: 'Asia/Kolkata', openingHours: defaultOpeningHours(), ...overrides,
  });
  const tables = await Table.insertMany([
    { restaurantId: r._id, tableNumber: '1', capacity: 2, position: { x: 3, y: 3 } },
    { restaurantId: r._id, tableNumber: '2', capacity: 4, position: { x: 8, y: 3 } },
    { restaurantId: r._id, tableNumber: '3', capacity: 6, shape: 'rectangle', position: { x: 13, y: 3 } },
  ]);
  return { restaurant: r, tables };
}

/** A local date `days` ahead (restaurant timezone), safely inside the booking window. */
export const futureDate = (days = 3) => localParts(new Date(Date.now() + days * DAY), 'Asia/Kolkata').date;

export const bookBody = (restaurant, table, extra = {}) => ({
  restaurantId: String(restaurant._id), tableId: String(table._id), date: futureDate(3), time: '19:00', guestCount: 2, ...extra,
});
