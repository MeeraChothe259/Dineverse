import { describe, it, expect, beforeAll, afterAll, beforeEach } from 'vitest';
import { startDb, stopDb, resetDb, makeUser, loginAgent, makeRestaurant, bookBody, futureDate } from './helpers.js';
import { StaffAssignment } from '../../src/models/StaffAssignment.js';
import { Reservation } from '../../src/models/Reservation.js';
import { Restaurant } from '../../src/models/Restaurant.js';

let owner, ctx;
beforeAll(startDb);
afterAll(stopDb);
beforeEach(async () => {
  await resetDb();
  owner = await makeUser('owner', 'owner@x.com');
  await makeUser('customer', 'c1@x.com', 'Cara One');
  await makeUser('customer', 'c2@x.com', 'Cal Two');
  ctx = await makeRestaurant(owner);
});

describe('booking validation', () => {
  it('creates a confirmed booking with a QR image and booking reference', async () => {
    const agent = await loginAgent('c1@x.com');
    const res = await agent.post('/api/v1/reservations').send(bookBody(ctx.restaurant, ctx.tables[1], { guestCount: 3 }));
    expect(res.status).toBe(201);
    expect(res.body.data.status).toBe('confirmed');
    expect(res.body.data.bookingReference).toMatch(/^DV-/);
    expect(res.body.data.qrDataUrl.startsWith('data:image/png')).toBe(true);
    expect(res.body.data.endAt).toBeTruthy();
  });

  it('rejects a party larger than the table capacity', async () => {
    const agent = await loginAgent('c1@x.com');
    const res = await agent.post('/api/v1/reservations').send(bookBody(ctx.restaurant, ctx.tables[0], { guestCount: 4 }));
    expect(res.status).toBe(400);
    expect(res.body.code).toBe('CAPACITY_EXCEEDED');
  });

  it('rejects bookings outside opening hours or running past closing', async () => {
    const agent = await loginAgent('c1@x.com');
    for (const time of ['08:00', '22:30']) {
      const res = await agent.post('/api/v1/reservations').send(bookBody(ctx.restaurant, ctx.tables[1], { time }));
      expect(res.status).toBe(400);
      expect(res.body.code).toBe('OUTSIDE_HOURS');
    }
  });

  it('rejects past dates, inactive tables, and tables from another restaurant', async () => {
    const agent = await loginAgent('c1@x.com');
    const past = await agent.post('/api/v1/reservations').send(bookBody(ctx.restaurant, ctx.tables[1], { date: futureDate(-2) }));
    expect(past.body.code).toBe('PAST_TIME');
    ctx.tables[1].isActive = false;
    await ctx.tables[1].save();
    expect((await agent.post('/api/v1/reservations').send(bookBody(ctx.restaurant, ctx.tables[1]))).body.code).toBe('TABLE_DISABLED');
    const other = await makeRestaurant(owner, { name: 'Other' });
    const wrong = await agent.post('/api/v1/reservations').send(bookBody(ctx.restaurant, other.tables[0]));
    expect(wrong.status).toBe(404);
  });

  it('requires authentication', async () => {
    const { default: request } = await import('supertest');
    const { app } = await import('./helpers.js');
    expect((await request(app).post('/api/v1/reservations').send(bookBody(ctx.restaurant, ctx.tables[1]))).status).toBe(401);
  });
});

describe('conflict detection', () => {
  it('rejects an overlapping booking and offers alternatives; allows back-to-back', async () => {
    const a1 = await loginAgent('c1@x.com');
    const a2 = await loginAgent('c2@x.com');
    expect((await a1.post('/api/v1/reservations').send(bookBody(ctx.restaurant, ctx.tables[1]))).status).toBe(201);

    const clash = await a2.post('/api/v1/reservations').send(bookBody(ctx.restaurant, ctx.tables[1], { time: '19:30' }));
    expect(clash.status).toBe(409);
    expect(clash.body.code).toBe('SLOT_CONFLICT');
    expect(clash.body.details.alternativeTables.length).toBeGreaterThan(0);

    // 19:00 + 90 min = 20:30, so 20:30 is free
    expect((await a2.post('/api/v1/reservations').send(bookBody(ctx.restaurant, ctx.tables[1], { time: '20:30' }))).status).toBe(201);
  });

  it('lets exactly one of many simultaneous requests win the same table and slot', async () => {
    const agents = await Promise.all(['c1@x.com', 'c2@x.com'].map(loginAgent));
    const attempts = Array.from({ length: 8 }, (_, i) => agents[i % 2].post('/api/v1/reservations').send(bookBody(ctx.restaurant, ctx.tables[2], { time: '18:00', guestCount: 4 })));
    const results = await Promise.all(attempts);
    expect(results.filter((r) => r.status === 201)).toHaveLength(1);
    expect(results.filter((r) => r.status === 409)).toHaveLength(7);
    expect(await Reservation.countDocuments({ tableId: ctx.tables[2]._id, blocking: true })).toBe(1);
  });

  it('frees the table after cancellation', async () => {
    const a1 = await loginAgent('c1@x.com');
    const a2 = await loginAgent('c2@x.com');
    const first = await a1.post('/api/v1/reservations').send(bookBody(ctx.restaurant, ctx.tables[1]));
    expect((await a1.patch(`/api/v1/reservations/${first.body.data.id}/cancel`).send({})).status).toBe(200);
    expect((await a2.post('/api/v1/reservations').send(bookBody(ctx.restaurant, ctx.tables[1]))).status).toBe(201);
  });

  it('reports table states in availability', async () => {
    const a1 = await loginAgent('c1@x.com');
    await a1.post('/api/v1/reservations').send(bookBody(ctx.restaurant, ctx.tables[1]));
    const res = await a1.get(`/api/v1/restaurants/${ctx.restaurant._id}/availability?date=${futureDate(3)}&time=19:00&guests=4`);
    const byNum = Object.fromEntries(res.body.data.tables.map((t) => [t.tableNumber, t.state]));
    expect(byNum).toEqual({ 1: 'too_small', 2: 'unavailable', 3: 'available' });
  });
});

describe('cancellation rules', () => {
  it("blocks customers cancelling inside the cutoff and other customers' reservations", async () => {
    const a1 = await loginAgent('c1@x.com');
    const a2 = await loginAgent('c2@x.com');
    const res = await a1.post('/api/v1/reservations').send(bookBody(ctx.restaurant, ctx.tables[1]));
    expect((await a2.patch(`/api/v1/reservations/${res.body.data.id}/cancel`).send({})).status).toBe(404);
    await Restaurant.updateOne({ _id: ctx.restaurant._id }, { 'reservationSettings.cancellationCutoffHours': 24 * 30 });
    const late = await a1.patch(`/api/v1/reservations/${res.body.data.id}/cancel`).send({});
    expect(late.status).toBe(409);
    expect(late.body.code).toBe('CANCELLATION_NOT_ALLOWED');
  });
});

describe('QR check-in, duplicates and walk-ins', () => {
  async function setup() {
    const staff = await makeUser('staff', 'staff@x.com');
    await StaffAssignment.create({ userId: staff._id, restaurantId: ctx.restaurant._id });
    const customer = await loginAgent('c1@x.com');
    const staffAgent = await loginAgent('staff@x.com');
    return { customer, staffAgent };
  }
  // Move the booking to "now" so it is inside the arrival window.
  const startNow = (id) => Reservation.updateOne({ _id: id }, { startAt: new Date(Date.now() + 5 * 60000), endAt: new Date(Date.now() + 95 * 60000) });

  it('validates the QR server-side and rejects duplicate check-ins', async () => {
    const { customer, staffAgent } = await setup();
    const booking = (await customer.post('/api/v1/reservations').send(bookBody(ctx.restaurant, ctx.tables[1]))).body.data;
    const token = (await import('../../src/utils/qr.js')).makeQrToken(booking.id);

    expect((await staffAgent.post('/api/v1/checkin/verify').send({ token })).body.data.state).toBe('too_early');
    await startNow(booking.id);
    expect((await staffAgent.post('/api/v1/checkin/verify').send({ token })).body.data.state).toBe('valid');
    expect((await staffAgent.post('/api/v1/checkin/verify').send({ token: token.slice(0, -2) + 'zz' })).body.data.state).toBe('invalid');

    const ok = await staffAgent.post('/api/v1/checkin/confirm').send({ token });
    expect(ok.status).toBe(200);
    expect(ok.body.data.reservation.status).toBe('checked_in');
    const dup = await staffAgent.post('/api/v1/checkin/confirm').send({ token });
    expect(dup.status).toBe(409);
    expect(dup.body.code).toBe('ALREADY_CHECKED_IN');
  });

  it('refuses check-in by customers and by staff of another restaurant; supports manual reference entry', async () => {
    const { customer, staffAgent } = await setup();
    const booking = (await customer.post('/api/v1/reservations').send(bookBody(ctx.restaurant, ctx.tables[1]))).body.data;
    await startNow(booking.id);
    expect((await customer.post('/api/v1/checkin/verify').send({ reference: booking.bookingReference })).status).toBe(403);

    const other = await makeRestaurant(owner, { name: 'Elsewhere' });
    const stranger = await makeUser('staff', 'stranger@x.com');
    await StaffAssignment.create({ userId: stranger._id, restaurantId: other.restaurant._id });
    const strangerAgent = await loginAgent('stranger@x.com');
    expect((await strangerAgent.post('/api/v1/checkin/verify').send({ reference: booking.bookingReference })).body.data.state).toBe('wrong_restaurant');

    const byRef = await staffAgent.post('/api/v1/checkin/confirm').send({ reference: booking.bookingReference });
    expect(byRef.status).toBe(200);
  });

  it('validates walk-ins: capacity, conflicts, permissions', async () => {
    const { staffAgent } = await setup();
    const base = { restaurantId: String(ctx.restaurant._id), guestName: 'Walk Guest', guestCount: 2 };
    const tooBig = await staffAgent.post('/api/v1/staff/walk-ins').send({ ...base, guestCount: 5, tableId: String(ctx.tables[0]._id) });
    expect(tooBig.status).toBe(400);
    const okRes = await staffAgent.post('/api/v1/staff/walk-ins').send({ ...base, tableId: String(ctx.tables[1]._id) });
    expect(okRes.status).toBe(201);
    expect(okRes.body.data.source).toBe('walk_in');
    expect(okRes.body.data.status).toBe('seated');
    const again = await staffAgent.post('/api/v1/staff/walk-ins').send({ ...base, tableId: String(ctx.tables[1]._id) });
    expect(again.status).toBe(409);
  });

  it('enforces valid status transitions', async () => {
    const { customer, staffAgent } = await setup();
    const booking = (await customer.post('/api/v1/reservations').send(bookBody(ctx.restaurant, ctx.tables[1]))).body.data;
    const jump = await staffAgent.patch(`/api/v1/staff/reservations/${booking.id}/status`).send({ status: 'completed' });
    expect(jump.status).toBe(409);
    expect(jump.body.code).toBe('INVALID_TRANSITION');
  });
});
