import { describe, it, expect, beforeAll, afterAll, beforeEach } from 'vitest';
import request from 'supertest';
import { app, PASSWORD, startDb, stopDb, resetDb, makeUser, loginAgent, makeRestaurant } from './helpers.js';
import { User } from '../../src/models/User.js';

beforeAll(startDb);
afterAll(stopDb);
beforeEach(resetDb);

describe('registration & login', () => {
  it('registers a customer, stores only a bcrypt hash, and never returns it', async () => {
    const res = await request(app).post('/api/v1/auth/register').send({ name: 'Asha Rao', email: 'ASHA@Example.com', password: 'Secret123' });
    expect(res.status).toBe(201);
    expect(res.body.data.user.role).toBe('customer');
    expect(res.body.data.user.passwordHash).toBeUndefined();
    const stored = await User.findOne({ email: 'asha@example.com' }).select('+passwordHash');
    expect(stored.passwordHash).not.toBe('Secret123');
    expect(stored.passwordHash.startsWith('$2')).toBe(true);
  });

  it('never lets public registration choose admin or staff', async () => {
    for (const accountType of ['admin', 'staff']) {
      const res = await request(app).post('/api/v1/auth/register').send({ name: 'Mallory', email: `${accountType}@x.com`, password: 'Secret123', accountType });
      expect(res.status).toBe(400);
    }
    const sneaky = await request(app).post('/api/v1/auth/register').send({ name: 'Mallory', email: 'm@x.com', password: 'Secret123', role: 'admin' });
    expect(sneaky.status).toBe(400); // unknown keys are rejected (strict schema)
  });

  it('rejects duplicate emails, weak passwords and wrong credentials', async () => {
    await makeUser('customer', 'dup@x.com');
    expect((await request(app).post('/api/v1/auth/register').send({ name: 'Dup', email: 'dup@x.com', password: 'Secret123' })).status).toBe(409);
    expect((await request(app).post('/api/v1/auth/register').send({ name: 'Weak', email: 'weak@x.com', password: 'short' })).status).toBe(400);
    expect((await request(app).post('/api/v1/auth/login').send({ email: 'dup@x.com', password: 'WrongPass1' })).status).toBe(401);
    expect((await request(app).post('/api/v1/auth/login').send({ email: 'nobody@x.com', password: 'WrongPass1' })).status).toBe(401);
  });

  it('logout revokes the token server-side', async () => {
    await makeUser('customer', 'c@x.com');
    const login = await request(app).post('/api/v1/auth/login').send({ email: 'c@x.com', password: PASSWORD });
    const cookie = login.headers['set-cookie'].map((c) => c.split(';')[0]).join('; ');
    expect((await request(app).get('/api/v1/auth/me').set('Cookie', cookie)).status).toBe(200);
    await request(app).post('/api/v1/auth/logout').set('Cookie', cookie);
    expect((await request(app).get('/api/v1/auth/me').set('Cookie', cookie)).status).toBe(401);
  });
});

describe('role-based authorization & ownership', () => {
  it('blocks customers from owner, staff and admin endpoints and unauthenticated users from everything private', async () => {
    await makeUser('customer', 'c@x.com');
    const agent = await loginAgent('c@x.com');
    for (const path of ['/owner/dashboard', '/staff/dashboard', '/admin/dashboard']) expect((await agent.get(`/api/v1${path}`)).status).toBe(403);
    expect((await request(app).get('/api/v1/reservations/my')).status).toBe(401);
  });

  it("stops an owner from reading or editing another owner's restaurant", async () => {
    const a = await makeUser('owner', 'a@x.com');
    await makeUser('owner', 'b@x.com');
    const { restaurant } = await makeRestaurant(a);
    const agentB = await loginAgent('b@x.com');
    expect((await agentB.get(`/api/v1/owner/restaurants/${restaurant._id}`)).status).toBe(403);
    expect((await agentB.patch(`/api/v1/owner/restaurants/${restaurant._id}`).send({ name: 'Hacked' })).status).toBe(403);
    expect((await agentB.get(`/api/v1/owner/restaurants/${restaurant._id}/floor-plan`)).status).toBe(403);
  });

  it('prevents mass assignment when owners update a restaurant', async () => {
    const a = await makeUser('owner', 'a@x.com');
    const { restaurant } = await makeRestaurant(a);
    const agent = await loginAgent('a@x.com');
    const res = await agent.patch(`/api/v1/owner/restaurants/${restaurant._id}`).send({ status: 'active', ownerId: '000000000000000000000000' });
    expect(res.status).toBe(400);
  });

  it('only admins can change restaurant status, and new owner applications start pending', async () => {
    const o = await makeUser('owner', 'o@x.com');
    await makeUser('admin', 'adm@x.com');
    const agent = await loginAgent('o@x.com');
    const created = await agent.post('/api/v1/owner/restaurants').send({ name: 'New Place', address: { city: 'Pune' } });
    expect(created.status).toBe(201);
    expect(created.body.data.status).toBe('pending');
    expect((await agent.patch(`/api/v1/admin/restaurants/${created.body.data.id}/status`).send({ status: 'active' })).status).toBe(403);
    const admin = await loginAgent('adm@x.com');
    expect((await admin.patch(`/api/v1/admin/restaurants/${created.body.data.id}/status`).send({ status: 'active' })).status).toBe(200);
    expect(o).toBeTruthy();
  });

  it("scopes staff to their assigned restaurant only", async () => {
    const o = await makeUser('owner', 'o@x.com');
    const staff = await makeUser('staff', 's@x.com');
    const { restaurant: mine } = await makeRestaurant(o);
    const { restaurant: other } = await makeRestaurant(o, { name: 'Other' });
    const { StaffAssignment } = await import('../../src/models/StaffAssignment.js');
    await StaffAssignment.create({ userId: staff._id, restaurantId: mine._id });
    const agent = await loginAgent('s@x.com');
    expect((await agent.get(`/api/v1/staff/dashboard?restaurantId=${mine._id}`)).status).toBe(200);
    expect((await agent.get(`/api/v1/staff/dashboard?restaurantId=${other._id}`)).status).toBe(403);
  });
});
