import { describe, it, expect } from 'vitest';
import { zonedToUtc, localParts, slotKeys, isValidDateStr, isValidTimeStr } from '../../src/utils/time.js';
import {
  canTransition,
  isWithinOpeningHours,
  validateBookingWindow,
  generateSlots,
  computeTableStates,
  canCancel,
  arrivalWindowState,
} from '../../src/utils/reservationRules.js';
import { makeQrToken, parseQrToken, hashToken, generateBookingReference } from '../../src/utils/qr.js';
import { buildAnalytics } from '../../src/utils/analytics.js';

const hours = (open = '12:00', close = '23:00') =>
  Array.from({ length: 7 }, (_, day) => ({ day, open, close, closed: false }));
const restaurant = {
  _id: 'r1',
  timezone: 'Asia/Kolkata',
  openingHours: hours(),
  reservationSettings: { durationMinutes: 90, slotIntervalMinutes: 30, advanceBookingDays: 60, cancellationCutoffHours: 2, checkInWindowMinutes: 30 },
};

describe('time helpers', () => {
  it('converts Asia/Kolkata wall time to UTC (+05:30)', () => {
    expect(zonedToUtc('2026-11-01', '19:00', 'Asia/Kolkata').toISOString()).toBe('2026-11-01T13:30:00.000Z');
  });
  it('round-trips local parts', () => {
    const d = zonedToUtc('2026-11-01', '23:30', 'Asia/Kolkata');
    expect(localParts(d, 'Asia/Kolkata')).toMatchObject({ date: '2026-11-01', time: '23:30', weekday: 0 });
  });
  it('validates date and time strings', () => {
    expect(isValidDateStr('2026-02-30')).toBe(false);
    expect(isValidDateStr('2026-02-28')).toBe(true);
    expect(isValidTimeStr('24:00')).toBe(false);
    expect(isValidTimeStr('09:45')).toBe(true);
  });
  it('produces adjacent, non-overlapping slot keys for back-to-back bookings', () => {
    const a = slotKeys('t', new Date('2026-11-01T13:30:00Z'), new Date('2026-11-01T15:00:00Z'));
    const b = slotKeys('t', new Date('2026-11-01T15:00:00Z'), new Date('2026-11-01T16:30:00Z'));
    expect(a).toHaveLength(6);
    expect(a.some((k) => b.includes(k))).toBe(false);
    const c = slotKeys('t', new Date('2026-11-01T14:45:00Z'), new Date('2026-11-01T16:15:00Z'));
    expect(a.some((k) => c.includes(k))).toBe(true);
  });
});

describe('status transitions', () => {
  it('allows the intended flow', () => {
    expect(canTransition('confirmed', 'checked_in')).toBe(true);
    expect(canTransition('checked_in', 'seated')).toBe(true);
    expect(canTransition('seated', 'completed')).toBe(true);
  });
  it('rejects arbitrary jumps and leaving terminal states', () => {
    expect(canTransition('confirmed', 'completed')).toBe(false);
    expect(canTransition('cancelled', 'confirmed')).toBe(false);
    expect(canTransition('completed', 'cancelled')).toBe(false);
  });
});

describe('opening hours and booking window', () => {
  it('accepts a booking that ends before closing', () => {
    const s = zonedToUtc('2026-11-01', '21:00', 'Asia/Kolkata');
    expect(isWithinOpeningHours(restaurant, s, new Date(s.getTime() + 90 * 60000))).toBe(true);
  });
  it('rejects a booking that would run past closing or start before opening', () => {
    const late = zonedToUtc('2026-11-01', '22:00', 'Asia/Kolkata');
    expect(isWithinOpeningHours(restaurant, late, new Date(late.getTime() + 90 * 60000))).toBe(false);
    const early = zonedToUtc('2026-11-01', '09:00', 'Asia/Kolkata');
    expect(isWithinOpeningHours(restaurant, early, new Date(early.getTime() + 90 * 60000))).toBe(false);
  });
  it('rejects closed days', () => {
    const r = { ...restaurant, openingHours: hours().map((h) => (h.day === 0 ? { ...h, closed: true } : h)) };
    const s = zonedToUtc('2026-11-01', '19:00', 'Asia/Kolkata'); // a Sunday
    expect(isWithinOpeningHours(r, s, new Date(s.getTime() + 90 * 60000))).toBe(false);
  });
  it('supports closing after midnight', () => {
    const r = { ...restaurant, openingHours: hours('18:00', '02:00') };
    const s = zonedToUtc('2026-11-01', '23:30', 'Asia/Kolkata');
    expect(isWithinOpeningHours(r, s, new Date(s.getTime() + 90 * 60000))).toBe(true);
  });
  it('validates past and far-future starts', () => {
    const now = new Date('2026-10-24T00:00:00Z');
    expect(validateBookingWindow(restaurant.reservationSettings, new Date('2026-10-23T00:00:00Z'), now)).toBe('PAST_TIME');
    expect(validateBookingWindow(restaurant.reservationSettings, new Date('2027-03-01T00:00:00Z'), now)).toBe('TOO_FAR_AHEAD');
    expect(validateBookingWindow(restaurant.reservationSettings, new Date('2026-10-30T00:00:00Z'), now)).toBeNull();
  });
  it('generates slots that all fit inside opening hours', () => {
    const slots = generateSlots(restaurant, '2026-11-01', 0);
    expect(slots[0].time).toBe('12:00');
    expect(slots.at(-1).time).toBe('21:30'); // 21:30 + 90m = 23:00
  });
});

describe('table availability states', () => {
  const start = new Date('2026-11-01T13:30:00Z');
  const end = new Date('2026-11-01T15:00:00Z');
  const tables = [
    { _id: 'a', isActive: true, status: 'available', capacity: 4 },
    { _id: 'b', isActive: true, status: 'available', capacity: 2 },
    { _id: 'c', isActive: false, status: 'available', capacity: 4 },
    { _id: 'd', isActive: true, status: 'out_of_service', capacity: 4 },
    { _id: 'e', isActive: true, status: 'cleaning', capacity: 6 },
  ];
  const reservations = [{ tableId: 'a', startAt: new Date('2026-11-01T14:00:00Z'), blockedUntil: new Date('2026-11-01T15:30:00Z') }];
  it('classifies each table', () => {
    const states = Object.fromEntries(
      computeTableStates({ tables, reservations, startAt: start, blockedUntil: end, guests: 4 }).map((x) => [x.table._id, x.state])
    );
    expect(states).toEqual({ a: 'unavailable', b: 'too_small', c: 'disabled', d: 'disabled', e: 'available' });
  });
  it('treats an exactly adjacent reservation as free', () => {
    const adj = [{ tableId: 'a', startAt: new Date('2026-11-01T15:00:00Z'), blockedUntil: new Date('2026-11-01T16:30:00Z') }];
    const r = computeTableStates({ tables: [tables[0]], reservations: adj, startAt: start, blockedUntil: end, guests: 2 });
    expect(r[0].state).toBe('available');
  });
});

describe('cancellation and arrival window', () => {
  const res = { status: 'confirmed', startAt: new Date('2026-11-01T13:30:00Z'), endAt: new Date('2026-11-01T15:00:00Z') };
  it('enforces the cancellation cutoff', () => {
    expect(canCancel(res, restaurant, new Date('2026-11-01T10:00:00Z'))).toBe(true);
    expect(canCancel(res, restaurant, new Date('2026-11-01T12:00:00Z'))).toBe(false);
    expect(canCancel({ ...res, status: 'seated' }, restaurant, new Date('2026-10-30T00:00:00Z'))).toBe(false);
  });
  it('computes arrival window state', () => {
    expect(arrivalWindowState(res, restaurant, new Date('2026-11-01T12:00:00Z'))).toBe('too_early');
    expect(arrivalWindowState(res, restaurant, new Date('2026-11-01T13:10:00Z'))).toBe('ok');
    expect(arrivalWindowState(res, restaurant, new Date('2026-11-01T15:30:00Z'))).toBe('expired');
  });
});

describe('QR tokens', () => {
  const id = '65f0c0ffee0c0ffee0c0ffee';
  it('round-trips and carries no personal data', () => {
    const t = makeQrToken(id);
    expect(parseQrToken(t)).toBe(id);
    expect(parseQrToken(`dineverse:checkin:${t}`)).toBe(id);
    expect(t).toMatch(/^[a-f0-9]{24}\.[A-Za-z0-9_-]{32}$/);
  });
  it('rejects tampered or malformed tokens', () => {
    const t = makeQrToken(id);
    expect(parseQrToken(t.slice(0, -1) + (t.endsWith('a') ? 'b' : 'a'))).toBeNull();
    expect(parseQrToken('garbage')).toBeNull();
    expect(parseQrToken(undefined)).toBeNull();
    expect(parseQrToken(`${'0'.repeat(24)}.${t.split('.')[1]}`)).toBeNull();
  });
  it('hashes deterministically and builds references', () => {
    expect(hashToken('x')).toBe(hashToken('x'));
    expect(hashToken('x')).toHaveLength(64);
    expect(generateBookingReference()).toMatch(/^DV-[A-Z2-9]{8}$/);
  });
});

describe('analytics builder', () => {
  const from = new Date('2026-10-01T00:00:00Z');
  const to = new Date('2026-10-08T00:00:00Z');
  const mk = (n, status, source, day, hour = 13) => ({
    restaurantId: 'r1', status, source, guestCount: n, date: `2026-10-0${day}`,
    startAt: new Date(`2026-10-0${day}T${hour}:00:00Z`), endAt: new Date(`2026-10-0${day}T${hour + 1}:30:00Z`),
  });
  const data = buildAnalytics({
    reservations: [mk(2, 'completed', 'online', 2), mk(4, 'cancelled', 'online', 3), mk(3, 'confirmed', 'walk_in', 4), mk(2, 'no_show', 'online', 5)],
    restaurants: [{ _id: 'r1', timezone: 'Asia/Kolkata', openingHours: hours(), isDemo: true }],
    tables: [{ isActive: true }, { isActive: true }],
    from, to, now: new Date('2026-10-04T00:00:00Z'),
  });
  it('computes totals from real records', () => {
    expect(data.totals.bookings).toBe(4);
    expect(data.totals.cancelled).toBe(1);
    expect(data.totals.cancellationRate).toBe(25);
    expect(data.totals.guests).toBe(7); // cancelled excluded
    expect(data.totals.online).toBe(3);
    expect(data.totals.walkIn).toBe(1);
    expect(data.totals.upcoming).toBe(1);
    expect(data.byDay).toHaveLength(7);
    expect(data.containsDemoData).toBe(true);
  });
});
