import mongoose from 'mongoose';

const { Schema } = mongoose;

export const TABLE_SHAPES = ['round', 'square', 'rectangle'];
export const TABLE_STATUSES = ['available', 'reserved', 'occupied', 'cleaning', 'out_of_service'];

const tableSchema = new Schema(
  {
    restaurantId: { type: Schema.Types.ObjectId, ref: 'Restaurant', required: true, index: true },
    tableNumber: { type: String, required: true, trim: true, maxlength: 20 },
    displayName: { type: String, trim: true, maxlength: 60 },
    capacity: { type: Number, required: true, min: 1, max: 40 },
    shape: { type: String, enum: TABLE_SHAPES, default: 'round' },
    // metres; for round tables `width` is the diameter
    dimensions: {
      width: { type: Number, default: 1.2, min: 0.4, max: 8 },
      depth: { type: Number, default: 1.2, min: 0.4, max: 8 },
      height: { type: Number, default: 0.75, min: 0.3, max: 1.5 },
    },
    // x/y are plan coordinates in metres (y maps to the 3D z axis); z is elevation.
    position: {
      x: { type: Number, default: 0 },
      y: { type: Number, default: 0 },
      z: { type: Number, default: 0 },
    },
    rotation: { type: Number, default: 0 }, // degrees, around the vertical axis
    floorId: { type: String, default: 'main' },
    isActive: { type: Boolean, default: true },
    status: { type: String, enum: TABLE_STATUSES, default: 'available' },
  },
  { timestamps: true }
);

tableSchema.index({ restaurantId: 1, tableNumber: 1 }, { unique: true });

export const Table = mongoose.models.Table || mongoose.model('Table', tableSchema);
