import mongoose from 'mongoose';

const { Schema } = mongoose;

export const RESTAURANT_STATUSES = ['pending', 'active', 'suspended', 'rejected'];
export const EXPERIENCES = [
  'Fine Dining',
  'Rooftop Dining',
  'Romantic Evenings',
  'Private Dining',
  'Celebrations',
  "Chef's Table",
];

const hoursSchema = new Schema(
  {
    day: { type: Number, min: 0, max: 6, required: true }, // 0 = Sunday
    open: { type: String, match: /^([01]\d|2[0-3]):[0-5]\d$/, default: '12:00' },
    close: { type: String, match: /^([01]\d|2[0-3]):[0-5]\d$/, default: '23:00' },
    closed: { type: Boolean, default: false },
  },
  { _id: false }
);

export const defaultOpeningHours = () =>
  Array.from({ length: 7 }, (_, day) => ({ day, open: '12:00', close: '23:00', closed: false }));

const restaurantSchema = new Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 120 },
    slug: { type: String, required: true, unique: true, lowercase: true, trim: true },
    tagline: { type: String, trim: true, maxlength: 160 },
    description: { type: String, trim: true, maxlength: 4000, default: '' },
    cuisineTypes: [{ type: String, trim: true, maxlength: 40 }],
    experiences: [{ type: String, enum: EXPERIENCES }],
    address: {
      line1: { type: String, trim: true, maxlength: 200 },
      city: { type: String, trim: true, maxlength: 80, index: true },
      state: { type: String, trim: true, maxlength: 80 },
      country: { type: String, trim: true, maxlength: 80, default: 'India' },
      postalCode: { type: String, trim: true, maxlength: 20 },
    },
    contact: {
      phone: { type: String, trim: true, maxlength: 30 },
      email: { type: String, trim: true, maxlength: 160 },
      website: { type: String, trim: true, maxlength: 300 },
    },
    timezone: { type: String, default: 'Asia/Kolkata' },
    priceRange: { type: Number, min: 1, max: 4, default: 2 },
    images: [{ url: { type: String, trim: true, maxlength: 600 }, alt: { type: String, trim: true, maxlength: 200 }, _id: false }],
    amenities: [{ type: String, trim: true, maxlength: 60 }],
    openingHours: { type: [hoursSchema], default: defaultOpeningHours },
    reservationSettings: {
      acceptingReservations: { type: Boolean, default: true },
      durationMinutes: { type: Number, default: 90, min: 30, max: 360 },
      bufferMinutes: { type: Number, default: 0, min: 0, max: 120 },
      slotIntervalMinutes: { type: Number, default: 30, min: 15, max: 120 },
      minPartySize: { type: Number, default: 1, min: 1 },
      maxPartySize: { type: Number, default: 12, min: 1, max: 100 },
      advanceBookingDays: { type: Number, default: 60, min: 1, max: 365 },
      cancellationCutoffHours: { type: Number, default: 2, min: 0, max: 168 },
      checkInWindowMinutes: { type: Number, default: 30, min: 0, max: 180 },
    },
    policies: { type: String, trim: true, maxlength: 2000, default: '' },
    // Room dimensions in metres; tables are placed inside this rectangle.
    floorPlan: {
      width: { type: Number, default: 20, min: 6, max: 80 },
      depth: { type: Number, default: 14, min: 6, max: 80 },
    },
    ownerId: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    status: { type: String, enum: RESTAURANT_STATUSES, default: 'pending', index: true },
    statusNote: { type: String, trim: true, maxlength: 500 },
    subscriptionPlan: { type: String, enum: ['demo', 'starter', 'pro'], default: 'demo' },
    // Demo-content markers (the platform never presents these as verified data).
    isDemo: { type: Boolean, default: false },
    demoRating: {
      value: { type: Number, min: 0, max: 5 },
      count: { type: Number, min: 0 },
    },
  },
  { timestamps: true }
);

restaurantSchema.index({ status: 1, 'address.city': 1 });

export const Restaurant = mongoose.models.Restaurant || mongoose.model('Restaurant', restaurantSchema);
