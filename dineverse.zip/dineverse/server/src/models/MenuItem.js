import mongoose from 'mongoose';

const { Schema } = mongoose;

export const DIETARY_LABELS = ['vegetarian', 'vegan', 'gluten_free', 'contains_nuts', 'dairy_free', 'spicy', 'jain'];

const menuItemSchema = new Schema(
  {
    restaurantId: { type: Schema.Types.ObjectId, ref: 'Restaurant', required: true, index: true },
    category: { type: String, required: true, trim: true, maxlength: 60 },
    name: { type: String, required: true, trim: true, maxlength: 120 },
    description: { type: String, trim: true, maxlength: 500, default: '' },
    price: { type: Number, required: true, min: 0 }, // INR, display only (no payments in v1)
    image: { type: String, trim: true, maxlength: 600 },
    dietaryLabels: [{ type: String, enum: DIETARY_LABELS }],
    isAvailable: { type: Boolean, default: true },
    sortOrder: { type: Number, default: 0 },
  },
  { timestamps: true }
);

export const MenuItem = mongoose.models.MenuItem || mongoose.model('MenuItem', menuItemSchema);
