import mongoose from 'mongoose';

const { Schema } = mongoose;

export const STAFF_PERMISSIONS = ['reservations', 'checkin', 'walkin', 'tables'];

const staffAssignmentSchema = new Schema(
  {
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    restaurantId: { type: Schema.Types.ObjectId, ref: 'Restaurant', required: true, index: true },
    assignedRole: { type: String, enum: ['host', 'server', 'manager'], default: 'host' },
    permissions: { type: [String], enum: STAFF_PERMISSIONS, default: () => [...STAFF_PERMISSIONS] },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

staffAssignmentSchema.index({ userId: 1, restaurantId: 1 }, { unique: true });

export const StaffAssignment =
  mongoose.models.StaffAssignment || mongoose.model('StaffAssignment', staffAssignmentSchema);
