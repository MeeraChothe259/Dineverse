import mongoose from 'mongoose';

const { Schema } = mongoose;

export const RESERVATION_STATUSES = ['pending', 'confirmed', 'checked_in', 'seated', 'completed', 'cancelled', 'no_show'];
// Statuses that still hold the table (and therefore block its time slots).
export const BLOCKING_STATUSES = ['pending', 'confirmed', 'checked_in', 'seated'];

const reservationSchema = new Schema(
  {
    bookingReference: { type: String, required: true, unique: true },
    customerId: { type: Schema.Types.ObjectId, ref: 'User', default: null, index: true }, // null for walk-ins
    restaurantId: { type: Schema.Types.ObjectId, ref: 'Restaurant', required: true },
    tableId: { type: Schema.Types.ObjectId, ref: 'Table', required: true },
    date: { type: String, required: true, match: /^\d{4}-\d{2}-\d{2}$/ }, // local date in the restaurant timezone
    startAt: { type: Date, required: true },
    endAt: { type: Date, required: true },
    // endAt + buffer. The table is held until this instant.
    blockedUntil: { type: Date, required: true },
    guestCount: { type: Number, required: true, min: 1, max: 100 },
    // Snapshots so history survives profile edits / deletions.
    customerName: { type: String, required: true, trim: true, maxlength: 80 },
    customerEmail: { type: String, trim: true, lowercase: true, maxlength: 160 },
    customerPhone: { type: String, trim: true, maxlength: 30 },
    specialRequests: { type: String, trim: true, maxlength: 500, default: '' },
    status: { type: String, enum: RESERVATION_STATUSES, default: 'confirmed', index: true },
    source: { type: String, enum: ['online', 'walk_in'], default: 'online' },
    qrTokenHash: { type: String, index: true },
    // 15-minute slot keys "<tableId>:<slotIndex>". A partial UNIQUE index over these keys
    // makes double-booking impossible at the database level, with no transactions needed.
    slotKeys: { type: [String], default: [] },
    blocking: { type: Boolean, default: true },
    checkedInAt: Date,
    checkedInBy: { type: Schema.Types.ObjectId, ref: 'User' },
    seatedAt: Date,
    completedAt: Date,
    cancelledAt: Date,
    cancelledBy: { type: Schema.Types.ObjectId, ref: 'User' },
    cancelReason: { type: String, trim: true, maxlength: 300 },
    createdBy: { type: Schema.Types.ObjectId, ref: 'User' },
    isDemo: { type: Boolean, default: false },
  },
  { timestamps: true }
);

reservationSchema.index({ restaurantId: 1, startAt: 1 });
reservationSchema.index({ restaurantId: 1, tableId: 1, startAt: 1 });
reservationSchema.index({ customerId: 1, startAt: -1 });
reservationSchema.index({ slotKeys: 1 }, { unique: true, partialFilterExpression: { blocking: true } });

export const Reservation = mongoose.models.Reservation || mongoose.model('Reservation', reservationSchema);
