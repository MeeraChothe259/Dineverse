import { Router } from 'express';
import { authenticate, requireRole } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import { authLimiter, bookingLimiter, checkinLimiter } from '../middleware/rateLimit.js';
import * as v from '../validators/index.js';
import * as auth from '../controllers/authController.js';
import * as pub from '../controllers/restaurantController.js';
import * as resv from '../controllers/reservationController.js';
import * as checkin from '../controllers/checkinController.js';
import * as fav from '../controllers/favoriteController.js';
import * as owner from '../controllers/ownerController.js';
import * as staff from '../controllers/staffController.js';
import * as admin from '../controllers/adminController.js';

const router = Router();

router.get('/health', (_req, res) => res.json({ success: true, data: { status: 'ok', time: new Date().toISOString() } }));

// ---- Auth ----
router.post('/auth/register', authLimiter, validate(v.registerSchema), auth.register);
router.post('/auth/login', authLimiter, validate(v.loginSchema), auth.login);
router.post('/auth/logout', authenticate, auth.logout);
router.get('/auth/me', authenticate, auth.me);
router.patch('/auth/me', authenticate, validate(v.updateMeSchema), auth.updateMe);
router.post('/auth/change-password', authenticate, authLimiter, validate(v.changePasswordSchema), auth.changePassword);
router.post('/auth/forgot-password', authLimiter, auth.forgotPassword);

// ---- Public restaurants ----
router.get('/restaurants', validate(v.listRestaurantsQuery, 'query'), pub.listRestaurants);
router.get('/restaurants/facets', pub.facets);
router.get('/restaurants/:id/availability', validate(v.availabilityQuery, 'query'), pub.getAvailabilityHandler);
router.get('/restaurants/:id/tables', pub.getTables);
router.get('/restaurants/:id/menu', pub.getMenu);
router.get('/restaurants/:slug', pub.getRestaurant);

// ---- Customer bookings & favourites ----
router.post('/reservations', authenticate, bookingLimiter, validate(v.createReservationSchema), resv.create);
router.get('/reservations/my', authenticate, validate(v.myReservationsQuery, 'query'), resv.listMine);
router.get('/reservations/:id', authenticate, resv.getOne);
router.patch('/reservations/:id/cancel', authenticate, validate(v.cancelSchema), resv.cancel);

router.get('/favorites', authenticate, requireRole('customer'), fav.list);
router.get('/favorites/ids', authenticate, requireRole('customer'), fav.ids);
router.put('/favorites/:restaurantId', authenticate, requireRole('customer'), fav.add);
router.delete('/favorites/:restaurantId', authenticate, requireRole('customer'), fav.remove);

// ---- Check-in (staff / owner of that venue) ----
router.post('/checkin/verify', authenticate, requireRole('staff', 'owner'), checkinLimiter, validate(v.checkinSchema), checkin.verify);
router.post('/checkin/confirm', authenticate, requireRole('staff', 'owner'), checkinLimiter, validate(v.checkinSchema), checkin.confirm);

// ---- Owner ----
const own = Router();
own.use(authenticate, requireRole('owner', 'admin'));
own.get('/dashboard', owner.dashboard);
own.get('/analytics', validate(v.analyticsQuery, 'query'), owner.analytics);
own.get('/restaurants', owner.listRestaurants);
own.post('/restaurants', validate(v.createRestaurantSchema), owner.createRestaurant);
own.get('/restaurants/:id', owner.getRestaurant);
own.patch('/restaurants/:id', validate(v.updateRestaurantSchema), owner.updateRestaurant);
own.get('/reservations', validate(v.ownerListQuery, 'query'), owner.listReservations);
own.get('/restaurants/:id/tables', owner.listTables);
own.post('/restaurants/:id/tables', validate(v.tableSchema), owner.createTable);
own.patch('/tables/:tableId', validate(v.updateTableSchema), owner.updateTable);
own.delete('/tables/:tableId', owner.deleteTable);
own.get('/restaurants/:id/floor-plan', owner.getFloorPlan);
own.put('/restaurants/:id/floor-plan', validate(v.floorPlanSchema), owner.putFloorPlan);
own.get('/restaurants/:id/menu', owner.listMenu);
own.post('/restaurants/:id/menu', validate(v.menuItemSchema), owner.createMenuItem);
own.patch('/menu/:itemId', validate(v.updateMenuItemSchema), owner.updateMenuItem);
own.delete('/menu/:itemId', owner.deleteMenuItem);
own.get('/staff', owner.listStaff);
own.post('/staff', validate(v.createStaffSchema), owner.createStaff);
own.patch('/staff/:id', validate(v.updateStaffSchema), owner.updateStaff);
router.use('/owner', own);

// ---- Staff ----
const st = Router();
st.use(authenticate, requireRole('staff', 'owner'));
st.get('/me', staff.me);
st.get('/dashboard', validate(v.staffQuery, 'query'), staff.dashboard);
st.get('/reservations', validate(v.staffQuery, 'query'), staff.listReservations);
st.post('/walk-ins', validate(v.walkInSchema), staff.walkIn);
st.patch('/tables/:tableId/status', validate(v.tableStatusSchema), staff.updateTableStatus);
st.patch('/reservations/:id/status', validate(v.reservationStatusSchema), staff.updateReservationStatus);
router.use('/staff', st);

// ---- Admin ----
const ad = Router();
ad.use(authenticate, requireRole('admin'));
ad.get('/dashboard', admin.dashboard);
ad.get('/restaurants', validate(v.adminListQuery, 'query'), admin.listRestaurants);
ad.patch('/restaurants/:id/status', validate(v.adminStatusSchema), admin.setRestaurantStatus);
ad.get('/customers', validate(v.adminListQuery, 'query'), admin.listUsers);
ad.patch('/users/:id/active', validate(v.adminUserActiveSchema), admin.setUserActive);
ad.get('/reservations', validate(v.adminListQuery, 'query'), admin.listReservations);
ad.get('/audit', validate(v.adminListQuery, 'query'), admin.listAudit);
router.use('/admin', ad);

export default router;
