import jwt from 'jsonwebtoken';
import { env } from '../config/env.js';
import { User } from '../models/User.js';
import { asyncHandler, forbidden, unauthorized } from '../utils/http.js';

export const COOKIE_NAME = 'dv_token';

export function signToken(user) {
  return jwt.sign({ sub: String(user._id), tv: user.tokenVersion || 0, role: user.role }, env.JWT_SECRET, {
    expiresIn: env.JWT_EXPIRES_IN,
  });
}

export function cookieOptions() {
  return {
    httpOnly: true,
    secure: env.isProd || env.COOKIE_SAMESITE === 'none',
    sameSite: env.COOKIE_SAMESITE,
    maxAge: env.COOKIE_MAX_AGE_DAYS * 24 * 60 * 60 * 1000,
    path: '/',
  };
}

export const setAuthCookie = (res, user) => res.cookie(COOKIE_NAME, signToken(user), cookieOptions());
export const clearAuthCookie = (res) => {
  const { maxAge, ...opts } = cookieOptions();
  res.clearCookie(COOKIE_NAME, opts);
};

export function tokenFromRequest(req) {
  if (req.cookies?.[COOKIE_NAME]) return req.cookies[COOKIE_NAME];
  const h = req.headers.authorization;
  if (h?.startsWith('Bearer ')) return h.slice(7);
  return null;
}

/** Resolves a JWT to an active user document (or null). Used by HTTP middleware and sockets. */
export async function userFromToken(token) {
  if (!token) return null;
  let payload;
  try {
    payload = jwt.verify(token, env.JWT_SECRET);
  } catch {
    return null;
  }
  const user = await User.findById(payload.sub);
  if (!user || !user.isActive || (user.tokenVersion || 0) !== payload.tv) return null;
  return user;
}

export const authenticate = asyncHandler(async (req, _res, next) => {
  const user = await userFromToken(tokenFromRequest(req));
  if (!user) throw unauthorized('Please sign in to continue.', 'UNAUTHENTICATED');
  req.user = user;
  next();
});

export const optionalAuth = asyncHandler(async (req, _res, next) => {
  req.user = (await userFromToken(tokenFromRequest(req))) || null;
  next();
});

export const requireRole =
  (...roles) =>
  (req, _res, next) => {
    if (!req.user) return next(unauthorized());
    if (!roles.includes(req.user.role)) return next(forbidden('Your account cannot access this resource.'));
    next();
  };
