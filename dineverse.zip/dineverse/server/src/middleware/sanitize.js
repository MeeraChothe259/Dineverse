// Rejects request keys that could be abused for NoSQL operator injection ("$where", "a.b").
// Combined with zod schemas (which strip unknown keys) this keeps Mongo queries safe.
const bad = (key) => key.startsWith('$') || key.includes('.');

function clean(value, depth = 0) {
  if (!value || typeof value !== 'object' || depth > 8) return false;
  for (const key of Object.keys(value)) {
    if (bad(key)) return true;
    if (clean(value[key], depth + 1)) return true;
  }
  return false;
}

export default function sanitize(req, res, next) {
  if (clean(req.body) || clean(req.query) || clean(req.params)) {
    return res.status(400).json({ success: false, code: 'INVALID_INPUT', message: 'Request contains invalid characters in field names.' });
  }
  next();
}
