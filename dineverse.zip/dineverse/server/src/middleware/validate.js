/** validate(schema, 'body' | 'query' | 'params') - replaces the input with the parsed (and stripped) value. */
export const validate =
  (schema, source = 'body') =>
  (req, _res, next) => {
    const result = schema.safeParse(req[source]);
    if (!result.success) return next(result.error);
    if (source === 'query') {
      // Express 5 makes req.query read-only; keep a parsed copy on a stable property.
      req.validatedQuery = result.data;
    } else {
      req[source] = result.data;
    }
    next();
  };
