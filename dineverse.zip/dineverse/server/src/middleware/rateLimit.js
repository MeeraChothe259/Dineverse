import rateLimit from 'express-rate-limit';
import { env } from '../config/env.js';

const make = (windowMs, limit, message) =>
  rateLimit({
    windowMs,
    limit,
    standardHeaders: true,
    legacyHeaders: false,
    skip: () => env.isTest,
    handler: (_req, res) => res.status(429).json({ success: false, code: 'RATE_LIMITED', message }),
  });

export const apiLimiter = make(60 * 1000, 300, 'Too many requests. Please slow down.');
export const authLimiter = make(15 * 60 * 1000, 20, 'Too many attempts. Please try again in a few minutes.');
export const checkinLimiter = make(60 * 1000, 60, 'Too many check-in attempts. Please wait a moment.');
export const bookingLimiter = make(60 * 1000, 20, 'Too many booking attempts. Please wait a moment.');
