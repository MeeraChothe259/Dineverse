import { ZodError } from 'zod';
import { env } from '../config/env.js';
import { ApiError } from '../utils/http.js';

export const notFoundHandler = (req, _res, next) =>
  next(new ApiError(404, `Route not found: ${req.method} ${req.originalUrl}`, 'ROUTE_NOT_FOUND'));

// eslint-disable-next-line no-unused-vars
export function errorHandler(err, req, res, _next) {
  let status = err.status || 500;
  let code = err.code && typeof err.code === 'string' ? err.code : 'INTERNAL_ERROR';
  let message = err.message || 'Something went wrong.';
  let details = err.details;

  if (err instanceof ZodError) {
    status = 400;
    code = 'VALIDATION_ERROR';
    message = 'Please check the highlighted fields.';
    details = err.issues.map((i) => ({ path: i.path.join('.'), message: i.message }));
  } else if (err.name === 'ValidationError' && err.errors) {
    status = 400;
    code = 'VALIDATION_ERROR';
    message = 'Please check the highlighted fields.';
    details = Object.values(err.errors).map((e) => ({ path: e.path, message: e.message }));
  } else if (err.name === 'CastError') {
    status = 400;
    code = 'INVALID_ID';
    message = 'Invalid identifier.';
  } else if (err.code === 11000) {
    status = 409;
    code = 'DUPLICATE';
    message = 'That record already exists.';
  } else if (!(err instanceof ApiError) && !err.status) {
    status = 500;
    code = 'INTERNAL_ERROR';
    message = 'Something went wrong on our side.';
  }

  if (status >= 500) console.error(`[error] ${req.method} ${req.originalUrl}`, env.isProd ? err.message : err);

  const body = { success: false, message, code };
  if (details) body.details = details;
  if (!env.isProd && status >= 500) body.stack = err.stack;
  res.status(status).json(body);
}
