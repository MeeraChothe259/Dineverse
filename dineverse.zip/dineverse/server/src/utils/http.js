export class ApiError extends Error {
  constructor(status, message, code = 'ERROR', details) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

export const badRequest = (msg, code = 'BAD_REQUEST', details) => new ApiError(400, msg, code, details);
export const unauthorized = (msg = 'Authentication required.', code = 'UNAUTHENTICATED') => new ApiError(401, msg, code);
export const forbidden = (msg = 'You do not have permission to do that.', code = 'FORBIDDEN') => new ApiError(403, msg, code);
export const notFound = (msg = 'Not found.', code = 'NOT_FOUND') => new ApiError(404, msg, code);
export const conflict = (msg, code = 'CONFLICT', details) => new ApiError(409, msg, code, details);

export const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

export function ok(res, data = null, message, meta, status = 200) {
  const body = { success: true, data };
  if (message) body.message = message;
  if (meta) body.meta = meta;
  return res.status(status).json(body);
}

export const created = (res, data, message) => ok(res, data, message, undefined, 201);

export function paginationFrom(query, { defaultLimit = 12, maxLimit = 50 } = {}) {
  const page = Math.max(1, parseInt(query.page, 10) || 1);
  const limit = Math.min(maxLimit, Math.max(1, parseInt(query.limit, 10) || defaultLimit));
  return { page, limit, skip: (page - 1) * limit };
}

export const pageMeta = ({ page, limit }, total) => ({ page, limit, total, pages: Math.max(1, Math.ceil(total / limit)) });

export const escapeRegex = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

export function slugify(text) {
  return String(text)
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/&/g, ' and ')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60);
}
