// Pure business rules for reservations: no database access, easy to unit-test.
import { DAY, MINUTE, addMinutes, localParts, zonedToUtc } from './time.js';

/** Allowed status transitions. Anything not listed is rejected. */
export const ALLOWED_TRANSITIONS = {
  pending: ['confirmed', 'cancelled'],
  confirmed: ['checked_in', 'cancelled', 'no_show'],
  checked_in: ['seated', 'cancelled'],
  seated: ['completed'],
  completed: [],
  cancelled: [],
  no_show: [],
};

export const canTransition = (from, to) => (ALLOWED_TRANSITIONS[from] || []).includes(to);
export const isTerminal = (status) => (ALLOWED_TRANSITIONS[status] || []).length === 0;

export function openingEntry(restaurant, weekday) {
  return (restaurant.openingHours || []).find((h) => h.day === weekday);
}

/** [openUtc, closeUtc] for the local date, or null if closed. Handles closing past midnight. */
export function openingWindow(restaurant, dateStr, weekday) {
  const entry = openingEntry(restaurant, weekday);
  if (!entry || entry.closed) return null;
  const tz = restaurant.timezone || 'Asia/Kolkata';
  const open = zonedToUtc(dateStr, entry.open, tz);
  let close = zonedToUtc(dateStr, entry.close, tz);
  if (close <= open) close = new Date(close.getTime() + DAY);
  return { open, close };
}

export function isWithinOpeningHours(restaurant, startAt, endAt) {
  const tz = restaurant.timezone || 'Asia/Kolkata';
  const { date, weekday } = localParts(startAt, tz);
  const win = openingWindow(restaurant, date, weekday);
  if (!win) return false;
  return startAt >= win.open && endAt <= win.close;
}

/** Returns an error code string, or null when the start time is acceptable. */
export function validateBookingWindow(settings, startAt, now = new Date()) {
  if (startAt.getTime() < now.getTime()) return 'PAST_TIME';
  if (startAt.getTime() > now.getTime() + settings.advanceBookingDays * DAY) return 'TOO_FAR_AHEAD';
  return null;
}

/** Start times (local HH:MM + UTC instants) that fit entirely inside opening hours for a date. */
export function generateSlots(restaurant, dateStr, weekday) {
  const win = openingWindow(restaurant, dateStr, weekday);
  if (!win) return [];
  const s = restaurant.reservationSettings || {};
  const duration = s.durationMinutes || 90;
  const step = (s.slotIntervalMinutes || 30) * MINUTE;
  const tz = restaurant.timezone || 'Asia/Kolkata';
  const out = [];
  for (let t = win.open.getTime(); t + duration * MINUTE <= win.close.getTime(); t += step) {
    const startAt = new Date(t);
    out.push({ time: localParts(startAt, tz).time, startAt, endAt: addMinutes(startAt, duration) });
  }
  return out;
}

/**
 * Availability state of each table for [startAt, blockedUntil).
 *  disabled    - inactive or out of service
 *  unavailable - a blocking reservation overlaps
 *  too_small   - capacity below the party size
 *  available   - can be booked
 */
export function computeTableStates({ tables, reservations, startAt, blockedUntil, guests }) {
  return tables.map((t) => {
    let state = 'available';
    if (!t.isActive || t.status === 'out_of_service') state = 'disabled';
    else if (
      reservations.some(
        (r) => String(r.tableId) === String(t._id) && r.startAt < blockedUntil && r.blockedUntil > startAt
      )
    )
      state = 'unavailable';
    else if (t.capacity < guests) state = 'too_small';
    return { table: t, state };
  });
}

export function canCancel(reservation, restaurant, now = new Date()) {
  if (!['pending', 'confirmed'].includes(reservation.status)) return false;
  const cutoff = restaurant?.reservationSettings?.cancellationCutoffHours ?? 2;
  return now.getTime() <= reservation.startAt.getTime() - cutoff * 60 * MINUTE;
}

/** 'too_early' | 'ok' | 'expired' relative to the reservation's arrival window. */
export function arrivalWindowState(reservation, restaurant, now = new Date()) {
  const windowMin = restaurant?.reservationSettings?.checkInWindowMinutes ?? 30;
  if (now.getTime() < reservation.startAt.getTime() - windowMin * MINUTE) return 'too_early';
  if (now.getTime() > reservation.endAt.getTime()) return 'expired';
  return 'ok';
}
