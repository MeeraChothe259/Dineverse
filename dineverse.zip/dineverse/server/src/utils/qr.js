import crypto from 'node:crypto';
import { env } from '../config/env.js';

const B32 = 'ABCDEFGHJKMNPQRSTVWXYZ23456789'; // no ambiguous characters

/** Human-friendly booking reference, e.g. DV-7K2M9XQA */
export function generateBookingReference() {
  const bytes = crypto.randomBytes(8);
  let out = '';
  for (const b of bytes) out += B32[b % B32.length];
  return `DV-${out}`;
}

const sign = (id) => crypto.createHmac('sha256', env.QR_SECRET).update(`qr:${id}`).digest('base64url').slice(0, 32);

/**
 * Signed identifier: "<reservationId>.<hmac>". Contains no personal data and cannot be
 * forged without QR_SECRET. Only a SHA-256 hash of it is stored in the database.
 */
export const makeQrToken = (reservationId) => `${reservationId}.${sign(reservationId)}`;

export const hashToken = (token) => crypto.createHash('sha256').update(String(token)).digest('hex');

/** Returns the reservation id if the token's signature is valid, else null. */
export function parseQrToken(raw) {
  if (typeof raw !== 'string') return null;
  const token = raw.trim().split(':').pop(); // tolerate the "dineverse:checkin:" prefix
  const [id, sig] = token.split('.');
  if (!id || !sig || !/^[a-f0-9]{24}$/.test(id)) return null;
  const expected = Buffer.from(sign(id));
  const actual = Buffer.from(sig);
  if (expected.length !== actual.length || !crypto.timingSafeEqual(expected, actual)) return null;
  return id;
}

export const qrPayload = (token) => `dineverse:checkin:${token}`;
