// Time helpers. All instants are stored as UTC Dates; restaurant opening hours are
// interpreted in the restaurant's own IANA timezone (e.g. Asia/Kolkata).

export const SLOT_MINUTES = 15;
const SLOT_MS = SLOT_MINUTES * 60 * 1000;
export const MINUTE = 60 * 1000;
export const DAY = 24 * 60 * MINUTE;

const dtfCache = new Map();
function dtf(tz) {
  if (!dtfCache.has(tz)) {
    dtfCache.set(
      tz,
      new Intl.DateTimeFormat('en-US', {
        timeZone: tz,
        hourCycle: 'h23',
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      })
    );
  }
  return dtfCache.get(tz);
}

export function isValidTimezone(tz) {
  try {
    new Intl.DateTimeFormat('en-US', { timeZone: tz });
    return true;
  } catch {
    return false;
  }
}

export function isValidDateStr(s) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s || '')) return false;
  const [y, m, d] = s.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d;
}

export const isValidTimeStr = (s) => /^([01]\d|2[0-3]):[0-5]\d$/.test(s || '');

/** Offset (minutes) of `tz` from UTC at the given instant. */
export function tzOffsetMinutes(date, tz) {
  const p = Object.fromEntries(dtf(tz).formatToParts(date).map((x) => [x.type, x.value]));
  const asUtc = Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour, +p.minute, +p.second);
  return Math.round((asUtc - Math.floor(date.getTime() / 1000) * 1000) / MINUTE);
}

/** Convert a wall-clock local date/time in `tz` to a UTC Date. */
export function zonedToUtc(dateStr, timeStr, tz) {
  const [y, m, d] = dateStr.split('-').map(Number);
  const [hh, mm] = timeStr.split(':').map(Number);
  const naive = Date.UTC(y, m - 1, d, hh, mm);
  let ts = naive - tzOffsetMinutes(new Date(naive), tz) * MINUTE;
  ts = naive - tzOffsetMinutes(new Date(ts), tz) * MINUTE; // second pass handles DST edges
  return new Date(ts);
}

/** Local date ("YYYY-MM-DD"), time ("HH:MM") and weekday (0=Sun) of an instant in `tz`. */
export function localParts(date, tz) {
  const p = Object.fromEntries(dtf(tz).formatToParts(date).map((x) => [x.type, x.value]));
  const dateStr = `${p.year}-${p.month}-${p.day}`;
  const weekday = new Date(Date.UTC(+p.year, +p.month - 1, +p.day)).getUTCDay();
  return { date: dateStr, time: `${p.hour}:${p.minute}`, weekday };
}

export const weekdayOf = (dateStr) => {
  const [y, m, d] = dateStr.split('-').map(Number);
  return new Date(Date.UTC(y, m - 1, d)).getUTCDay();
};

export const addMinutes = (date, minutes) => new Date(date.getTime() + minutes * MINUTE);

/** Keys of every 15-minute slot touched by [start, end) for a table. */
export function slotKeys(tableId, start, end) {
  const keys = [];
  for (let t = Math.floor(start.getTime() / SLOT_MS); t * SLOT_MS < end.getTime(); t++) {
    keys.push(`${tableId}:${t}`);
  }
  return keys;
}
