// Pure analytics builder: turns reservation + table records into dashboard metrics.
// Every number is derived from stored data; nothing is invented (no revenue figures).
import { DAY, MINUTE, localParts } from './time.js';

const WEEKDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export function buildAnalytics({ reservations, restaurants, tables, from, to, now = new Date() }) {
  const tzOf = new Map(restaurants.map((r) => [String(r._id), r.timezone || 'Asia/Kolkata']));
  const days = Math.max(1, Math.round((to - from) / DAY));
  const inRange = reservations.filter((r) => r.startAt >= from && r.startAt < to);

  const count = (arr, keyFn) => {
    const m = new Map();
    for (const x of arr) m.set(keyFn(x), (m.get(keyFn(x)) || 0) + 1);
    return m;
  };

  const cancelled = inRange.filter((r) => r.status === 'cancelled');
  const active = inRange.filter((r) => r.status !== 'cancelled');
  const completedLike = inRange.filter((r) => ['completed', 'seated', 'checked_in'].includes(r.status));
  const upcoming = reservations.filter((r) => r.startAt >= now && ['pending', 'confirmed'].includes(r.status));

  const byStatus = [...count(inRange, (r) => r.status)].map(([status, n]) => ({ status, count: n }));
  const bySource = [...count(inRange, (r) => r.source)].map(([source, n]) => ({ source, count: n }));

  const dayMap = count(active, (r) => r.date);
  const byDay = [];
  for (let t = from.getTime(); t < to.getTime(); t += DAY) {
    const d = new Date(t).toISOString().slice(0, 10);
    byDay.push({ date: d, count: dayMap.get(d) || 0 });
  }

  const wk = new Array(7).fill(0);
  for (const r of active) wk[localParts(r.startAt, tzOf.get(String(r.restaurantId)) || 'Asia/Kolkata').weekday]++;
  const byWeekday = wk.map((count_, i) => ({ weekday: WEEKDAYS[i], count: count_ }));

  // Occupancy by local hour: reserved table-minutes in that hour / (tables * days * 60).
  const tableCount = Math.max(1, tables.filter((t) => t.isActive).length);
  const minutesByHour = new Array(24).fill(0);
  let reservedMinutes = 0;
  for (const r of active) {
    const tz = tzOf.get(String(r.restaurantId)) || 'Asia/Kolkata';
    for (let t = r.startAt.getTime(); t < r.endAt.getTime(); t += MINUTE) {
      minutesByHour[+localParts(new Date(t), tz).time.slice(0, 2)]++;
    }
    reservedMinutes += (r.endAt - r.startAt) / MINUTE;
  }
  const byHour = minutesByHour
    .map((mins, hour) => ({ hour, label: `${String(hour).padStart(2, '0')}:00`, occupancyPct: Math.min(100, Math.round((mins / (tableCount * days * 60)) * 100)) }))
    .filter((h) => h.occupancyPct > 0);

  // Overall occupancy against average daily opening minutes.
  let openMinutesPerDay = 0;
  for (const r of restaurants) {
    const open = (r.openingHours || []).filter((h) => !h.closed);
    if (!open.length) continue;
    const avg =
      open.reduce((s, h) => {
        const [oh, om] = h.open.split(':').map(Number);
        const [ch, cm] = h.close.split(':').map(Number);
        let m = ch * 60 + cm - (oh * 60 + om);
        if (m <= 0) m += 1440;
        return s + m;
      }, 0) / open.length;
    openMinutesPerDay += avg * (open.length / 7);
  }
  const capacityMinutes = Math.max(1, tableCount * days * (openMinutesPerDay / Math.max(1, restaurants.length)));
  const occupancyPct = Math.min(100, Math.round((reservedMinutes / capacityMinutes) * 100));

  return {
    range: { from, to },
    totals: {
      bookings: inRange.length,
      upcoming: upcoming.length,
      confirmed: inRange.filter((r) => r.status === 'confirmed').length,
      completed: completedLike.length,
      cancelled: cancelled.length,
      noShow: inRange.filter((r) => r.status === 'no_show').length,
      cancellationRate: inRange.length ? Math.round((cancelled.length / inRange.length) * 1000) / 10 : 0,
      guests: active.reduce((s, r) => s + r.guestCount, 0),
      online: inRange.filter((r) => r.source === 'online').length,
      walkIn: inRange.filter((r) => r.source === 'walk_in').length,
      occupancyPct,
    },
    byDay,
    byWeekday,
    byStatus,
    bySource,
    byHour,
    containsDemoData: restaurants.some((r) => r.isDemo),
  };
}
