import mongoose from 'mongoose';
import { Restaurant } from '../models/Restaurant.js';
import { StaffAssignment } from '../models/StaffAssignment.js';
import { badRequest, forbidden, notFound } from '../utils/http.js';

const isId = (id) => mongoose.isValidObjectId(id) && /^[a-f0-9]{24}$/i.test(String(id));

/**
 * Central authorisation for restaurant-scoped data.
 *  admin -> any restaurant; owner -> restaurants they own; staff -> active assignment
 *  (optionally requiring a specific permission).
 */
export async function canAccessRestaurant(user, restaurantId, permission) {
  if (!user || !isId(restaurantId)) return false;
  if (user.role === 'admin') return true;
  if (user.role === 'owner') return !!(await Restaurant.exists({ _id: restaurantId, ownerId: user._id }));
  if (user.role === 'staff') {
    const a = await StaffAssignment.findOne({ userId: user._id, restaurantId, isActive: true }).lean();
    return !!a && (!permission || a.permissions.includes(permission));
  }
  return false;
}

/** Returns the restaurant or throws 400/403/404. Never trusts a client-supplied id by itself. */
export async function assertRestaurantAccess(user, restaurantId, permission) {
  if (!isId(restaurantId)) throw badRequest('Invalid restaurant id.', 'INVALID_ID');
  const restaurant = await Restaurant.findById(restaurantId);
  if (!restaurant) throw notFound('Restaurant not found.');
  if (!(await canAccessRestaurant(user, restaurantId, permission))) {
    throw forbidden('You do not have access to this restaurant.');
  }
  return restaurant;
}

/** Restaurant ids the user can manage. */
export async function accessibleRestaurantIds(user) {
  if (user.role === 'admin') return (await Restaurant.find().select('_id').lean()).map((r) => r._id);
  if (user.role === 'owner') return (await Restaurant.find({ ownerId: user._id }).select('_id').lean()).map((r) => r._id);
  if (user.role === 'staff')
    return (await StaffAssignment.find({ userId: user._id, isActive: true }).select('restaurantId').lean()).map((a) => a.restaurantId);
  return [];
}

/** For staff/owner endpoints: use the requested restaurant, or default to the user's first one. */
export async function resolveWorkplace(user, requestedId, permission) {
  let id = requestedId;
  if (!id) {
    const ids = await accessibleRestaurantIds(user);
    if (!ids.length) throw forbidden('No restaurant is assigned to your account yet.', 'NO_ASSIGNMENT');
    id = String(ids[0]);
  }
  return assertRestaurantAccess(user, id, permission);
}
