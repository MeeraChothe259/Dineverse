import { Reservation } from '../models/Reservation.js';
import { Table } from '../models/Table.js';
import { DAY, MINUTE, addMinutes, weekdayOf, zonedToUtc } from '../utils/time.js';
import { computeTableStates, generateSlots, isWithinOpeningHours, validateBookingWindow } from '../utils/reservationRules.js';

export const holdWindow = (restaurant, startAt, durationMinutes) => {
  const s = restaurant.reservationSettings || {};
  const minutes = durationMinutes || s.durationMinutes || 90;
  const endAt = addMinutes(startAt, minutes);
  return { endAt, blockedUntil: addMinutes(endAt, s.bufferMinutes || 0) };
};

export const tableLayoutDto = (t) => ({
  id: String(t._id),
  tableNumber: t.tableNumber,
  displayName: t.displayName || `Table ${t.tableNumber}`,
  capacity: t.capacity,
  shape: t.shape,
  dimensions: t.dimensions,
  position: t.position,
  rotation: t.rotation,
  isActive: t.isActive,
});

export async function blockingReservations(restaurantId, from, to) {
  return Reservation.find({ restaurantId, blocking: true, startAt: { $lt: to }, blockedUntil: { $gt: from } })
    .select('tableId startAt blockedUntil')
    .lean();
}

/** Why a slot cannot be booked at all (closed, past, ...), or null. */
export function slotProblem(restaurant, startAt, endAt, now = new Date()) {
  const s = restaurant.reservationSettings;
  if (restaurant.status !== 'active') return 'RESTAURANT_UNAVAILABLE';
  if (!s.acceptingReservations) return 'NOT_ACCEPTING';
  const w = validateBookingWindow(s, startAt, now);
  if (w) return w;
  if (!isWithinOpeningHours(restaurant, startAt, endAt)) return 'OUTSIDE_HOURS';
  return null;
}

export async function getAvailability(restaurant, { date, time, guests }, now = new Date()) {
  const tz = restaurant.timezone;
  const startAt = zonedToUtc(date, time, tz);
  const { endAt, blockedUntil } = holdWindow(restaurant, startAt);
  const problem = slotProblem(restaurant, startAt, endAt, now);

  const tables = await Table.find({ restaurantId: restaurant._id, isActive: true }).sort({ tableNumber: 1 }).lean();
  const reservations = problem ? [] : await blockingReservations(restaurant._id, startAt, blockedUntil);
  const states = computeTableStates({ tables, reservations, startAt, blockedUntil, guests });

  const out = states.map(({ table, state }) => ({
    ...tableLayoutDto(table),
    state: problem && state !== 'disabled' ? 'unavailable' : state,
    selectable: !problem && state === 'available',
  }));

  return {
    slot: { date, time, startAt, endAt, problem },
    tables: out,
    summary: { available: out.filter((t) => t.selectable).length, total: out.length },
    slots: await slotAvailability(restaurant, date, guests, now),
  };
}

/** For every bookable start time on a date: how many suitable tables are free. */
export async function slotAvailability(restaurant, date, guests, now = new Date()) {
  const slots = generateSlots(restaurant, date, weekdayOf(date));
  if (!slots.length || restaurant.status !== 'active') return [];
  const tables = await Table.find({ restaurantId: restaurant._id, isActive: true }).lean();
  const dayStart = zonedToUtc(date, '00:00', restaurant.timezone);
  const reservations = await blockingReservations(restaurant._id, dayStart, new Date(dayStart.getTime() + 2 * DAY));
  const settings = restaurant.reservationSettings;
  return slots
    .filter((s) => !validateBookingWindow(settings, s.startAt, now))
    .map((s) => {
      const { blockedUntil } = holdWindow(restaurant, s.startAt);
      const free = computeTableStates({ tables, reservations, startAt: s.startAt, blockedUntil, guests }).filter(
        (x) => x.state === 'available'
      ).length;
      return { time: s.time, availableCount: free };
    });
}

/** Restaurants-list helper: does any suitable table exist at that slot? */
export async function hasAvailability(restaurant, { date, time, guests }, now = new Date()) {
  const startAt = zonedToUtc(date, time, restaurant.timezone);
  const { endAt, blockedUntil } = holdWindow(restaurant, startAt);
  if (slotProblem(restaurant, startAt, endAt, now)) return false;
  const tables = await Table.find({ restaurantId: restaurant._id, isActive: true }).lean();
  const reservations = await blockingReservations(restaurant._id, startAt, blockedUntil);
  return computeTableStates({ tables, reservations, startAt, blockedUntil, guests }).some((x) => x.state === 'available');
}

export { MINUTE };
