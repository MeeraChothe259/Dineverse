import { AuditLog } from '../models/AuditLog.js';

const SECRET_KEYS = /pass(word)?|token|secret|hash|authorization|cookie/i;

function scrub(value, depth = 0) {
  if (value == null || depth > 3) return value;
  if (Array.isArray(value)) return value.slice(0, 20).map((v) => scrub(v, depth + 1));
  if (typeof value === 'object' && !(value instanceof Date) && !value._bsontype) {
    return Object.fromEntries(
      Object.entries(value).map(([k, v]) => [k, SECRET_KEYS.test(k) ? '[redacted]' : scrub(v, depth + 1)])
    );
  }
  return value;
}

/** Record an important action. Never throws: auditing must not break the request. */
export async function audit(actor, action, targetType, targetId, { restaurantId, metadata } = {}) {
  try {
    await AuditLog.create({
      actorId: actor._id,
      actorRole: actor.role,
      restaurantId,
      action,
      targetType,
      targetId: targetId ? String(targetId) : undefined,
      metadata: scrub(metadata),
    });
  } catch (e) {
    console.error('[audit] failed to write audit log:', e.message);
  }
}
