import mongoose from 'mongoose';
import { Reservation, BLOCKING_STATUSES } from '../models/Reservation.js';
import { Table } from '../models/Table.js';
import { conflict, badRequest, notFound } from '../utils/http.js';
import { canTransition, isTerminal } from '../utils/reservationRules.js';
import { generateBookingReference, hashToken, makeQrToken } from '../utils/qr.js';
import { localParts, slotKeys, zonedToUtc } from '../utils/time.js';
import { blockingReservations, getAvailability, holdWindow, slotProblem, tableLayoutDto } from './availability.js';
import { emitToRestaurant, emitToUser } from '../sockets/index.js';

const PROBLEM_MESSAGES = {
  RESTAURANT_UNAVAILABLE: 'This restaurant is not accepting reservations right now.',
  NOT_ACCEPTING: 'This restaurant has paused online reservations.',
  PAST_TIME: 'That time has already passed.',
  TOO_FAR_AHEAD: 'That date is too far in the future to book.',
  OUTSIDE_HOURS: 'That time is outside the restaurant\'s opening hours, or the booking would run past closing.',
};

/** Builds a reservation document (no DB writes). Used by booking, walk-ins and the seed script. */
export function buildReservationDoc({ restaurant, table, startAt, durationMinutes, guestCount, customer, status = 'confirmed', source = 'online', extra = {} }) {
  const _id = new mongoose.Types.ObjectId();
  const { endAt, blockedUntil } = holdWindow(restaurant, startAt, durationMinutes);
  const token = makeQrToken(_id);
  return {
    _id,
    bookingReference: generateBookingReference(),
    customerId: customer?._id || null,
    restaurantId: restaurant._id,
    tableId: table._id,
    date: extra.date,
    startAt,
    endAt,
    blockedUntil,
    guestCount,
    customerName: customer?.name,
    customerEmail: customer?.email,
    customerPhone: customer?.phone,
    status,
    source,
    qrTokenHash: hashToken(token),
    slotKeys: slotKeys(table._id, startAt, blockedUntil),
    blocking: BLOCKING_STATUSES.includes(status),
    ...extra,
  };
}

async function conflictError(restaurant, { date, time, guests }) {
  let details;
  try {
    const a = await getAvailability(restaurant, { date, time, guests });
    details = {
      alternativeTables: a.tables.filter((t) => t.selectable).slice(0, 6).map((t) => ({ id: t.id, displayName: t.displayName, capacity: t.capacity })),
      alternativeSlots: a.slots.filter((s) => s.availableCount > 0).slice(0, 8),
    };
  } catch {
    details = undefined;
  }
  return conflict('That table was just taken for this time. Please choose another table or time.', 'SLOT_CONFLICT', details);
}

/**
 * Creates an online reservation. The backend revalidates everything; the unique
 * slot-key index is the final, race-proof guard against double booking.
 */
export async function createOnlineReservation({ restaurant, user, tableId, date, time, guestCount, specialRequests, phone }, now = new Date()) {
  const s = restaurant.reservationSettings;
  const startAt = zonedToUtc(date, time, restaurant.timezone);
  const { endAt, blockedUntil } = holdWindow(restaurant, startAt);

  const problem = slotProblem(restaurant, startAt, endAt, now);
  if (problem) throw badRequest(PROBLEM_MESSAGES[problem], problem);
  if (guestCount < s.minPartySize || guestCount > s.maxPartySize)
    throw badRequest(`Party size must be between ${s.minPartySize} and ${s.maxPartySize}.`, 'INVALID_PARTY_SIZE');

  const table = await Table.findOne({ _id: tableId, restaurantId: restaurant._id });
  if (!table) throw notFound('That table does not belong to this restaurant.', 'TABLE_NOT_FOUND');
  if (!table.isActive || table.status === 'out_of_service') throw badRequest('That table is not available for booking.', 'TABLE_DISABLED');
  if (table.capacity < guestCount) throw badRequest(`That table seats up to ${table.capacity} guests.`, 'CAPACITY_EXCEEDED');

  const overlapping = await blockingReservations(restaurant._id, startAt, blockedUntil);
  if (overlapping.some((r) => String(r.tableId) === String(table._id))) throw await conflictError(restaurant, { date, time, guests: guestCount });

  const doc = buildReservationDoc({
    restaurant,
    table,
    startAt,
    guestCount,
    customer: { _id: user._id, name: user.name, email: user.email, phone: phone || user.phone },
    extra: { date, specialRequests: specialRequests || '', createdBy: user._id },
  });

  let reservation;
  try {
    reservation = await Reservation.create(doc);
  } catch (e) {
    if (e.code === 11000) throw await conflictError(restaurant, { date, time, guests: guestCount });
    throw e;
  }
  announce(reservation, 'reservation:created');
  return reservation;
}

/** Walk-in: seats guests immediately (or at a near-future time) with the same conflict guarantees. */
export async function createWalkIn({ restaurant, staff, tableId, guestName, phone, guestCount, notes, durationMinutes, now = new Date() }) {
  if (restaurant.status !== 'active') throw badRequest('This restaurant is not active.', 'RESTAURANT_UNAVAILABLE');
  const table = await Table.findOne({ _id: tableId, restaurantId: restaurant._id });
  if (!table) throw notFound('That table does not belong to this restaurant.', 'TABLE_NOT_FOUND');
  if (!table.isActive || table.status === 'out_of_service') throw badRequest('That table is out of service.', 'TABLE_DISABLED');
  if (table.capacity < guestCount) throw badRequest(`That table seats up to ${table.capacity} guests.`, 'CAPACITY_EXCEEDED');

  const startAt = new Date(Math.floor(now.getTime() / 60000) * 60000);
  const { blockedUntil } = holdWindow(restaurant, startAt, durationMinutes);
  const overlapping = await blockingReservations(restaurant._id, startAt, blockedUntil);
  if (overlapping.some((r) => String(r.tableId) === String(table._id)))
    throw conflict('That table is booked or occupied during this period. Choose another table or a shorter stay.', 'SLOT_CONFLICT');

  const doc = buildReservationDoc({
    restaurant,
    table,
    startAt,
    durationMinutes,
    guestCount,
    customer: { name: guestName, phone },
    status: 'seated',
    source: 'walk_in',
    extra: { date: localParts(startAt, restaurant.timezone).date, specialRequests: notes || '', seatedAt: startAt, createdBy: staff._id },
  });
  try {
    const r = await Reservation.create(doc);
    await Table.updateOne({ _id: table._id }, { status: 'occupied' });
    announce(r, 'reservation:created');
    emitToRestaurant(restaurant._id, 'table:status', { tableId: String(table._id), status: 'occupied' });
    return r;
  } catch (e) {
    if (e.code === 11000) throw conflict('That table was just taken. Please choose another.', 'SLOT_CONFLICT');
    throw e;
  }
}

const TIMESTAMP_FOR = { checked_in: 'checkedInAt', seated: 'seatedAt', completed: 'completedAt', cancelled: 'cancelledAt' };

/**
 * Atomic, validated status change. The update is conditional on the current status, so two
 * concurrent requests (e.g. duplicate check-ins) cannot both succeed.
 */
export async function transitionReservation(reservation, to, actor, { reason } = {}) {
  if (!canTransition(reservation.status, to)) {
    throw conflict(`A ${reservation.status.replace('_', ' ')} reservation cannot be changed to ${to.replace('_', ' ')}.`, 'INVALID_TRANSITION');
  }
  const now = new Date();
  const set = { status: to };
  if (TIMESTAMP_FOR[to]) set[TIMESTAMP_FOR[to]] = now;
  if (to === 'checked_in') set.checkedInBy = actor._id;
  if (to === 'cancelled') {
    set.cancelledBy = actor._id;
    if (reason) set.cancelReason = reason;
  }
  if (isTerminal(to)) set.blocking = false; // frees the table's slots immediately

  const updated = await Reservation.findOneAndUpdate({ _id: reservation._id, status: reservation.status }, { $set: set }, { new: true });
  if (!updated) throw conflict('This reservation was just updated by someone else. Please refresh.', 'STALE_STATE');

  if (to === 'seated') await Table.updateOne({ _id: updated.tableId }, { status: 'occupied' });
  if (to === 'completed') await Table.updateOne({ _id: updated.tableId, status: 'occupied' }, { status: 'cleaning' });
  announce(updated, to === 'cancelled' ? 'reservation:cancelled' : to === 'checked_in' ? 'guest:checked_in' : 'reservation:updated');
  return updated;
}

/** Realtime fan-out. Payloads carry ids/status only, never names or contact details. */
export function announce(reservation, event) {
  const payload = {
    reservationId: String(reservation._id),
    bookingReference: reservation.bookingReference,
    tableId: String(reservation.tableId),
    status: reservation.status,
    startAt: reservation.startAt,
    guestCount: reservation.guestCount,
  };
  emitToRestaurant(reservation.restaurantId, event, payload);
  emitToUser(reservation.customerId, event, payload);
}

// ---------- serialisation ----------
const imageOf = (r) => r?.images?.[0] || null;

export function serializeReservation(r, { management = false, canCancel = false } = {}) {
  const restaurant = r.restaurantId && r.restaurantId.name ? r.restaurantId : null;
  const table = r.tableId && r.tableId.tableNumber ? r.tableId : null;
  const out = {
    id: String(r._id),
    bookingReference: r.bookingReference,
    status: r.status,
    source: r.source,
    date: r.date,
    startAt: r.startAt,
    endAt: r.endAt,
    guestCount: r.guestCount,
    specialRequests: r.specialRequests,
    customerName: r.customerName,
    restaurantId: String(restaurant?._id || r.restaurantId),
    tableId: String(table?._id || r.tableId),
    restaurant: restaurant && {
      id: String(restaurant._id),
      name: restaurant.name,
      slug: restaurant.slug,
      image: imageOf(restaurant),
      timezone: restaurant.timezone,
      city: restaurant.address?.city,
      isDemo: restaurant.isDemo,
    },
    table: table && { id: String(table._id), tableNumber: table.tableNumber, displayName: table.displayName || `Table ${table.tableNumber}`, capacity: table.capacity },
    checkedInAt: r.checkedInAt,
    seatedAt: r.seatedAt,
    completedAt: r.completedAt,
    cancelledAt: r.cancelledAt,
    createdAt: r.createdAt,
    canCancel,
    isDemo: r.isDemo,
  };
  if (management) {
    out.customerEmail = r.customerEmail;
    out.customerPhone = r.customerPhone;
    out.cancelReason = r.cancelReason;
  }
  return out;
}

export { tableLayoutDto };
