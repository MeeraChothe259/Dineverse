import { Reservation } from '../models/Reservation.js';
import { Table } from '../models/Table.js';
import { DAY, MINUTE, localParts, zonedToUtc } from '../utils/time.js';

/**
 * Effective table status right now. Manual statuses set by staff win for out_of_service/cleaning;
 * otherwise live reservations decide occupied/reserved.
 */
export function liveTableStatus(table, activeReservations, now = new Date()) {
  if (table.status === 'out_of_service') return 'out_of_service';
  if (table.status === 'cleaning') return 'cleaning';
  const mine = activeReservations.filter((r) => String(r.tableId) === String(table._id));
  if (mine.some((r) => r.status === 'seated' || r.status === 'checked_in')) return 'occupied';
  if (table.status === 'occupied' && !mine.length) return 'occupied';
  if (mine.some((r) => r.status === 'confirmed' && r.startAt.getTime() - now.getTime() <= 60 * MINUTE && r.endAt > now)) return 'reserved';
  return 'available';
}

export function dayRange(restaurant, now = new Date(), dateStr) {
  const date = dateStr || localParts(now, restaurant.timezone).date;
  const start = zonedToUtc(date, '00:00', restaurant.timezone);
  return { date, start, end: new Date(start.getTime() + DAY) };
}

export async function staffDashboard(restaurant, now = new Date()) {
  const { date, start, end } = dayRange(restaurant, now);
  const [reservations, tables] = await Promise.all([
    Reservation.find({ restaurantId: restaurant._id, startAt: { $gte: start, $lt: end } }).lean(),
    Table.find({ restaurantId: restaurant._id, isActive: true }).sort({ tableNumber: 1 }).lean(),
  ]);
  const live = reservations.filter((r) => ['pending', 'confirmed', 'checked_in', 'seated'].includes(r.status));
  const statuses = tables.map((t) => ({ table: t, status: liveTableStatus(t, live, now) }));
  const notCancelled = reservations.filter((r) => !['cancelled'].includes(r.status));
  const arrived = notCancelled.filter((r) => ['checked_in', 'seated', 'completed'].includes(r.status));
  return {
    date,
    stats: {
      reservationsToday: notCancelled.length,
      expectedGuests: notCancelled.filter((r) => r.status !== 'no_show').reduce((s, r) => s + r.guestCount, 0),
      checkedInGuests: arrived.reduce((s, r) => s + r.guestCount, 0),
      upcomingArrivals: notCancelled.filter((r) => r.status === 'confirmed' && r.endAt > now).length,
      availableTables: statuses.filter((s) => s.status === 'available').length,
      occupiedTables: statuses.filter((s) => s.status === 'occupied').length,
      totalTables: tables.length,
    },
    tables: statuses.map(({ table, status }) => ({ id: String(table._id), tableNumber: table.tableNumber, displayName: table.displayName || `Table ${table.tableNumber}`, capacity: table.capacity, status, manualStatus: table.status })),
  };
}
