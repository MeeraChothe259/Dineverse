import { Reservation } from '../models/Reservation.js';
import { Restaurant } from '../models/Restaurant.js';
import { canAccessRestaurant } from './access.js';
import { hashToken, parseQrToken } from '../utils/qr.js';
import { arrivalWindowState } from '../utils/reservationRules.js';
import { serializeReservation, transitionReservation } from './reservations.js';
import { conflict } from '../utils/http.js';

const MESSAGES = {
  valid: 'Reservation verified. Ready to check in.',
  invalid: 'This code is not a valid DineVerse reservation.',
  wrong_restaurant: 'This reservation is for a different restaurant.',
  cancelled: 'This reservation was cancelled.',
  no_show: 'This reservation was marked as a no-show.',
  already_used: 'This guest has already been checked in.',
  completed: 'This reservation has already been completed.',
  too_early: 'Too early: check-in opens shortly before the reservation time.',
  expired: 'This reservation has expired (past its end time).',
  pending: 'This reservation is awaiting approval.',
};

/** Find by signed QR token (validated + hash-checked) or by booking reference. */
async function locate({ token, reference }) {
  if (token) {
    const id = parseQrToken(token);
    if (!id) return null;
    const r = await Reservation.findById(id).populate('tableId', 'tableNumber displayName capacity');
    if (!r || r.qrTokenHash !== hashToken(String(token).trim().split(':').pop())) return null;
    return r;
  }
  if (reference) return Reservation.findOne({ bookingReference: reference }).populate('tableId', 'tableNumber displayName capacity');
  return null;
}

/**
 * Verifies a reservation for the given staff member without changing anything.
 * Always returns a { valid, state, message } object so the scanner UI can show clear states.
 */
export async function verifyCheckin(user, input, now = new Date()) {
  const r = await locate(input);
  if (!r) return { valid: false, state: 'invalid', message: MESSAGES.invalid };

  // Staff may only see reservations for restaurants they are assigned to (with check-in permission).
  if (!(await canAccessRestaurant(user, r.restaurantId, 'checkin')))
    return { valid: false, state: 'wrong_restaurant', message: MESSAGES.wrong_restaurant };

  const restaurant = await Restaurant.findById(r.restaurantId).select('name timezone reservationSettings');
  const base = { reservation: serializeReservation(r, { management: true }), restaurantName: restaurant.name };

  if (['checked_in', 'seated'].includes(r.status)) return { valid: false, state: 'already_used', message: MESSAGES.already_used, ...base };
  if (r.status === 'completed') return { valid: false, state: 'completed', message: MESSAGES.completed, ...base };
  if (r.status === 'cancelled') return { valid: false, state: 'cancelled', message: MESSAGES.cancelled, ...base };
  if (r.status === 'no_show') return { valid: false, state: 'no_show', message: MESSAGES.no_show, ...base };
  if (r.status === 'pending') return { valid: false, state: 'pending', message: MESSAGES.pending, ...base };

  const win = arrivalWindowState(r, restaurant, now);
  if (win !== 'ok') return { valid: false, state: win, message: MESSAGES[win], ...base };
  return { valid: true, state: 'valid', message: MESSAGES.valid, ...base };
}

/** Confirms check-in. Re-verifies everything and uses an atomic transition to block duplicates. */
export async function confirmCheckin(user, input, now = new Date()) {
  const result = await verifyCheckin(user, input, now);
  if (!result.valid) {
    const err = conflict(result.message, result.state === 'already_used' ? 'ALREADY_CHECKED_IN' : `CHECKIN_${result.state.toUpperCase()}`, { state: result.state });
    throw err;
  }
  const r = await Reservation.findById(result.reservation.id);
  const updated = await transitionReservation(r, 'checked_in', user).catch((e) => {
    if (e.code === 'STALE_STATE' || e.code === 'INVALID_TRANSITION') throw conflict(MESSAGES.already_used, 'ALREADY_CHECKED_IN', { state: 'already_used' });
    throw e;
  });
  return { ...result, state: 'checked_in', valid: true, message: 'Guest checked in.', reservation: serializeReservation(updated, { management: true }) };
}
