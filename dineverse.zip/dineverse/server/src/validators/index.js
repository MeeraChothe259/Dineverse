import { z } from 'zod';
import { isValidDateStr, isValidTimeStr, isValidTimezone } from '../utils/time.js';
import { EXPERIENCES } from '../models/Restaurant.js';
import { TABLE_SHAPES, TABLE_STATUSES } from '../models/Table.js';
import { DIETARY_LABELS } from '../models/MenuItem.js';
import { STAFF_PERMISSIONS } from '../models/StaffAssignment.js';

const objectId = z.string().regex(/^[a-f0-9]{24}$/i, 'Invalid id');
const dateStr = z.string().refine(isValidDateStr, 'Use a valid date (YYYY-MM-DD)');
const timeStr = z.string().refine(isValidTimeStr, 'Use a valid time (HH:MM)');
const trimmed = (max, min = 0) => z.string().trim().min(min).max(max);
const optionalText = (max) => z.string().trim().max(max).optional().or(z.literal(''));

// ---------- auth ----------
export const password = z
  .string()
  .min(8, 'Use at least 8 characters')
  .max(128)
  .regex(/[A-Za-z]/, 'Include a letter')
  .regex(/\d/, 'Include a number');

export const registerSchema = z
  .object({
    name: trimmed(80, 2),
    email: z.string().trim().toLowerCase().email().max(160),
    password,
    phone: optionalText(30),
    // Public sign-up can only ever create customers or restaurant-owner applicants. Never admin/staff.
    accountType: z.enum(['customer', 'owner']).default('customer'),
  })
  .strict();

export const loginSchema = z
  .object({ email: z.string().trim().toLowerCase().email(), password: z.string().min(1).max(128) })
  .strict();

export const updateMeSchema = z.object({ name: trimmed(80, 2).optional(), phone: optionalText(30) }).strict();
export const changePasswordSchema = z.object({ currentPassword: z.string().min(1).max(128), newPassword: password }).strict();

// ---------- public restaurants ----------
const csv = z
  .string()
  .optional()
  .transform((v) => (v ? v.split(',').map((s) => s.trim()).filter(Boolean) : []));

export const listRestaurantsQuery = z.object({
  q: z.string().trim().max(80).optional(),
  city: z.string().trim().max(80).optional(),
  cuisine: csv,
  price: csv,
  experience: z.enum(EXPERIENCES).optional(),
  minRating: z.coerce.number().min(0).max(5).optional(),
  date: dateStr.optional(),
  time: timeStr.optional(),
  guests: z.coerce.number().int().min(1).max(100).optional(),
  sort: z.enum(['recommended', 'rating', 'price_asc', 'price_desc']).default('recommended'),
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(50).default(9),
});

export const availabilityQuery = z.object({
  date: dateStr,
  time: timeStr,
  guests: z.coerce.number().int().min(1).max(100).default(2),
});

// ---------- reservations ----------
export const createReservationSchema = z
  .object({
    restaurantId: objectId,
    tableId: objectId,
    date: dateStr,
    time: timeStr,
    guestCount: z.coerce.number().int().min(1).max(100),
    specialRequests: optionalText(500),
    phone: optionalText(30),
  })
  .strict();

export const myReservationsQuery = z.object({
  group: z.enum(['upcoming', 'past', 'cancelled', 'all']).default('all'),
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(50).default(20),
});

export const cancelSchema = z.object({ reason: optionalText(300) }).strict();

// ---------- check-in ----------
export const checkinSchema = z
  .object({ token: z.string().trim().max(200).optional(), reference: z.string().trim().toUpperCase().max(30).optional(), restaurantId: objectId.optional() })
  .refine((v) => v.token || v.reference, { message: 'Provide a QR token or a booking reference' });

// ---------- owner ----------
const hoursEntry = z.object({
  day: z.number().int().min(0).max(6),
  open: timeStr,
  close: timeStr,
  closed: z.boolean().default(false),
});

const restaurantFields = {
  name: trimmed(120, 2),
  tagline: optionalText(160),
  description: optionalText(4000),
  cuisineTypes: z.array(trimmed(40, 1)).max(8),
  experiences: z.array(z.enum(EXPERIENCES)).max(6),
  address: z.object({
    line1: optionalText(200),
    city: trimmed(80, 1),
    state: optionalText(80),
    country: optionalText(80),
    postalCode: optionalText(20),
  }),
  contact: z.object({ phone: optionalText(30), email: optionalText(160), website: optionalText(300) }),
  timezone: z.string().refine(isValidTimezone, 'Unknown timezone'),
  priceRange: z.number().int().min(1).max(4),
  images: z.array(z.object({ url: trimmed(600, 1), alt: optionalText(200) })).max(12),
  amenities: z.array(trimmed(60, 1)).max(20),
  openingHours: z.array(hoursEntry).length(7),
  reservationSettings: z.object({
    acceptingReservations: z.boolean(),
    durationMinutes: z.number().int().min(30).max(360),
    bufferMinutes: z.number().int().min(0).max(120),
    slotIntervalMinutes: z.number().int().min(15).max(120),
    minPartySize: z.number().int().min(1).max(100),
    maxPartySize: z.number().int().min(1).max(100),
    advanceBookingDays: z.number().int().min(1).max(365),
    cancellationCutoffHours: z.number().int().min(0).max(168),
    checkInWindowMinutes: z.number().int().min(0).max(180),
  }),
  policies: optionalText(2000),
};

export const createRestaurantSchema = z
  .object({ name: restaurantFields.name, address: restaurantFields.address, cuisineTypes: restaurantFields.cuisineTypes.default([]), description: restaurantFields.description, timezone: restaurantFields.timezone.default('Asia/Kolkata'), priceRange: restaurantFields.priceRange.default(2) })
  .strict();

// Partial + strict: only whitelisted fields can ever be updated (no mass assignment).
export const updateRestaurantSchema = z.object(restaurantFields).partial().strict();

export const ownerListQuery = z.object({
  restaurantId: objectId.optional(),
  status: z.string().optional(),
  date: dateStr.optional(),
  q: z.string().trim().max(80).optional(),
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(100).default(20),
});

export const analyticsQuery = z.object({
  restaurantId: objectId.optional(),
  days: z.coerce.number().int().min(7).max(180).default(30),
});

export const tableSchema = z
  .object({
    tableNumber: trimmed(20, 1),
    displayName: optionalText(60),
    capacity: z.number().int().min(1).max(40),
    shape: z.enum(TABLE_SHAPES).default('round'),
    dimensions: z.object({ width: z.number().min(0.4).max(8), depth: z.number().min(0.4).max(8), height: z.number().min(0.3).max(1.5).optional() }).optional(),
    position: z.object({ x: z.number().min(-100).max(100), y: z.number().min(-100).max(100), z: z.number().min(0).max(10).optional() }).optional(),
    rotation: z.number().min(-360).max(360).optional(),
    isActive: z.boolean().optional(),
  })
  .strict();
export const updateTableSchema = tableSchema.partial();

export const floorPlanSchema = z
  .object({
    room: z.object({ width: z.number().min(6).max(80), depth: z.number().min(6).max(80) }).optional(),
    tables: z.array(tableSchema.extend({ id: objectId.optional() })).max(120),
  })
  .strict();

export const menuItemSchema = z
  .object({
    category: trimmed(60, 1),
    name: trimmed(120, 1),
    description: optionalText(500),
    price: z.number().min(0).max(1000000),
    image: optionalText(600),
    dietaryLabels: z.array(z.enum(DIETARY_LABELS)).max(7).default([]),
    isAvailable: z.boolean().default(true),
  })
  .strict();
export const updateMenuItemSchema = menuItemSchema.partial();

export const createStaffSchema = z
  .object({
    restaurantId: objectId,
    email: z.string().trim().toLowerCase().email(),
    name: trimmed(80, 2).optional(),
    password: password.optional(), // required only when the account does not exist yet
    assignedRole: z.enum(['host', 'server', 'manager']).default('host'),
    permissions: z.array(z.enum(STAFF_PERMISSIONS)).default([...STAFF_PERMISSIONS]),
  })
  .strict();
export const updateStaffSchema = z
  .object({ assignedRole: z.enum(['host', 'server', 'manager']).optional(), permissions: z.array(z.enum(STAFF_PERMISSIONS)).optional(), isActive: z.boolean().optional() })
  .strict();

// ---------- staff ----------
export const staffQuery = z.object({
  restaurantId: objectId.optional(),
  date: dateStr.optional(),
  status: z.string().optional(),
  q: z.string().trim().max(80).optional(),
});

export const walkInSchema = z
  .object({
    restaurantId: objectId.optional(),
    guestName: trimmed(80, 1),
    phone: optionalText(30),
    guestCount: z.number().int().min(1).max(100),
    tableId: objectId,
    notes: optionalText(500),
    durationMinutes: z.number().int().min(15).max(360).optional(),
  })
  .strict();

export const tableStatusSchema = z.object({ status: z.enum(TABLE_STATUSES) }).strict();
export const reservationStatusSchema = z
  .object({ status: z.enum(['seated', 'completed', 'no_show', 'cancelled', 'confirmed']), reason: optionalText(300) })
  .strict();

// ---------- admin ----------
export const adminListQuery = z.object({
  q: z.string().trim().max(80).optional(),
  status: z.string().optional(),
  role: z.enum(['customer', 'owner', 'staff', 'admin']).optional(),
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(100).default(20),
});
export const adminStatusSchema = z.object({ status: z.enum(['active', 'rejected', 'suspended', 'pending']), note: optionalText(500) }).strict();
export const adminUserActiveSchema = z.object({ isActive: z.boolean() }).strict();
