import { Server } from 'socket.io';
import cookie from 'cookie';
import { env } from '../config/env.js';
import { COOKIE_NAME, userFromToken } from '../middleware/auth.js';
import { canAccessRestaurant } from '../services/access.js';

let io = null;

export const roomFor = (restaurantId) => `restaurant:${restaurantId}`;
export const userRoom = (userId) => `user:${userId}`;

export function initSockets(httpServer) {
  io = new Server(httpServer, {
    cors: { origin: env.CLIENT_URLS, credentials: true },
    serveClient: false,
  });

  // Authenticate every connection using the same HTTP-only cookie (or an explicit auth token).
  io.use(async (socket, next) => {
    try {
      const cookies = cookie.parse(socket.handshake.headers.cookie || '');
      const token = cookies[COOKIE_NAME] || socket.handshake.auth?.token;
      const user = await userFromToken(token);
      if (!user) return next(new Error('unauthenticated'));
      socket.data.user = user;
      next();
    } catch (e) {
      next(new Error('unauthenticated'));
    }
  });

  io.on('connection', (socket) => {
    const user = socket.data.user;
    socket.join(userRoom(user._id)); // private per-user room (own reservation updates)

    // Only owners / assigned staff / admins may join a restaurant room.
    socket.on('restaurant:join', async (restaurantId, ack) => {
      try {
        const allowed = await canAccessRestaurant(user, restaurantId);
        if (!allowed) return ack?.({ ok: false, message: 'Not allowed' });
        socket.join(roomFor(restaurantId));
        ack?.({ ok: true });
      } catch {
        ack?.({ ok: false, message: 'Not allowed' });
      }
    });
    socket.on('restaurant:leave', (restaurantId) => socket.leave(roomFor(restaurantId)));
  });
  return io;
}

/** Broadcast to a restaurant's authorised room. Payloads must never contain private customer data. */
export function emitToRestaurant(restaurantId, event, payload) {
  io?.to(roomFor(restaurantId)).emit(event, payload);
}
export function emitToUser(userId, event, payload) {
  if (userId) io?.to(userRoom(userId)).emit(event, payload);
}
export const closeSockets = () => io?.close();
