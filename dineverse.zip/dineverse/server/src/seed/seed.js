// Development-only seed. Creates FICTIONAL demo venues, menus, tables, accounts and reservations.
// Refuses to run in production. Usage: npm run seed   (add --keep to skip wiping existing data)
import bcrypt from 'bcryptjs';
import { env } from '../config/env.js';
import { connectDb, disconnectDb } from '../config/db.js';
import { User } from '../models/User.js';
import { Restaurant, defaultOpeningHours } from '../models/Restaurant.js';
import { Table } from '../models/Table.js';
import { MenuItem } from '../models/MenuItem.js';
import { Reservation } from '../models/Reservation.js';
import { StaffAssignment } from '../models/StaffAssignment.js';
import { AuditLog } from '../models/AuditLog.js';
import { Favorite } from '../models/Favorite.js';
import { buildReservationDoc } from '../services/reservations.js';
import { DAY, localParts, zonedToUtc } from '../utils/time.js';

if (env.isProd || process.env.NODE_ENV === 'production') {
  console.error('Refusing to seed: NODE_ENV=production. The seed script is for development only.');
  process.exit(1);
}

const PASSWORD = env.SEED_DEMO_PASSWORD;
const TZ = 'Asia/Kolkata';

// ---- deterministic pseudo-random so re-seeding gives the same demo data ----
let seedState = 20261024;
const rand = () => ((seedState = (seedState * 1664525 + 1013904223) % 4294967296) / 4294967296);
const pick = (arr) => arr[Math.floor(rand() * arr.length)];

/** Grid-style layouts: [x, y, capacity, shape] in metres inside a 20 x 14 room. */
function layout(kind) {
  const L = [];
  const add = (x, y, capacity, shape = 'round', rotation = 0) => L.push({ x, y, capacity, shape, rotation });
  if (kind === 'hall') {
    [3.5, 8, 12.5, 17].forEach((x, i) => [3.5, 7, 10.5].forEach((y, j) => add(x, y, (i + j) % 3 === 0 ? 4 : (i + j) % 3 === 1 ? 2 : 6, (i + j) % 2 ? 'square' : 'round')));
    add(10, 1.6, 8, 'rectangle');
  } else if (kind === 'rooftop') {
    [4, 8, 12, 16].forEach((x) => { add(x, 2.5, 2, 'round'); add(x, 11.5, 2, 'round'); });
    [5, 10, 15].forEach((x) => add(x, 7, 4, 'square', 45));
    add(10, 4.8, 6, 'rectangle'); add(10, 9.2, 6, 'rectangle');
  } else if (kind === 'chef') {
    add(10, 7, 10, 'rectangle'); // chef's counter
    [3.5, 16.5].forEach((x) => [3.5, 10.5].forEach((y) => add(x, y, 4, 'round')));
    add(3.5, 7, 2, 'round'); add(16.5, 7, 2, 'round');
  } else {
    [4, 8, 12, 16].forEach((x) => [3.5, 10.5].forEach((y, j) => add(x, y, j ? 4 : 2, j ? 'square' : 'round')));
    add(6, 7, 6, 'round'); add(14, 7, 8, 'rectangle'); add(10, 7, 4, 'round');
  }
  return L.map((t, i) => ({
    tableNumber: String(i + 1),
    displayName: `Table ${i + 1}`,
    capacity: t.capacity,
    shape: t.shape,
    dimensions: t.shape === 'rectangle' ? { width: Math.max(2, t.capacity * 0.28), depth: 1, height: 0.75 } : t.shape === 'square' ? { width: 1.1, depth: 1.1, height: 0.75 } : { width: t.capacity > 4 ? 1.7 : 1.2, depth: t.capacity > 4 ? 1.7 : 1.2, height: 0.75 },
    position: { x: t.x, y: t.y, z: 0 },
    rotation: t.rotation,
  }));
}

const VENUES = [
  {
    name: 'Saffron & Smoke', tagline: 'Wood-fired North Indian, slowly.', city: 'Mumbai', state: 'Maharashtra',
    cuisineTypes: ['North Indian', 'Contemporary'], experiences: ['Fine Dining', 'Celebrations'], price: 3, rating: [4.6, 214], kind: 'hall',
    amenities: ['Valet parking', 'Wheelchair accessible', 'Full bar', 'Live ghazal evenings'],
    description: 'A sample venue for the DineVerse demo: a tandoor-led dining room with copper-lit alcoves and an open kitchen. All details are fictional.',
    hours: ['12:00', '23:30'],
    menu: { Starters: [['Charred Paneer Tikka', 540, ['vegetarian']], ['Smoked Lamb Seekh', 720, []], ['Beetroot Galouti', 480, ['vegetarian']]], Mains: [['Dal Saffron', 460, ['vegetarian']], ['Butter Chicken, Slow Reduced', 780, []], ['Raan Biryani', 1180, ['spicy']]], Desserts: [['Kulfi Falooda', 380, ['vegetarian']], ['Jaggery Phirni', 340, ['vegetarian', 'gluten_free']]] },
  },
  {
    name: 'The Terrace at Ninety', tagline: 'Rooftop dining above the city lights.', city: 'Bengaluru', state: 'Karnataka',
    cuisineTypes: ['Modern European', 'Mediterranean'], experiences: ['Rooftop Dining', 'Romantic Evenings'], price: 3, rating: [4.4, 167], kind: 'rooftop',
    amenities: ['Open-air terrace', 'Cocktail bar', 'Heaters & fans', 'Vegetarian friendly'],
    description: 'A sample rooftop restaurant for the DineVerse demo with candle-lit tables and a skyline view. All details are fictional.',
    hours: ['17:00', '23:30'],
    menu: { Small: [['Burrata, Heirloom Tomato', 620, ['vegetarian']], ['Grilled Octopus', 880, ['gluten_free']]], Mains: [['Wild Mushroom Risotto', 740, ['vegetarian']], ['Herb-Crusted Sea Bass', 1020, []], ['Saffron Gnocchi', 690, ['vegetarian']]], Desserts: [['Olive Oil Cake', 420, ['vegetarian']], ['Dark Chocolate Torte', 460, ['vegetarian', 'contains_nuts']]] },
  },
  {
    name: 'Banyan Leaf Kitchen', tagline: 'Coastal South Indian, served on banana leaf.', city: 'Chennai', state: 'Tamil Nadu',
    cuisineTypes: ['South Indian', 'Seafood'], experiences: ['Celebrations', 'Private Dining'], price: 2, rating: [4.5, 301], kind: 'family',
    amenities: ['Private dining room', 'Family friendly', 'Vegetarian & Jain options', 'Parking'],
    description: 'A sample family-style restaurant for the DineVerse demo, known (in this fictional story) for its banana-leaf meals. All details are fictional.',
    hours: ['11:30', '22:30'],
    menu: { Starters: [['Pepper Crab Roast', 760, ['spicy']], ['Medu Vada Trio', 260, ['vegetarian']]], Mains: [['Meen Kuzhambu', 640, ['spicy']], ['Chettinad Mushroom Curry', 520, ['vegetarian']], ['Banana-Leaf Meal', 480, ['vegetarian']]], Desserts: [['Payasam Flight', 320, ['vegetarian']], ['Elaneer Pudding', 300, ['vegetarian', 'gluten_free']]] },
  },
  {
    name: 'Atelier Eleven', tagline: "A twelve-seat chef's counter and tasting menus.", city: 'New Delhi', state: 'Delhi',
    cuisineTypes: ['Tasting Menu', 'Contemporary'], experiences: ["Chef's Table", 'Fine Dining', 'Private Dining'], price: 4, rating: [4.8, 89], kind: 'chef',
    amenities: ['Sommelier pairing', 'Open kitchen counter', 'Dietary accommodations on request'],
    description: 'A sample tasting-menu venue for the DineVerse demo with a central chef\'s counter. All details are fictional.',
    hours: ['18:30', '23:00'],
    menu: { 'Tasting Menu': [['Seven-Course Tasting', 4200, []], ['Vegetarian Tasting', 3800, ['vegetarian']], ['Wine Pairing', 2600, []]] },
  },
  {
    name: 'Rani Mahal Courtyard', tagline: 'Candlelit courtyard dining in the Pink City.', city: 'Jaipur', state: 'Rajasthan',
    cuisineTypes: ['Rajasthani', 'Royal Indian'], experiences: ['Romantic Evenings', 'Private Dining', 'Celebrations'], price: 3, rating: [4.3, 126], kind: 'family',
    amenities: ['Courtyard seating', 'Folk music (weekends)', 'Heritage setting'],
    description: 'A sample heritage-courtyard restaurant for the DineVerse demo. All details are fictional.',
    hours: ['12:00', '23:00'],
    menu: { Starters: [['Laal Maas Croquette', 560, ['spicy']], ['Ker Sangri Tart', 420, ['vegetarian']]], Mains: [['Gatte ki Sabzi', 480, ['vegetarian']], ['Safed Maas', 820, []], ['Dal Baati Churma', 560, ['vegetarian']]], Desserts: [['Ghewar with Rabri', 380, ['vegetarian']]] },
  },
];

const slug = (s) => s.toLowerCase().replace(/&/g, 'and').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

async function main() {
  await connectDb();
  const keep = process.argv.includes('--keep');
  if (!keep) {
    await Promise.all([User, Restaurant, Table, MenuItem, Reservation, StaffAssignment, AuditLog, Favorite].map((m) => m.deleteMany({})));
    await Reservation.syncIndexes();
  }
  const passwordHash = await bcrypt.hash(PASSWORD, 10);
  const mkUser = (name, email, role) => User.create({ name, email, role, passwordHash, isDemo: true, emailVerified: true, phone: '+91 90000 0000' + Math.floor(rand() * 9 + 1) });

  const admin = await mkUser('Demo Admin', 'admin@dineverse.demo', 'admin');
  const owner = await mkUser('Demo Owner', 'owner@dineverse.demo', 'owner');
  const owner2 = await mkUser('Demo Owner Two', 'owner2@dineverse.demo', 'owner');
  const staff = await mkUser('Demo Host', 'staff@dineverse.demo', 'staff');
  const customers = [await mkUser('Aarav Demo', 'customer@dineverse.demo', 'customer'), await mkUser('Meera Demo', 'customer2@dineverse.demo', 'customer'), await mkUser('Kabir Demo', 'customer3@dineverse.demo', 'customer')];

  const now = new Date();
  const restaurants = [];
  for (const [i, v] of VENUES.entries()) {
    const r = await Restaurant.create({
      name: v.name, slug: slug(v.name), tagline: v.tagline, description: v.description, cuisineTypes: v.cuisineTypes, experiences: v.experiences,
      address: { line1: 'Sample address (fictional)', city: v.city, state: v.state, country: 'India' },
      contact: {}, timezone: TZ, priceRange: v.price, images: [], amenities: v.amenities,
      openingHours: defaultOpeningHours().map((h) => ({ ...h, open: v.hours[0], close: v.hours[1] })),
      reservationSettings: { durationMinutes: 90, bufferMinutes: 0, slotIntervalMinutes: 30, cancellationCutoffHours: 2 },
      policies: 'Demo policy: free cancellation up to 2 hours before your reservation. Tables are held for 15 minutes after the booking time.',
      ownerId: i === 4 ? owner2._id : owner._id, status: 'active', isDemo: true, demoRating: { value: v.rating[0], count: v.rating[1] },
    });
    restaurants.push(r);
    const tables = await Table.insertMany(layout(v.kind).map((t) => ({ ...t, restaurantId: r._id })));
    r.$locals.tables = tables;
    let order = 0;
    for (const [category, items] of Object.entries(v.menu))
      for (const [name, price, dietaryLabels] of items)
        await MenuItem.create({ restaurantId: r._id, category, name, description: 'Sample menu item (demo content).', price, dietaryLabels, sortOrder: order++ });
  }
  await StaffAssignment.create({ userId: staff._id, restaurantId: restaurants[0]._id, assignedRole: 'host' });
  await StaffAssignment.create({ userId: staff._id, restaurantId: restaurants[1]._id, assignedRole: 'host' });

  // ---- reservations: history + upcoming, conflict-free ----
  const used = new Set();
  let made = 0;
  async function book(r, startAt, status, source = 'online') {
    const tables = r.$locals.tables;
    const guests = pick([2, 2, 3, 4, 4, 5, 6]);
    const fits = tables.filter((t) => t.capacity >= guests);
    if (!fits.length) return;
    const table = pick(fits);
    const customer = source === 'walk_in' ? { name: pick(['Walk-in guest', 'Walk-in party']), phone: undefined } : pick(customers);
    const doc = buildReservationDoc({
      restaurant: r, table, startAt, guestCount: guests, customer, status, source,
      extra: { date: localParts(startAt, TZ).date, isDemo: true, specialRequests: rand() < 0.2 ? pick(['Window seat please', 'Anniversary dinner', 'Nut allergy', 'High chair needed']) : '' },
    });
    if (doc.slotKeys.some((k) => used.has(k))) return;
    doc.slotKeys.forEach((k) => used.add(k));
    if (status === 'cancelled') { doc.cancelledAt = new Date(startAt.getTime() - 5 * 3600e3); doc.blocking = false; doc.slotKeys = []; }
    if (['completed', 'no_show'].includes(status)) doc.blocking = false;
    if (status === 'completed') { doc.checkedInAt = startAt; doc.seatedAt = startAt; doc.completedAt = doc.endAt; }
    if (status === 'completed' || status === 'no_show') doc.slotKeys = [];
    await Reservation.create(doc);
    made++;
  }

  const today = localParts(now, TZ).date;
  for (const r of restaurants) {
    const open = r.openingHours[0].open;
    const slotTimes = [];
    for (let h = Number(open.slice(0, 2)) + (open.slice(3) === '30' ? 1 : 0); h <= 20; h++) slotTimes.push(`${String(h).padStart(2, '0')}:${rand() < 0.5 ? '00' : '30'}`);
    // 30 days of history
    for (let d = 30; d >= 1; d--) {
      const date = localParts(new Date(now.getTime() - d * DAY), TZ).date;
      for (let n = 0; n < 5 + Math.floor(rand() * 6); n++) {
        const roll = rand();
        await book(r, zonedToUtc(date, pick(slotTimes), TZ), roll < 0.7 ? 'completed' : roll < 0.85 ? 'cancelled' : 'no_show', rand() < 0.2 ? 'walk_in' : 'online');
      }
    }
    // next 10 days + today (future-only slots)
    for (let d = 0; d <= 10; d++) {
      const date = localParts(new Date(now.getTime() + d * DAY), TZ).date;
      for (let n = 0; n < 4 + Math.floor(rand() * 5); n++) {
        const startAt = zonedToUtc(date, pick(slotTimes), TZ);
        if (startAt.getTime() < now.getTime() + 3 * 3600e3) continue;
        await book(r, startAt, rand() < 0.08 ? 'cancelled' : 'confirmed');
      }
    }
  }
  await Favorite.create({ customerId: customers[0]._id, restaurantId: restaurants[0]._id });
  await Favorite.create({ customerId: customers[0]._id, restaurantId: restaurants[3]._id });
  await AuditLog.create({ actorId: admin._id, actorRole: 'admin', action: 'seed.completed', targetType: 'System', metadata: { note: 'Demo data created' } });

  console.log(`\nSeeded ${restaurants.length} fictional restaurants and ${made} demo reservations (today: ${today}).`);
  console.log('\nDEMO ACCOUNTS (development only):');
  for (const [role, email] of [['admin', 'admin@dineverse.demo'], ['owner', 'owner@dineverse.demo'], ['owner (pending-style 2nd)', 'owner2@dineverse.demo'], ['staff', 'staff@dineverse.demo'], ['customer', 'customer@dineverse.demo']])
    console.log(`  ${role.padEnd(26)} ${email}  /  ${PASSWORD}`);
  await disconnectDb();
}

main().catch(async (e) => {
  console.error('Seed failed:', e);
  await disconnectDb().catch(() => {});
  process.exit(1);
});
