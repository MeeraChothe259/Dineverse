import bcrypt from 'bcryptjs';
import { User } from '../models/User.js';
import { clearAuthCookie, setAuthCookie } from '../middleware/auth.js';
import { asyncHandler, conflict, created, ok, unauthorized, forbidden, badRequest } from '../utils/http.js';

const BCRYPT_ROUNDS = 12;
// Pre-computed hash so login takes similar time whether or not the email exists.
const DUMMY_HASH = bcrypt.hashSync('dineverse-dummy-password', 10);

export const register = asyncHandler(async (req, res) => {
  const { name, email, password, phone, accountType } = req.body;
  if (await User.exists({ email })) throw conflict('An account with this email already exists.', 'EMAIL_TAKEN');
  const user = await User.create({
    name,
    email,
    phone: phone || undefined,
    role: accountType, // 'customer' | 'owner' only (validated); admin can never be self-assigned
    passwordHash: await bcrypt.hash(password, BCRYPT_ROUNDS),
  });
  setAuthCookie(res, user);
  return created(res, { user }, 'Account created.');
});

export const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email }).select('+passwordHash');
  const valid = await bcrypt.compare(password, user?.passwordHash || DUMMY_HASH);
  if (!user || !valid) throw unauthorized('Incorrect email or password.', 'INVALID_CREDENTIALS');
  if (!user.isActive) throw forbidden('This account has been deactivated.', 'ACCOUNT_DISABLED');
  setAuthCookie(res, user);
  return ok(res, { user }, 'Signed in.');
});

// Logout revokes every token issued so far for this user (tokenVersion bump).
export const logout = asyncHandler(async (req, res) => {
  if (req.user) await User.updateOne({ _id: req.user._id }, { $inc: { tokenVersion: 1 } });
  clearAuthCookie(res);
  return ok(res, null, 'Signed out.');
});

export const me = asyncHandler(async (req, res) => ok(res, { user: req.user }));

export const updateMe = asyncHandler(async (req, res) => {
  const { name, phone } = req.body;
  if (name !== undefined) req.user.name = name;
  if (phone !== undefined) req.user.phone = phone || undefined;
  await req.user.save();
  return ok(res, { user: req.user }, 'Profile updated.');
});

export const changePassword = asyncHandler(async (req, res) => {
  const { currentPassword, newPassword } = req.body;
  const user = await User.findById(req.user._id).select('+passwordHash');
  if (!(await bcrypt.compare(currentPassword, user.passwordHash))) throw badRequest('Current password is incorrect.', 'INVALID_CREDENTIALS');
  user.passwordHash = await bcrypt.hash(newPassword, BCRYPT_ROUNDS);
  user.tokenVersion += 1; // sign out other sessions
  await user.save();
  setAuthCookie(res, user);
  return ok(res, null, 'Password changed.');
});

// Password recovery requires an email provider, which is not configured in v1.
export const forgotPassword = asyncHandler(async (_req, res) =>
  ok(res, { emailEnabled: false }, 'Email delivery is not enabled in this version, so reset links cannot be sent. Contact the platform administrator.')
);
