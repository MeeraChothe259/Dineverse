import mongoose from 'mongoose';
import { Restaurant } from '../models/Restaurant.js';
import { Table } from '../models/Table.js';
import { MenuItem } from '../models/MenuItem.js';
import { EXPERIENCES } from '../models/Restaurant.js';
import { asyncHandler, escapeRegex, notFound, ok, pageMeta } from '../utils/http.js';
import { getAvailability, hasAvailability, tableLayoutDto } from '../services/availability.js';

const PUBLIC_FIELDS =
  'name slug tagline description cuisineTypes experiences address contact timezone priceRange images amenities openingHours reservationSettings policies floorPlan isDemo demoRating status';

export const publicDto = (r) => ({
  id: String(r._id),
  name: r.name,
  slug: r.slug,
  tagline: r.tagline,
  description: r.description,
  cuisineTypes: r.cuisineTypes,
  experiences: r.experiences,
  address: r.address,
  contact: r.contact,
  timezone: r.timezone,
  priceRange: r.priceRange,
  images: r.images,
  amenities: r.amenities,
  openingHours: r.openingHours,
  reservationSettings: {
    durationMinutes: r.reservationSettings.durationMinutes,
    minPartySize: r.reservationSettings.minPartySize,
    maxPartySize: r.reservationSettings.maxPartySize,
    advanceBookingDays: r.reservationSettings.advanceBookingDays,
    cancellationCutoffHours: r.reservationSettings.cancellationCutoffHours,
    acceptingReservations: r.reservationSettings.acceptingReservations,
  },
  policies: r.policies,
  floorPlan: r.floorPlan,
  // Ratings are only ever shown for sample venues and are explicitly labelled as demo.
  rating: r.demoRating?.value != null ? { value: r.demoRating.value, count: r.demoRating.count, isDemo: !!r.isDemo } : null,
  isDemo: r.isDemo,
});

async function findActive(idOrSlug) {
  const q = mongoose.isValidObjectId(idOrSlug) && /^[a-f0-9]{24}$/i.test(idOrSlug) ? { _id: idOrSlug } : { slug: String(idOrSlug).toLowerCase() };
  const r = await Restaurant.findOne({ ...q, status: 'active' }).select(PUBLIC_FIELDS);
  if (!r) throw notFound('Restaurant not found.');
  return r;
}

export const listRestaurants = asyncHandler(async (req, res) => {
  const q = req.validatedQuery;
  const filter = { status: 'active' };
  const and = [];
  if (q.q) {
    const rx = new RegExp(escapeRegex(q.q), 'i');
    and.push({ $or: [{ name: rx }, { cuisineTypes: rx }, { 'address.city': rx }, { description: rx }] });
  }
  if (q.city) filter['address.city'] = new RegExp(`^${escapeRegex(q.city)}$`, 'i');
  if (q.cuisine.length) filter.cuisineTypes = { $in: q.cuisine.map((c) => new RegExp(`^${escapeRegex(c)}$`, 'i')) };
  if (q.price.length) filter.priceRange = { $in: q.price.map(Number).filter((n) => n >= 1 && n <= 4) };
  if (q.experience) filter.experiences = q.experience;
  if (q.minRating) filter['demoRating.value'] = { $gte: q.minRating };
  if (and.length) filter.$and = and;

  const sort =
    q.sort === 'rating' ? { 'demoRating.value': -1, name: 1 } : q.sort === 'price_asc' ? { priceRange: 1, name: 1 } : q.sort === 'price_desc' ? { priceRange: -1, name: 1 } : { 'demoRating.value': -1, createdAt: -1 };

  let docs = await Restaurant.find(filter).select(PUBLIC_FIELDS).sort(sort);
  // Availability filter is evaluated on live backend data (date + time + guests together).
  if (q.date && q.time) {
    const guests = q.guests || 2;
    const flags = await Promise.all(docs.map((r) => hasAvailability(r, { date: q.date, time: q.time, guests })));
    docs = docs.filter((_, i) => flags[i]);
  }
  const total = docs.length;
  const page = { page: q.page, limit: q.limit };
  const slice = docs.slice((q.page - 1) * q.limit, q.page * q.limit);
  return ok(res, slice.map(publicDto), undefined, pageMeta(page, total));
});

export const facets = asyncHandler(async (_req, res) => {
  const [cuisines, cities] = await Promise.all([
    Restaurant.distinct('cuisineTypes', { status: 'active' }),
    Restaurant.distinct('address.city', { status: 'active' }),
  ]);
  return ok(res, { cuisines: cuisines.sort(), cities: cities.filter(Boolean).sort(), experiences: EXPERIENCES });
});

export const getRestaurant = asyncHandler(async (req, res) => {
  const r = await findActive(req.params.slug);
  const tables = await Table.find({ restaurantId: r._id, isActive: true }).select('capacity').lean();
  const caps = tables.map((t) => t.capacity);
  return ok(res, { ...publicDto(r), tableCount: tables.length, seating: caps.length ? { min: Math.min(...caps), max: Math.max(...caps) } : null });
});

export const getAvailabilityHandler = asyncHandler(async (req, res) => {
  const r = await findActive(req.params.id);
  const { date, time, guests } = req.validatedQuery;
  const data = await getAvailability(r, { date, time, guests });
  return ok(res, {
    restaurant: { id: String(r._id), name: r.name, slug: r.slug, timezone: r.timezone, floorPlan: r.floorPlan, durationMinutes: r.reservationSettings.durationMinutes },
    ...data,
  });
});

export const getTables = asyncHandler(async (req, res) => {
  const r = await findActive(req.params.id);
  const tables = await Table.find({ restaurantId: r._id, isActive: true }).sort({ tableNumber: 1 }).lean();
  return ok(res, { floorPlan: r.floorPlan, tables: tables.map(tableLayoutDto) });
});

export const getMenu = asyncHandler(async (req, res) => {
  const r = await findActive(req.params.id);
  const items = await MenuItem.find({ restaurantId: r._id }).sort({ category: 1, sortOrder: 1, name: 1 }).lean();
  return ok(res, items.map((i) => ({ id: String(i._id), category: i.category, name: i.name, description: i.description, price: i.price, image: i.image, dietaryLabels: i.dietaryLabels, isAvailable: i.isAvailable })));
});
