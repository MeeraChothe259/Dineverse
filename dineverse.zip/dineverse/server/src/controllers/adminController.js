import { AuditLog } from '../models/AuditLog.js';
import { Reservation } from '../models/Reservation.js';
import { Restaurant } from '../models/Restaurant.js';
import { User } from '../models/User.js';
import { asyncHandler, badRequest, escapeRegex, notFound, ok, pageMeta } from '../utils/http.js';
import { audit } from '../services/audit.js';
import { serializeReservation } from '../services/reservations.js';
import { DAY } from '../utils/time.js';

export const dashboard = asyncHandler(async (_req, res) => {
  const now = new Date();
  const since = new Date(now.getTime() - 30 * DAY);
  const [customers, owners, staff, restaurantsByStatus, reservations30, upcoming, recent] = await Promise.all([
    User.countDocuments({ role: 'customer' }),
    User.countDocuments({ role: 'owner' }),
    User.countDocuments({ role: 'staff' }),
    Restaurant.aggregate([{ $group: { _id: '$status', n: { $sum: 1 } } }]),
    Reservation.countDocuments({ createdAt: { $gte: since } }),
    Reservation.countDocuments({ startAt: { $gte: now }, status: { $in: ['pending', 'confirmed'] } }),
    AuditLog.find().sort({ timestamp: -1 }).limit(10).populate('actorId', 'name role').lean(),
  ]);
  const byStatus = Object.fromEntries(restaurantsByStatus.map((s) => [s._id, s.n]));
  return ok(res, {
    users: { customers, owners, staff },
    restaurants: { total: Object.values(byStatus).reduce((a, b) => a + b, 0), ...byStatus },
    reservations: { last30Days: reservations30, upcoming },
    recentActivity: recent.map((a) => ({ id: String(a._id), action: a.action, targetType: a.targetType, actor: a.actorId ? { name: a.actorId.name, role: a.actorId.role } : null, timestamp: a.timestamp })),
  });
});

export const listRestaurants = asyncHandler(async (req, res) => {
  const { q, status, page, limit } = req.validatedQuery;
  const filter = {};
  if (status) filter.status = { $in: status.split(',') };
  if (q) filter.$or = [{ name: new RegExp(escapeRegex(q), 'i') }, { 'address.city': new RegExp(escapeRegex(q), 'i') }];
  const [total, docs] = await Promise.all([
    Restaurant.countDocuments(filter),
    Restaurant.find(filter).sort({ createdAt: -1 }).skip((page - 1) * limit).limit(limit).populate('ownerId', 'name email'),
  ]);
  return ok(res, docs.map((r) => ({
    id: String(r._id), name: r.name, slug: r.slug, status: r.status, statusNote: r.statusNote, city: r.address?.city,
    cuisineTypes: r.cuisineTypes, isDemo: r.isDemo, createdAt: r.createdAt,
    owner: r.ownerId ? { id: String(r.ownerId._id), name: r.ownerId.name, email: r.ownerId.email } : null,
  })), undefined, pageMeta({ page, limit }, total));
});

export const setRestaurantStatus = asyncHandler(async (req, res) => {
  const r = await Restaurant.findById(req.params.id);
  if (!r) throw notFound('Restaurant not found.');
  const { status, note } = req.body;
  if (r.status === status) throw badRequest(`Restaurant is already ${status}.`, 'NO_CHANGE');
  const from = r.status;
  r.status = status;
  r.statusNote = note || undefined;
  await r.save();
  await audit(req.user, `restaurant.${status}`, 'Restaurant', r._id, { restaurantId: r._id, metadata: { from, to: status, note } });
  return ok(res, { id: String(r._id), status: r.status }, `Restaurant ${status}.`);
});

export const listUsers = asyncHandler(async (req, res) => {
  const { q, role, page, limit } = req.validatedQuery;
  const filter = { role: role || { $in: ['customer', 'owner', 'staff'] } };
  if (q) filter.$or = [{ name: new RegExp(escapeRegex(q), 'i') }, { email: new RegExp(escapeRegex(q), 'i') }];
  const [total, docs] = await Promise.all([User.countDocuments(filter), User.find(filter).sort({ createdAt: -1 }).skip((page - 1) * limit).limit(limit)]);
  return ok(res, docs, undefined, pageMeta({ page, limit }, total));
});

export const setUserActive = asyncHandler(async (req, res) => {
  const u = await User.findById(req.params.id);
  if (!u) throw notFound('User not found.');
  if (String(u._id) === String(req.user._id) || u.role === 'admin') throw badRequest('Admin accounts cannot be changed here.', 'FORBIDDEN_TARGET');
  u.isActive = req.body.isActive;
  if (!u.isActive) u.tokenVersion += 1; // kill existing sessions immediately
  await u.save();
  await audit(req.user, u.isActive ? 'user.reactivated' : 'user.deactivated', 'User', u._id, { metadata: { role: u.role } });
  return ok(res, u, u.isActive ? 'User reactivated.' : 'User deactivated.');
});

export const listReservations = asyncHandler(async (req, res) => {
  const { q, status, page, limit } = req.validatedQuery;
  const filter = {};
  if (status) filter.status = { $in: status.split(',') };
  if (q) filter.$or = [{ bookingReference: new RegExp(escapeRegex(q), 'i') }, { customerName: new RegExp(escapeRegex(q), 'i') }];
  const [total, docs] = await Promise.all([
    Reservation.countDocuments(filter),
    Reservation.find(filter).sort({ startAt: -1 }).skip((page - 1) * limit).limit(limit)
      .populate('restaurantId', 'name slug images timezone address isDemo').populate('tableId', 'tableNumber displayName capacity'),
  ]);
  return ok(res, docs.map((d) => serializeReservation(d, { management: true })), undefined, pageMeta({ page, limit }, total));
});

export const listAudit = asyncHandler(async (req, res) => {
  const { page, limit } = req.validatedQuery;
  const [total, docs] = await Promise.all([
    AuditLog.countDocuments(),
    AuditLog.find().sort({ timestamp: -1 }).skip((page - 1) * limit).limit(limit).populate('actorId', 'name email role').lean(),
  ]);
  return ok(res, docs.map((a) => ({ id: String(a._id), action: a.action, targetType: a.targetType, targetId: a.targetId, metadata: a.metadata, timestamp: a.timestamp, actor: a.actorId ? { name: a.actorId.name, email: a.actorId.email, role: a.actorId.role } : null })), undefined, pageMeta({ page, limit }, total));
});
