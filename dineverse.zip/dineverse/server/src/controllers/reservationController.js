import QRCode from 'qrcode';
import { Reservation } from '../models/Reservation.js';
import { Restaurant } from '../models/Restaurant.js';
import { asyncHandler, badRequest, conflict, created, forbidden, notFound, ok, pageMeta } from '../utils/http.js';
import { canCancel } from '../utils/reservationRules.js';
import { createOnlineReservation, serializeReservation, transitionReservation } from '../services/reservations.js';
import { canAccessRestaurant } from '../services/access.js';
import { audit } from '../services/audit.js';
import { makeQrToken, qrPayload } from '../utils/qr.js';

const POPULATE = [
  { path: 'restaurantId', select: 'name slug images timezone address isDemo reservationSettings' },
  { path: 'tableId', select: 'tableNumber displayName capacity' },
];

const dto = (r, opts) => serializeReservation(r, { ...opts, canCancel: canCancel(r, r.restaurantId) });

export const create = asyncHandler(async (req, res) => {
  if (req.user.role !== 'customer') throw forbidden('Only guest accounts can book online. Please sign in with a guest account.', 'GUEST_ONLY');
  const restaurant = await Restaurant.findById(req.body.restaurantId);
  if (!restaurant || restaurant.status !== 'active') throw notFound('Restaurant not found.');
  const r = await createOnlineReservation({ restaurant, user: req.user, ...req.body });
  await r.populate(POPULATE);
  return created(res, { ...dto(r), qrDataUrl: await qrImage(r) }, 'Reservation confirmed. (Email confirmations are not enabled in this version.)');
});

const qrImage = (r) =>
  r.status === 'confirmed'
    ? QRCode.toDataURL(qrPayload(makeQrToken(r._id)), { margin: 1, width: 320, color: { dark: '#0B0B0C', light: '#F5F1E9' } })
    : null;

export const listMine = asyncHandler(async (req, res) => {
  const { group, page, limit } = req.validatedQuery;
  const now = new Date();
  const filter = { customerId: req.user._id };
  if (group === 'upcoming') Object.assign(filter, { status: { $in: ['pending', 'confirmed', 'checked_in', 'seated'] }, endAt: { $gte: now } });
  if (group === 'past') Object.assign(filter, { status: { $in: ['completed', 'no_show', 'checked_in', 'seated', 'confirmed', 'pending'] }, endAt: { $lt: now } });
  if (group === 'cancelled') filter.status = 'cancelled';
  const sort = group === 'upcoming' ? { startAt: 1 } : { startAt: -1 };
  const [total, docs] = await Promise.all([
    Reservation.countDocuments(filter),
    Reservation.find(filter).sort(sort).skip((page - 1) * limit).limit(limit).populate(POPULATE),
  ]);
  return ok(res, docs.map((d) => dto(d)), undefined, pageMeta({ page, limit }, total));
});

async function loadForViewer(req) {
  const r = await Reservation.findById(req.params.id).populate(POPULATE);
  if (!r) throw notFound('Reservation not found.');
  const own = r.customerId && String(r.customerId) === String(req.user._id);
  const managed = !own && (await canAccessRestaurant(req.user, r.restaurantId._id));
  if (!own && !managed) throw notFound('Reservation not found.'); // do not reveal existence
  return { r, own, managed };
}

export const getOne = asyncHandler(async (req, res) => {
  const { r, own, managed } = await loadForViewer(req);
  const data = dto(r, { management: managed });
  if (own) data.qrDataUrl = await qrImage(r);
  return ok(res, data);
});

export const cancel = asyncHandler(async (req, res) => {
  const { r, own, managed } = await loadForViewer(req);
  if (own && !canCancel(r, r.restaurantId)) {
    const cutoff = r.restaurantId.reservationSettings?.cancellationCutoffHours ?? 2;
    throw conflict(
      ['pending', 'confirmed'].includes(r.status)
        ? `Reservations can only be cancelled at least ${cutoff} hour(s) before the start time. Please contact the restaurant.`
        : `A ${r.status.replace('_', ' ')} reservation cannot be cancelled.`,
      'CANCELLATION_NOT_ALLOWED'
    );
  }
  if (!own && !['pending', 'confirmed', 'checked_in'].includes(r.status)) throw badRequest('This reservation can no longer be cancelled.', 'CANCELLATION_NOT_ALLOWED');
  const updated = await transitionReservation(r, 'cancelled', req.user, { reason: req.body.reason });
  if (managed) await audit(req.user, 'reservation.cancelled', 'Reservation', r._id, { restaurantId: r.restaurantId._id, metadata: { reference: r.bookingReference, reason: req.body.reason } });
  await updated.populate(POPULATE);
  return ok(res, dto(updated, { management: managed }), 'Reservation cancelled.');
});
