import { asyncHandler, ok } from '../utils/http.js';
import { confirmCheckin, verifyCheckin } from '../services/checkin.js';
import { audit } from '../services/audit.js';

export const verify = asyncHandler(async (req, res) => {
  const { token, reference } = req.body;
  return ok(res, await verifyCheckin(req.user, { token, reference }));
});

export const confirm = asyncHandler(async (req, res) => {
  const { token, reference } = req.body;
  const result = await confirmCheckin(req.user, { token, reference });
  await audit(req.user, 'guest.checked_in', 'Reservation', result.reservation.id, {
    restaurantId: result.reservation.restaurantId,
    metadata: { reference: result.reservation.bookingReference, via: token ? 'qr' : 'reference' },
  });
  return ok(res, result, 'Guest checked in.');
});
