import { Favorite } from '../models/Favorite.js';
import { Restaurant } from '../models/Restaurant.js';
import { asyncHandler, badRequest, notFound, ok } from '../utils/http.js';
import { publicDto } from './restaurantController.js';

export const list = asyncHandler(async (req, res) => {
  const favs = await Favorite.find({ customerId: req.user._id }).sort({ createdAt: -1 }).populate({ path: 'restaurantId' });
  const items = favs.filter((f) => f.restaurantId && f.restaurantId.status === 'active').map((f) => publicDto(f.restaurantId));
  return ok(res, items);
});

export const ids = asyncHandler(async (req, res) => {
  const favs = await Favorite.find({ customerId: req.user._id }).select('restaurantId').lean();
  return ok(res, favs.map((f) => String(f.restaurantId)));
});

export const add = asyncHandler(async (req, res) => {
  if (!/^[a-f0-9]{24}$/i.test(req.params.restaurantId)) throw badRequest('Invalid restaurant id.', 'INVALID_ID');
  if (!(await Restaurant.exists({ _id: req.params.restaurantId, status: 'active' }))) throw notFound('Restaurant not found.');
  await Favorite.updateOne({ customerId: req.user._id, restaurantId: req.params.restaurantId }, { $setOnInsert: {} }, { upsert: true });
  return ok(res, { favorited: true }, 'Added to favorites.');
});

export const remove = asyncHandler(async (req, res) => {
  await Favorite.deleteOne({ customerId: req.user._id, restaurantId: req.params.restaurantId });
  return ok(res, { favorited: false }, 'Removed from favorites.');
});
