import { Reservation } from '../models/Reservation.js';
import { StaffAssignment } from '../models/StaffAssignment.js';
import { Table } from '../models/Table.js';
import { asyncHandler, badRequest, conflict, created, escapeRegex, notFound, ok } from '../utils/http.js';
import { accessibleRestaurantIds, assertRestaurantAccess, resolveWorkplace } from '../services/access.js';
import { audit } from '../services/audit.js';
import { createWalkIn, serializeReservation, transitionReservation } from '../services/reservations.js';
import { dayRange, staffDashboard, liveTableStatus } from '../services/operations.js';
import { Restaurant } from '../models/Restaurant.js';
import { emitToRestaurant } from '../sockets/index.js';

const POPULATE = [{ path: 'tableId', select: 'tableNumber displayName capacity' }];

export const me = asyncHandler(async (req, res) => {
  const ids = await accessibleRestaurantIds(req.user);
  const restaurants = await Restaurant.find({ _id: { $in: ids } }).select('name slug timezone isDemo status');
  const assignments = req.user.role === 'staff' ? await StaffAssignment.find({ userId: req.user._id, isActive: true }).lean() : [];
  return ok(res, {
    restaurants: restaurants.map((r) => ({
      id: String(r._id), name: r.name, slug: r.slug, timezone: r.timezone, isDemo: r.isDemo,
      permissions: assignments.find((a) => String(a.restaurantId) === String(r._id))?.permissions || ['reservations', 'checkin', 'walkin', 'tables'],
    })),
  });
});

export const dashboard = asyncHandler(async (req, res) => {
  const r = await resolveWorkplace(req.user, req.validatedQuery.restaurantId, 'reservations');
  return ok(res, { restaurant: { id: String(r._id), name: r.name, timezone: r.timezone }, ...(await staffDashboard(r)) });
});

export const listReservations = asyncHandler(async (req, res) => {
  const { restaurantId, date, status, q } = req.validatedQuery;
  const r = await resolveWorkplace(req.user, restaurantId, 'reservations');
  const { date: d, start, end } = dayRange(r, new Date(), date);
  const filter = { restaurantId: r._id, startAt: { $gte: start, $lt: end } };
  if (status) filter.status = { $in: status.split(',') };
  if (q) {
    const rx = new RegExp(escapeRegex(q), 'i');
    filter.$or = [{ bookingReference: rx }, { customerName: rx }];
  }
  const docs = await Reservation.find(filter).sort({ startAt: 1 }).populate(POPULATE);
  return ok(res, { date: d, reservations: docs.map((x) => serializeReservation(x, { management: true })) });
});

export const walkIn = asyncHandler(async (req, res) => {
  const { restaurantId, guestName, phone, guestCount, tableId, notes, durationMinutes } = req.body;
  const r = await resolveWorkplace(req.user, restaurantId, 'walkin');
  const reservation = await createWalkIn({ restaurant: r, staff: req.user, tableId, guestName, phone, guestCount, notes, durationMinutes });
  await audit(req.user, 'walkin.created', 'Reservation', reservation._id, { restaurantId: r._id, metadata: { guestCount, tableId } });
  await reservation.populate(POPULATE);
  return created(res, serializeReservation(reservation, { management: true }), 'Walk-in seated.');
});

export const updateTableStatus = asyncHandler(async (req, res) => {
  const table = await Table.findById(req.params.tableId);
  if (!table) throw notFound('Table not found.');
  await assertRestaurantAccess(req.user, table.restaurantId, 'tables');
  const { status } = req.body;
  if (status === 'available') {
    const live = await Reservation.exists({ tableId: table._id, status: { $in: ['seated', 'checked_in'] } });
    if (live) throw conflict('A party is currently seated at this table. Complete their reservation first.', 'TABLE_IN_USE');
  }
  table.status = status;
  await table.save();
  await audit(req.user, 'table.status', 'Table', table._id, { restaurantId: table.restaurantId, metadata: { status } });
  emitToRestaurant(table.restaurantId, 'table:status', { tableId: String(table._id), status });
  return ok(res, { id: String(table._id), status }, 'Table status updated.');
});

// Moves a reservation through its lifecycle (seated, completed, no-show, cancelled).
export const updateReservationStatus = asyncHandler(async (req, res) => {
  const r = await Reservation.findById(req.params.id);
  if (!r) throw notFound('Reservation not found.');
  await assertRestaurantAccess(req.user, r.restaurantId, 'reservations');
  const { status, reason } = req.body;
  if (status === 'confirmed' && r.status !== 'pending') throw badRequest('Only pending reservations can be confirmed.', 'INVALID_TRANSITION');
  const updated = await transitionReservation(r, status, req.user, { reason });
  await audit(req.user, `reservation.${status}`, 'Reservation', r._id, { restaurantId: r.restaurantId, metadata: { from: r.status, reference: r.bookingReference } });
  await updated.populate(POPULATE);
  return ok(res, serializeReservation(updated, { management: true }), 'Reservation updated.');
});

export { liveTableStatus };
