import bcrypt from 'bcryptjs';
import { Restaurant, defaultOpeningHours } from '../models/Restaurant.js';
import { Table } from '../models/Table.js';
import { MenuItem } from '../models/MenuItem.js';
import { Reservation } from '../models/Reservation.js';
import { StaffAssignment } from '../models/StaffAssignment.js';
import { User } from '../models/User.js';
import { asyncHandler, conflict, created, escapeRegex, notFound, ok, pageMeta, slugify, badRequest, forbidden } from '../utils/http.js';
import { accessibleRestaurantIds, assertRestaurantAccess } from '../services/access.js';
import { audit } from '../services/audit.js';
import { serializeReservation } from '../services/reservations.js';
import { canCancel } from '../utils/reservationRules.js';
import { buildAnalytics } from '../utils/analytics.js';
import { DAY } from '../utils/time.js';
import { tableLayoutDto } from '../services/availability.js';

const ownerDto = (r) => ({ ...r.toObject(), id: String(r._id), _id: undefined, __v: undefined });

async function uniqueSlug(name) {
  const base = slugify(name) || 'restaurant';
  let slug = base;
  for (let i = 2; await Restaurant.exists({ slug }); i++) slug = `${base}-${i}`;
  return slug;
}

// ---------- restaurants ----------
export const listRestaurants = asyncHandler(async (req, res) => {
  const filter = req.user.role === 'admin' ? {} : { ownerId: req.user._id };
  const list = await Restaurant.find(filter).sort({ createdAt: -1 });
  const counts = await Table.aggregate([{ $match: { restaurantId: { $in: list.map((r) => r._id) }, isActive: true } }, { $group: { _id: '$restaurantId', n: { $sum: 1 } } }]);
  const byId = Object.fromEntries(counts.map((c) => [String(c._id), c.n]));
  return ok(res, list.map((r) => ({ ...ownerDto(r), tableCount: byId[String(r._id)] || 0 })));
});

export const createRestaurant = asyncHandler(async (req, res) => {
  if (req.user.role !== 'owner') throw forbidden('Only restaurant owner accounts can submit a restaurant.');
  const b = req.body;
  const r = await Restaurant.create({
    ...b,
    slug: await uniqueSlug(b.name),
    ownerId: req.user._id,
    status: 'pending', // owners submit an application; a platform admin must approve it
    openingHours: defaultOpeningHours(),
  });
  await audit(req.user, 'restaurant.submitted', 'Restaurant', r._id, { restaurantId: r._id, metadata: { name: r.name } });
  return created(res, ownerDto(r), 'Application submitted. A platform administrator will review it.');
});

export const getRestaurant = asyncHandler(async (req, res) => {
  const r = await assertRestaurantAccess(req.user, req.params.id);
  if (req.user.role === 'staff') throw forbidden();
  return ok(res, ownerDto(r));
});

export const updateRestaurant = asyncHandler(async (req, res) => {
  const r = await assertRestaurantAccess(req.user, req.params.id);
  const b = req.body;
  if (b.reservationSettings && b.reservationSettings.minPartySize > b.reservationSettings.maxPartySize)
    throw badRequest('Minimum party size cannot exceed the maximum.', 'VALIDATION_ERROR');
  for (const [k, v] of Object.entries(b)) r.set(k, v); // keys are whitelisted by updateRestaurantSchema
  await r.save();
  await audit(req.user, 'restaurant.updated', 'Restaurant', r._id, { restaurantId: r._id, metadata: { fields: Object.keys(b) } });
  return ok(res, ownerDto(r), 'Restaurant updated.');
});

// ---------- reservations ----------
export const listReservations = asyncHandler(async (req, res) => {
  const { restaurantId, status, date, q, page, limit } = req.validatedQuery;
  let ids = await accessibleRestaurantIds(req.user);
  if (restaurantId) {
    await assertRestaurantAccess(req.user, restaurantId);
    ids = [restaurantId];
  }
  const filter = { restaurantId: { $in: ids } };
  if (status) filter.status = { $in: status.split(',') };
  if (date) filter.date = date;
  if (q) {
    const rx = new RegExp(escapeRegex(q), 'i');
    filter.$or = [{ bookingReference: rx }, { customerName: rx }, { customerEmail: rx }];
  }
  const [total, docs] = await Promise.all([
    Reservation.countDocuments(filter),
    Reservation.find(filter).sort({ startAt: -1 }).skip((page - 1) * limit).limit(limit)
      .populate('tableId', 'tableNumber displayName capacity').populate('restaurantId', 'name slug images timezone address isDemo reservationSettings'),
  ]);
  return ok(res, docs.map((d) => serializeReservation(d, { management: true, canCancel: canCancel(d, d.restaurantId) })), undefined, pageMeta({ page, limit }, total));
});

// ---------- dashboard & analytics ----------
async function analyticsFor(user, restaurantId, days) {
  let ids = await accessibleRestaurantIds(user);
  if (restaurantId) {
    await assertRestaurantAccess(user, restaurantId);
    ids = [restaurantId];
  }
  const now = new Date();
  const from = new Date(now.getTime() - days * DAY);
  const to = new Date(now.getTime() + 14 * DAY);
  const [restaurants, tables, reservations] = await Promise.all([
    Restaurant.find({ _id: { $in: ids } }).select('timezone openingHours isDemo name').lean(),
    Table.find({ restaurantId: { $in: ids } }).select('isActive').lean(),
    Reservation.find({ restaurantId: { $in: ids }, startAt: { $gte: from, $lt: to } }).select('restaurantId status source guestCount date startAt endAt').lean(),
  ]);
  return buildAnalytics({ reservations, restaurants, tables, from, to, now });
}

export const analytics = asyncHandler(async (req, res) => {
  const { restaurantId, days } = req.validatedQuery;
  return ok(res, await analyticsFor(req.user, restaurantId, days));
});

export const dashboard = asyncHandler(async (req, res) => {
  const restaurants = await Restaurant.find(req.user.role === 'admin' ? {} : { ownerId: req.user._id }).select('name slug status isDemo');
  const a = await analyticsFor(req.user, undefined, 30);
  const upcoming = await Reservation.find({ restaurantId: { $in: restaurants.map((r) => r._id) }, status: { $in: ['confirmed', 'pending'] }, startAt: { $gte: new Date() } })
    .sort({ startAt: 1 }).limit(8)
    .populate('tableId', 'tableNumber displayName capacity').populate('restaurantId', 'name slug images timezone address isDemo reservationSettings');
  return ok(res, {
    restaurants: restaurants.map((r) => ({ id: String(r._id), name: r.name, slug: r.slug, status: r.status, isDemo: r.isDemo })),
    analytics: a,
    upcoming: upcoming.map((d) => serializeReservation(d, { management: true })),
  });
});

// ---------- tables & floor plan ----------
const tableFields = (b) => {
  const out = { ...b };
  if (out.displayName === '') delete out.displayName;
  return out;
};

export const createTable = asyncHandler(async (req, res) => {
  const r = await assertRestaurantAccess(req.user, req.params.id);
  try {
    const t = await Table.create({ ...tableFields(req.body), restaurantId: r._id });
    await audit(req.user, 'table.created', 'Table', t._id, { restaurantId: r._id });
    return created(res, tableLayoutDto(t), 'Table added.');
  } catch (e) {
    if (e.code === 11000) throw conflict('A table with that number already exists.', 'DUPLICATE_TABLE');
    throw e;
  }
});

async function loadTable(req) {
  const t = await Table.findById(req.params.tableId);
  if (!t) throw notFound('Table not found.');
  await assertRestaurantAccess(req.user, t.restaurantId);
  return t;
}

export const updateTable = asyncHandler(async (req, res) => {
  const t = await loadTable(req);
  for (const [k, v] of Object.entries(tableFields(req.body))) t.set(k, v);
  try {
    await t.save();
  } catch (e) {
    if (e.code === 11000) throw conflict('A table with that number already exists.', 'DUPLICATE_TABLE');
    throw e;
  }
  await audit(req.user, 'table.updated', 'Table', t._id, { restaurantId: t.restaurantId, metadata: { fields: Object.keys(req.body) } });
  return ok(res, tableLayoutDto(t), 'Table updated.');
});

// DELETE deactivates (soft delete) so reservation history keeps its table reference.
export const deleteTable = asyncHandler(async (req, res) => {
  const t = await loadTable(req);
  const future = await Reservation.countDocuments({ tableId: t._id, blocking: true, endAt: { $gte: new Date() } });
  if (future > 0) throw conflict(`This table has ${future} upcoming reservation(s). Cancel or move them first.`, 'TABLE_IN_USE');
  t.isActive = false;
  await t.save();
  await audit(req.user, 'table.deactivated', 'Table', t._id, { restaurantId: t.restaurantId });
  return ok(res, null, 'Table removed from the floor plan.');
});

export const listTables = asyncHandler(async (req, res) => {
  const r = await assertRestaurantAccess(req.user, req.params.id);
  const tables = await Table.find({ restaurantId: r._id }).sort({ tableNumber: 1 });
  return ok(res, { floorPlan: r.floorPlan, tables: tables.map((t) => ({ ...tableLayoutDto(t), status: t.status })) });
});

export const getFloorPlan = listTables;

export const putFloorPlan = asyncHandler(async (req, res) => {
  const r = await assertRestaurantAccess(req.user, req.params.id);
  const { room, tables } = req.body;
  const numbers = tables.map((t) => t.tableNumber);
  if (new Set(numbers).size !== numbers.length) throw badRequest('Table numbers must be unique.', 'DUPLICATE_TABLE');
  const existing = await Table.find({ restaurantId: r._id });
  const byId = new Map(existing.map((t) => [String(t._id), t]));
  const keep = new Set();

  // Note: swapping two existing table numbers within one save can trip the unique index (409); rename via an interim number.
  for (const t of tables) {
    if (t.id) {
      const doc = byId.get(t.id);
      if (!doc) throw badRequest('A table in the plan does not belong to this restaurant.', 'INVALID_TABLE');
      keep.add(t.id);
    }
  }
  for (const t of tables) {
    const { id, ...fields } = tableFields(t);
    if (id) {
      const doc = byId.get(id);
      doc.set({ ...fields, isActive: fields.isActive ?? true });
      await doc.save();
    } else {
      const doc = await Table.create({ ...fields, restaurantId: r._id });
      keep.add(String(doc._id));
    }
  }
  const removed = existing.filter((t) => t.isActive && !keep.has(String(t._id)));
  for (const t of removed) {
    if (await Reservation.exists({ tableId: t._id, blocking: true, endAt: { $gte: new Date() } }))
      throw conflict(`Table ${t.tableNumber} has upcoming reservations and cannot be removed.`, 'TABLE_IN_USE');
    t.isActive = false;
    await t.save();
  }
  if (room) {
    r.floorPlan = room;
    await r.save();
  }
  await audit(req.user, 'floorplan.saved', 'Restaurant', r._id, { restaurantId: r._id, metadata: { tables: tables.length } });
  const fresh = await Table.find({ restaurantId: r._id, isActive: true }).sort({ tableNumber: 1 });
  return ok(res, { floorPlan: r.floorPlan, tables: fresh.map(tableLayoutDto) }, 'Floor plan saved.');
});

// ---------- menu ----------
export const listMenu = asyncHandler(async (req, res) => {
  const r = await assertRestaurantAccess(req.user, req.params.id);
  return ok(res, await MenuItem.find({ restaurantId: r._id }).sort({ category: 1, sortOrder: 1, name: 1 }));
});
export const createMenuItem = asyncHandler(async (req, res) => {
  const r = await assertRestaurantAccess(req.user, req.params.id);
  const item = await MenuItem.create({ ...req.body, image: req.body.image || undefined, restaurantId: r._id });
  return created(res, item, 'Menu item added.');
});
async function loadItem(req) {
  const item = await MenuItem.findById(req.params.itemId);
  if (!item) throw notFound('Menu item not found.');
  await assertRestaurantAccess(req.user, item.restaurantId);
  return item;
}
export const updateMenuItem = asyncHandler(async (req, res) => {
  const item = await loadItem(req);
  item.set(req.body);
  await item.save();
  return ok(res, item, 'Menu item updated.');
});
export const deleteMenuItem = asyncHandler(async (req, res) => {
  const item = await loadItem(req);
  await item.deleteOne();
  return ok(res, null, 'Menu item deleted.');
});

// ---------- staff ----------
export const listStaff = asyncHandler(async (req, res) => {
  const ids = await accessibleRestaurantIds(req.user);
  const rows = await StaffAssignment.find({ restaurantId: { $in: ids } }).populate('userId', 'name email phone isActive').populate('restaurantId', 'name');
  return ok(res, rows.filter((a) => a.userId && a.restaurantId).map((a) => ({
    id: String(a._id),
    user: { id: String(a.userId._id), name: a.userId.name, email: a.userId.email },
    restaurant: { id: String(a.restaurantId._id), name: a.restaurantId.name },
    assignedRole: a.assignedRole,
    permissions: a.permissions,
    isActive: a.isActive,
  })));
});

export const createStaff = asyncHandler(async (req, res) => {
  const { restaurantId, email, name, password, assignedRole, permissions } = req.body;
  const r = await assertRestaurantAccess(req.user, restaurantId);
  let user = await User.findOne({ email });
  if (user) {
    if (user.role !== 'staff') throw conflict('That email belongs to a non-staff account and cannot be assigned.', 'NOT_STAFF');
  } else {
    if (!name || !password) throw badRequest('Name and a temporary password are required to create a new staff account.', 'VALIDATION_ERROR');
    user = await User.create({ name, email, role: 'staff', passwordHash: await bcrypt.hash(password, 12) });
  }
  try {
    const a = await StaffAssignment.create({ userId: user._id, restaurantId: r._id, assignedRole, permissions });
    await audit(req.user, 'staff.assigned', 'StaffAssignment', a._id, { restaurantId: r._id, metadata: { staffId: String(user._id), assignedRole, permissions } });
    return created(res, { id: String(a._id) }, 'Staff member assigned.');
  } catch (e) {
    if (e.code === 11000) throw conflict('That person is already assigned to this restaurant.', 'DUPLICATE');
    throw e;
  }
});

export const updateStaff = asyncHandler(async (req, res) => {
  const a = await StaffAssignment.findById(req.params.id);
  if (!a) throw notFound('Assignment not found.');
  await assertRestaurantAccess(req.user, a.restaurantId);
  a.set(req.body);
  await a.save();
  await audit(req.user, 'staff.updated', 'StaffAssignment', a._id, { restaurantId: a.restaurantId, metadata: req.body });
  return ok(res, { id: String(a._id), isActive: a.isActive, permissions: a.permissions, assignedRole: a.assignedRole }, 'Staff updated.');
});
