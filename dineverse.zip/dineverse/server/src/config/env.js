import 'dotenv/config';

const NODE_ENV = process.env.NODE_ENV || 'development';
const isProd = NODE_ENV === 'production';

const DEV_JWT = 'dev-only-jwt-secret-do-not-use-in-production';
const DEV_QR = 'dev-only-qr-secret-do-not-use-in-production';

export const env = {
  NODE_ENV,
  isProd,
  isTest: NODE_ENV === 'test',
  PORT: Number(process.env.PORT || 5000),
  MONGODB_URI: process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/dineverse',
  CLIENT_URLS: (process.env.CLIENT_URL || 'http://localhost:5173')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean),
  COOKIE_SAMESITE: process.env.COOKIE_SAMESITE || (isProd ? 'none' : 'lax'),
  JWT_SECRET: process.env.JWT_SECRET || DEV_JWT,
  JWT_EXPIRES_IN: process.env.JWT_EXPIRES_IN || '7d',
  COOKIE_MAX_AGE_DAYS: Number(process.env.COOKIE_MAX_AGE_DAYS || 7),
  QR_SECRET: process.env.QR_SECRET || DEV_QR,
  SEED_DEMO_PASSWORD: process.env.SEED_DEMO_PASSWORD || 'Demo@12345',
};

if (isProd) {
  if (env.JWT_SECRET === DEV_JWT || env.JWT_SECRET.length < 32) {
    throw new Error('JWT_SECRET must be set to a strong value (>= 32 chars) in production.');
  }
  if (env.QR_SECRET === DEV_QR || env.QR_SECRET.length < 32) {
    throw new Error('QR_SECRET must be set to a strong value (>= 32 chars) in production.');
  }
}
